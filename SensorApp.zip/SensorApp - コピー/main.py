"""
SensorApp v3.0 - エントリポイント

センサデータ監視・AI予兆検知システムのメインモジュール。
運用モードと研究検証モードを切り替えて使用可能。
"""

import streamlit as st
from pathlib import Path
import traceback

# ページ設定（最初に呼び出す必要がある）
st.set_page_config(
    page_title="SensorApp v3.0",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded"
)


def main():
    """アプリケーションのメインエントリポイント"""
    
    try:
        # 設定ファイルのパス
        config_path = Path(__file__).parent / "config.json"
        
        # 設定をロード（AIパラメータはコード上のマスタ値を優先）
        from src.config.settings import AppConfig
        config = AppConfig.load_or_default_master(config_path)

        # ロギング設定の初期化（S+級: 可観測性の確保）
        from src.config.logging_config import configure_logging
        log_dir = config.paths.get_output_path() / "logs"
        configure_logging(log_dir=log_dir)
        
        # 設定が無効な場合はウィザードを表示
        from src.presentation.wizard import should_show_wizard, render as render_wizard
        
        if should_show_wizard(config):
            render_wizard(config, config_path)
            return
        
        # StateManager と AnalysisService を初期化
        from src.application.state_manager import StateManager
        from src.application.services import AnalysisService
        from src.application.context import AppMode
        
        state = StateManager()
        service = AnalysisService(config)
        
        # サイドバーを描画
        from src.presentation.components.sidebar import render_sidebar
        render_sidebar(state)
        
        # モードに応じた画面を表示
        if state.mode == AppMode.OPERATIONAL:
            from src.presentation.views import operational
            operational.render(state, service)
        else:
            from src.presentation.views import research
            research.render(state, service)
    
    except Exception as e:
        # 予期せぬエラーをキャッチして表示
        st.error("❌ アプリケーションエラーが発生しました")
        
        with st.expander("エラー詳細"):
            st.code(traceback.format_exc())
        
        st.info("""
        **対処方法:**
        1. ページを再読み込みしてください
        2. 問題が解決しない場合は、設定ファイル (config.json) を削除して再起動してください
        3. それでも解決しない場合は、管理者にお問い合わせください
        """)


if __name__ == "__main__":
    main()
