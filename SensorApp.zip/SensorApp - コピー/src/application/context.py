"""
実行コンテキスト定義モジュール (Version 3.0)

アプリケーションの実行モードを定義する。
運用モード(Operational)と研究モード(Research)を明確に区別し、
コンテキストに応じた処理分岐を型安全に行う。
"""

from enum import Enum


class AppMode(str, Enum):
    """
    アプリケーション動作モード
    
    Attributes:
        OPERATIONAL: 運用モード - 実機センサデータを使用した監視・保全判断支援
        RESEARCH: 研究検証モード - シード固定仮想データによるアルゴリズム評価
    """
    
    OPERATIONAL = "operational"
    RESEARCH = "research"
    
    @property
    def display_name(self) -> str:
        """UI表示用の名前を返す"""
        if self == AppMode.OPERATIONAL:
            return "運用モード"
        else:
            return "研究検証モード"
    
    @property
    def theme_color(self) -> str:
        """モードに応じたテーマカラーを返す"""
        if self == AppMode.OPERATIONAL:
            return "blue"  # 標準（青基調）
        else:
            return "violet"  # 実験的（紫基調）
    
    @property
    def tabs(self) -> list[str]:
        """モードに応じたタブ構成を返す"""
        if self == AppMode.OPERATIONAL:
            return ["データビュー", "センサ管理", "AIモデル", "設定"]
        else:
            return ["検証実行・評価", "設定"]
    
    def is_operational(self) -> bool:
        """運用モードかどうか"""
        return self == AppMode.OPERATIONAL
    
    def is_research(self) -> bool:
        """研究モードかどうか"""
        return self == AppMode.RESEARCH
