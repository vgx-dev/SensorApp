"""
管理サービスモジュール (Version 3.5)

センサ管理（マウント情報のCRUD）と測定実績集計を提供する。

DESIGN_SENSOR_CONTEXT.md 準拠:
- MasterDataRepositoryを利用したファイルIO
- センサID・使用者の選択式入力
- 設備・装置の親子関係
"""

from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime
from pathlib import Path
import pandas as pd

from .context import AppMode
from ..config.settings import AppConfig
from ..domain.entities.sensor import MountInfo
from ..domain.services.mount_manager import (
    complete_time_chain,
    resolve_context,
    get_current_context
)
from ..infrastructure.repositories.master_data import MasterDataRepository


class ManagementService:
    """
    管理サービス
    
    センサ管理（マウント履歴のCRUD）と測定実績の集計を担当。
    
    Usage:
        config = AppConfig.load_or_default(config_path)
        service = ManagementService(config)
        
        # マウント登録
        service.register_mount("SENSOR-001", "設備A", "装置1")
        
        # 測定実績集計
        stats = service.aggregate_measurement_stats()
    """
    
    def __init__(self, config: AppConfig):
        """
        初期化
        
        Args:
            config: アプリケーション設定
        """
        self.config = config
        self._repo = MasterDataRepository(config.paths)
        self._mount_df: Optional[pd.DataFrame] = None
    
    def _get_mount_file_path(self) -> Path:
        """マウントファイルパスを取得（内部用）"""
        appsetting_path = self.config.paths.get_appsetting_path()
        return appsetting_path / "sensor_mount_list.csv"
    
    def get_mount_file_path(self) -> Path:
        """マウントファイルパスを取得（パブリックAPI）"""
        return self._get_mount_file_path()
    
    def _load_mount_df(self) -> pd.DataFrame:
        """マウントDataFrameをロード"""
        if self._mount_df is not None:
            return self._mount_df
        
        mount_file = self._get_mount_file_path()
        
        # 必須列定義（UserName追加）
        required_columns = [
            "SensorID",
            "EquipmentID",
            "DeviceID",
            "UserName",
            "StartTime",
            "EndTime",
            "Remark"
        ]
        
        if mount_file.exists():
            try:
                df = pd.read_csv(mount_file, encoding="utf-8-sig")
                # 既存CSVに存在しない列を補完
                for col in required_columns:
                    if col not in df.columns:
                        df[col] = ""
                self._mount_df = df[required_columns].copy()
            except Exception:
                self._mount_df = self._create_empty_mount_df()
        else:
            self._mount_df = self._create_empty_mount_df()
        
        return self._mount_df
    
    def _create_empty_mount_df(self) -> pd.DataFrame:
        """空のマウントDataFrameを作成"""
        return pd.DataFrame(columns=[
            "SensorID",
            "EquipmentID",
            "DeviceID",
            "UserName",
            "StartTime",
            "EndTime",
            "Remark"
        ])
    
    def _save_mount_df(self) -> bool:
        """マウントDataFrameを保存"""
        if self._mount_df is None:
            return False
        
        try:
            # ドメインロジックでEndTime自動補完
            self._mount_df = complete_time_chain(self._mount_df)
            
            # リポジトリ経由で保存
            return self._repo.save_mount_history(self._mount_df)
        except Exception:
            return False
    
    def _apply_time_chain(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        ドメインロジックを呼び出してEndTime補完
        
        Note:
            後方互換性のためのラッパー。
            実際のロジックはdomain.services.mount_manager.complete_time_chainに委譲。
        """
        return complete_time_chain(df)
    
    def get_mount_history(self) -> pd.DataFrame:
        """マウント履歴を取得"""
        return self._load_mount_df().copy()
    
    def register_mount(
        self,
        sensor_id: str,
        equipment_id: str,
        device_id: str,
        *,
        start_time: Optional[datetime] = None,
        remark: str = ""
    ) -> bool:
        """
        マウント情報を新規登録
        
        Args:
            sensor_id: センサID
            equipment_id: 設備ID
            device_id: 装置ID
            start_time: 開始日時（省略時は現在）
            remark: 備考
            
        Returns:
            成功時True
        """
        df = self._load_mount_df()
        
        if start_time is None:
            start_time = datetime.now()
        
        new_row = {
            "SensorID": sensor_id,
            "EquipmentID": equipment_id,
            "DeviceID": device_id,
            "UserName": "",  # NOTE: このメソッドは非推奨。register_mount_with_user()を使用すること
            "StartTime": start_time.strftime("%Y-%m-%d %H:%M:%S"),
            "EndTime": "",
            "Remark": remark
        }
        
        self._mount_df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        return self._save_mount_df()
    
    def update_mount(
        self,
        index: int,
        *,
        sensor_id: Optional[str] = None,
        equipment_id: Optional[str] = None,
        device_id: Optional[str] = None,
        user_name: Optional[str] = None,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        remark: Optional[str] = None
    ) -> bool:
        """
        マウント情報を更新
        
        Args:
            index: 更新対象のインデックス
            **kwargs: 更新するフィールド
            
        Returns:
            成功時True
        """
        df = self._load_mount_df()
        
        if index < 0 or index >= len(df):
            return False
        
        if sensor_id is not None:
            df.loc[index, "SensorID"] = sensor_id
        if equipment_id is not None:
            df.loc[index, "EquipmentID"] = equipment_id
        if device_id is not None:
            df.loc[index, "DeviceID"] = device_id
        if user_name is not None:
            df.loc[index, "UserName"] = user_name
        if start_time is not None:
            df.loc[index, "StartTime"] = start_time
        if end_time is not None:
            df.loc[index, "EndTime"] = end_time
        if remark is not None:
            df.loc[index, "Remark"] = remark
        
        self._mount_df = df
        return self._save_mount_df()
    
    def delete_mount(self, index: int) -> bool:
        """
        マウント情報を削除
        
        Args:
            index: 削除対象のインデックス
            
        Returns:
            成功時True
        """
        df = self._load_mount_df()
        
        if index < 0 or index >= len(df):
            return False
        
        self._mount_df = df.drop(index).reset_index(drop=True)
        return self._save_mount_df()
    
    def aggregate_measurement_stats(self) -> pd.DataFrame:
        """
        測定実績を集計（設備×装置ごとの測定回数）
        
        Returns:
            DataFrame: equipment, device, count, is_currentの列を持つ
        """
        df = self._load_mount_df()
        
        if df.empty:
            return pd.DataFrame(columns=["equipment", "device", "count", "is_current"])
        
        # 設備×装置でグループ化
        stats = df.groupby(["EquipmentID", "DeviceID"]).size().reset_index(name="count")
        stats.columns = ["equipment", "device", "count"]
        
        # 現在取付中かどうか（ベクトル化 - iterrows廃止）
        # EndTimeが空のレコードの設備×装置ペアを取得
        current_df = df[
            (df["EndTime"].isna()) | 
            (df["EndTime"].astype(str).str.strip() == "")
        ][["EquipmentID", "DeviceID"]].drop_duplicates()
        current_df["_is_current"] = True
        
        # mergeで判定
        stats = stats.merge(
            current_df.rename(columns={"EquipmentID": "equipment", "DeviceID": "device"}),
            on=["equipment", "device"],
            how="left"
        )
        stats["is_current"] = stats["_is_current"].fillna(False)
        stats = stats.drop(columns=["_is_current"])
        
        return stats
    
    def get_current_mounts(self) -> Dict[str, str]:
        """
        現在取付中のセンサマッピングを取得
        
        Returns:
            Dict: {sensor_id: "設備 - 装置"}
        """
        df = self._load_mount_df()
        current_mount = {}
        now = pd.Timestamp.now()
        
        for _, row in df.iterrows():
            sensor_id = str(row.get("SensorID", ""))
            if not sensor_id:
                continue
            
            start_time = pd.to_datetime(row.get("StartTime"), errors="coerce")
            end_time = pd.to_datetime(row.get("EndTime"), errors="coerce")
            
            if pd.isna(start_time):
                continue
            
            # EndTimeがない場合は現在も有効
            if pd.isna(end_time):
                end_time = now
            
            if start_time <= now <= end_time:
                equip = row.get("EquipmentID", "未設定")
                dev = row.get("DeviceID", "未設定")
                current_mount[sensor_id] = f"{equip} - {dev}"
        
        return current_mount
    
    def clear_cache(self) -> None:
        """キャッシュをクリア"""
        self._mount_df = None
        self._repo.clear_cache()
    
    # ==================== 選択肢取得（UI支援） ====================
    
    def get_equipment_options(self) -> List[str]:
        """
        設備選択肢リストを取得
        
        Returns:
            設備IDリスト（ソート済み）
        """
        return self._repo.get_equipment_list()
    
    def get_device_options(self, equipment_id: Optional[str] = None) -> List[str]:
        """
        装置選択肢リストを取得
        
        Args:
            equipment_id: 設備IDでフィルタ（省略時は全装置）
        
        Returns:
            装置IDリスト（ソート済み）
        """
        return self._repo.get_device_list(equipment_id)
    
    def get_manager_suggestion(self, equipment_id: str, device_id: Optional[str] = None) -> str:
        """
        管理者名を自動補完（マスタから取得）
        
        Args:
            equipment_id: 設備ID
            device_id: 装置ID（省略時は設備のみでマッチ）
        
        Returns:
            管理者名（見つからない場合は空文字）
        """
        manager = self._repo.get_manager_by_equipment(equipment_id, device_id)
        return manager if manager else ""
    
    def get_sensor_context(self, sensor_id: str) -> Optional[MountInfo]:
        """
        センサの現在コンテキスト（設備・装置）を取得
        
        Args:
            sensor_id: センサID
        
        Returns:
            MountInfo: 現在のマウント情報（未設定時はNone）
        """
        df = self._load_mount_df()
        return get_current_context(df, sensor_id)
    
    def update_master_from_mount(
        self,
        equipment_id: str,
        device_id: str,
        manager: str = ""
    ) -> bool:
        """
        マウント登録時にマスタも更新
        
        Args:
            equipment_id: 設備ID
            device_id: 装置ID
            manager: 管理者名
        
        Returns:
            成功時True
        """
        if not equipment_id or not device_id:
            return False
        return self._repo.add_or_update_master(equipment_id, device_id, manager)
    
    # ==================== センサID・使用者取得 ====================
    
    def get_sensor_options(self) -> List[str]:
        """
        センサID選択肢リストを取得
        
        Returns:
            センサIDリスト（ソート済み）
        """
        return self._repo.get_sensor_id_list()
    
    def get_user_options(self) -> List[str]:
        """
        使用者選択肢リストを取得
        
        Returns:
            使用者名リスト（ソート済み）
        """
        return self._repo.get_user_list()
    
    def get_user_suggestion(self, sensor_id: str) -> str:
        """
        センサIDから使用者を自動補完
        
        Args:
            sensor_id: センサID
        
        Returns:
            使用者名（見つからない場合は空文字）
        """
        user = self._repo.get_user_by_sensor(sensor_id)
        return user if user else ""
    
    def get_equipment_device_pairs(self) -> List[Dict[str, str]]:
        """
        設備・装置のペアリストを取得（親子関係用）
        
        Returns:
            [{"equipment": "OPF-1", "device": "CTポンプ"}, ...]
        """
        return self._repo.get_equipment_device_pairs()
    
    def register_mount_with_user(
        self,
        sensor_id: str,
        equipment_id: str,
        device_id: str,
        user_name: str = "",
        remark: str = "",
        start_time: Optional[datetime] = None
    ) -> bool:
        """
        マウントを登録（使用者情報付き）
        
        Args:
            sensor_id: センサID
            equipment_id: 設備ID
            device_id: 装置ID
            user_name: 使用者名
            remark: 備考
            start_time: 開始時刻（省略時は現在時刻）
        
        Returns:
            成功時True
        """
        df = self._load_mount_df()
        
        if start_time is None:
            start_time = datetime.now()
        
        new_row = {
            "SensorID": sensor_id,
            "EquipmentID": equipment_id,
            "DeviceID": device_id,
            "UserName": user_name,
            "StartTime": start_time.strftime("%Y-%m-%d %H:%M:%S"),
            "EndTime": "",
            "Remark": remark
        }
        
        self._mount_df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        return self._save_mount_df()
