"""
アプリケーションサービスモジュール (Version 3.0)

UIから呼び出され、ドメインロジックとインフラストラクチャを制御する。
Strategyパターンでデータプロバイダを切り替え、運用/研究モードを統一的に扱う。
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from contextlib import contextmanager
import warnings
from typing import Optional, Union, Dict, Any
import numpy as np

from .state_manager import StateManager
from .context import AppMode
from ..config.settings import AppConfig, PathConfig, AIParams, ForecastParams
from ..domain.entities.sensor import SensorData, MountInfo
from ..domain.entities.analysis import AnalysisResult, FutureForecast, TrendComponents
from ..domain.ai.detector import AnomalyDetector, TrainedModels
from ..domain.ai.forecaster import Forecaster
from ..domain.services.scoring import integrate_scores
from ..infrastructure.repositories.real_data import RealDataProvider
from ..infrastructure.repositories.virtual_data import VirtualDataProvider, AnomalyScenario
from ..infrastructure.repositories.model_store import ModelStore


@dataclass
class AnalysisContext:
    """
    分析実行コンテキスト
    
    分析実行に必要なパラメータをまとめた構造体。
    """
    
    sensor_id: str
    mode: AppMode
    
    # 研究モード用
    scenario: Optional[AnomalyScenario] = None
    random_seed: int = 42
    
    # オプション
    n_points: int = 1000
    tail_rows: Optional[int] = None


class AnalysisService:
    """
    分析サービスクラス
    
    UIから呼び出され、データ取得→AI推論→予測の一連の処理を制御。
    モードに応じてデータプロバイダを切り替える（Strategyパターン）。
    
    Usage:
        # 常にコード上のデフォルト値（マスタ）を使用
        config = AppConfig.load_or_default_master(Path("config.json"))
        service = AnalysisService(config)
        
        # 運用モード
        result = service.run_analysis(AnalysisContext(
            sensor_id="SENSOR-001",
            mode=AppMode.OPERATIONAL
        ))
        
        # 研究モード（シード固定）
        result = service.run_analysis(AnalysisContext(
            sensor_id="VIRT-001",
            mode=AppMode.RESEARCH,
            scenario=AnomalyScenario(anomaly_type="spike"),
            random_seed=42
        ))
    """
    
    def __init__(self, config: AppConfig):
        """
        初期化
        
        Args:
            config: アプリケーション設定
        """
        self.config = config
        self._real_provider: Optional[RealDataProvider] = None
        self._virtual_provider: Optional[VirtualDataProvider] = None
        self._model_store: Optional[ModelStore] = None
        self._detector: Optional[AnomalyDetector] = None
        self._forecaster: Optional[Forecaster] = None
    
    def get_data_provider(
        self,
        mode: AppMode,
        seed: Optional[int] = None
    ) -> Union[RealDataProvider, VirtualDataProvider]:
        """
        モードに応じたデータプロバイダを取得（Strategyパターン）
        
        Args:
            mode: アプリケーションモード
            seed: 乱数シード（研究モード用）
            
        Returns:
            データプロバイダ
        """
        if mode == AppMode.OPERATIONAL:
            if self._real_provider is None:
                self._real_provider = RealDataProvider(self.config.paths)
            return self._real_provider
        else:
            # 研究モード: シード固定
            if seed is None:
                seed = 42
            if self._virtual_provider is None or self._virtual_provider.seed != seed:
                self._virtual_provider = VirtualDataProvider(seed=seed)
            return self._virtual_provider
    
    def get_model_store(self) -> ModelStore:
        """モデルストアを取得"""
        if self._model_store is None:
            self._model_store = ModelStore(self.config.paths)
        return self._model_store
    
    def get_detector(self) -> AnomalyDetector:
        """異常検知器を取得"""
        if self._detector is None:
            self._detector = AnomalyDetector(self.config.ai_params)
        return self._detector
    
    def get_forecaster(self) -> Forecaster:
        """予測器を取得"""
        if self._forecaster is None:
            self._forecaster = Forecaster(self.config.forecast_params)
        return self._forecaster
    
    def run_analysis(
        self,
        context: AnalysisContext
    ) -> Dict[str, Any]:
        """
        分析を実行
        
        Args:
            context: 分析コンテキスト
            
        Returns:
            分析結果辞書:
                - sensor_data: SensorData
                - analysis_result: AnalysisResult
                - forecast: FutureForecast
                - metadata: Dict
        """
        # 研究モードの場合はコンテキストマネージャーでシード固定
        if context.mode == AppMode.RESEARCH:
            with self.seed_context(context.random_seed):
                return self._run_analysis_impl(context)
        else:
            # 運用モードは通常実行
            return self._run_analysis_impl(context)
    
    def _run_analysis_impl(self, context: AnalysisContext) -> Dict[str, Any]:
        """
        分析の実際の実装（seed_context内で実行される）
        
        Args:
            context: 分析コンテキスト
            
        Returns:
            分析結果辞書
        """
        # データ取得
        provider = self.get_data_provider(context.mode, context.random_seed)
        
        if context.mode == AppMode.RESEARCH and context.scenario is not None:
            # 研究モード: シナリオ付きデータ生成
            sensor_data = provider.get_sensor_data(
                context.sensor_id,
                n_points=context.n_points,
                scenario=context.scenario
            )
        elif context.mode == AppMode.OPERATIONAL and context.tail_rows is not None:
            # 運用モード: 末尾のみ取得
            sensor_data = provider.get_sensor_data(
                context.sensor_id,
                tail_rows=context.tail_rows
            )
        else:
            sensor_data = provider.get_sensor_data(context.sensor_id)
        
        if sensor_data.is_empty:
            return self._empty_result(context.sensor_id)
        
        # モデル取得/学習
        models = self._get_or_train_models(
            sensor_data,
            context,
            provider
        )
        
        # 異常検知
        detector = self.get_detector()
        analysis_result = detector.score(
            sensor_data.dataframe,
            models,
            value_columns=sensor_data.value_columns,
            sensor_id=context.sensor_id
        )
        
        # トレンド計算（Forecasterと共有） Phase 2
        rms_col = sensor_data.value_columns[0] if sensor_data.value_columns else "RMS"
        trend_components = self._compute_trend_components(sensor_data, rms_col)
        
        # 未来予測（計算済みトレンドと異常スコアを使用） Phase 3
        forecaster = self.get_forecaster()
        forecast = forecaster.predict(
            sensor_data.dataframe,
            time_col=sensor_data.time_column,
            value_col=rms_col,
            sensor_id=context.sensor_id,
            trend_components=trend_components,
            current_anomaly_score=analysis_result.mean_score
        )
        
        # ★ S級: メンテナンス推奨をApplication層で生成
        forecast.maintenance = self._generate_maintenance_recommendation(
            forecast,
            sensor_data,
            rms_col
        )
        
        return {
            "sensor_data": sensor_data,
            "analysis_result": analysis_result,
            "forecast": forecast,
            "metadata": {
                "mode": context.mode.value,
                "analyzed_at": datetime.now().isoformat(),
                "data_points": sensor_data.length,
                "random_seed": context.random_seed if context.mode == AppMode.RESEARCH else None
            }
        }
    
    def run_research_scenario(
        self,
        params: Dict[str, Any],
        seed: int = 42
    ) -> Dict[str, Any]:
        """
        研究シナリオを実行（簡易版）
        
        UIから直接呼び出す用のラッパー。
        
        Args:
            params: シナリオパラメータ
            seed: 乱数シード
            
        Returns:
            分析結果
        """
        scenario = AnomalyScenario(
            anomaly_type=params.get("type", "spike"),
            amplitude=params.get("amplitude", 2.0),
            duration=params.get("duration", 10),
            injection_point=params.get("injection_point", 0.7),
            spike_count=params.get("spike_count", 5),
            trend_slope=params.get("trend_slope", 0.01)
        )
        
        context = AnalysisContext(
            sensor_id=params.get("sensor_id", "VIRT-001"),
            mode=AppMode.RESEARCH,
            scenario=scenario,
            random_seed=seed,
            n_points=params.get("n_points", 500)
        )
        
        return self.run_analysis(context)
    
    def list_sensors(self, mode: AppMode) -> list[str]:
        """センサ一覧を取得"""
        provider = self.get_data_provider(mode)
        return provider.list_sensors()
    
    def get_mount_info(self, mode: AppMode) -> list[MountInfo]:
        """マウント情報を取得"""
        provider = self.get_data_provider(mode)
        return provider.get_mount_info()
    
    def _compute_trend_components(
        self, 
        sensor_data: SensorData, 
        value_col: str
    ) -> Optional[TrendComponents]:
        """
        トレンド成分を計算
        
        Forecasterの内部ロジックを再利用してトレンド成分を計算する。
        データが不足している場合はNoneを返し、Forecasterに内部計算させる。
        
        Args:
            sensor_data: センサデータ
            value_col: 値列名
            
        Returns:
            TrendComponents or None: トレンド成分（データ不足時はNone）
        """
        if sensor_data.is_empty or value_col not in sensor_data.dataframe.columns:
            return None
        
        values = sensor_data.dataframe[value_col].dropna().values.astype(float)
        if len(values) < 10:
            return None
        
        # Forecasterのインスタンスメソッドを利用
        forecaster = self.get_forecaster()
        return forecaster._decompose_trend(values)
    
    def _generate_maintenance_recommendation(
        self,
        forecast: FutureForecast,
        sensor_data: SensorData,
        value_col: str
    ) -> Optional['MaintenanceRecommendation']:
        """
        メンテナンス推奨を生成（S級改善）
        
        振動値の予測値から、現在値+critical_deltaを超える日数を推定。
        
        Args:
            forecast: 予測結果
            sensor_data: センサデータ
            value_col: 値列名
            
        Returns:
            MaintenanceRecommendation or None
        """
        from ..domain.entities.analysis import MaintenanceRecommendation
        
        # 予測データがない場合
        if forecast.length == 0:
            return None
        
        # 現在値を取得
        if sensor_data.is_empty or value_col not in sensor_data.dataframe.columns:
            return None
        
        current_value = sensor_data.dataframe[value_col].dropna().iloc[-1]
        
        # 閾値を取得
        params = self.config.forecast_params
        critical_delta = params.critical_delta_mps2
        warning_delta = params.warning_delta_mps2
        
        # 各閾値を超える日数を探索
        critical_threshold = current_value + critical_delta
        warning_threshold = current_value + warning_delta
        
        critical_days = None
        warning_days = None
        
        for i, pred_val in enumerate(forecast.forecast_values):
            if critical_days is None and pred_val >= critical_threshold:
                critical_days = i + 1
            if warning_days is None and pred_val >= warning_threshold:
                warning_days = i + 1
            if critical_days is not None and warning_days is not None:
                break
        
        # 緊急度判定
        if critical_days is not None and critical_days <= 30:
            return MaintenanceRecommendation(
                urgency="immediate",
                estimated_days=critical_days,
                confidence="high" if critical_days <= 14 else "medium",
                reasoning=f"{critical_days}日以内に危険レベルに達する可能性。早急にメンテナンスを実施してください。"
            )
        elif warning_days is not None and warning_days <= 90:
            return MaintenanceRecommendation(
                urgency="scheduled",
                estimated_days=warning_days,
                confidence="medium" if warning_days <= 60 else "low",
                reasoning=f"{warning_days}日以内に警告レベルに達する可能性。メンテナンスを計画してください。"
            )
        else:
            return MaintenanceRecommendation(
                urgency="monitor",
                estimated_days=None,
                confidence="low",
                reasoning="現在のトレンドでは当面の間、注意レベルに達しません。引き続き監視を継続してください。"
            )
    
    def _get_or_train_models(
        self,
        sensor_data: SensorData,
        context: AnalysisContext,
        provider: Union[RealDataProvider, VirtualDataProvider]
    ) -> TrainedModels:
        """
        モデルを取得または学習
        
        運用モード: モデルストアからロード
        研究モード: その場で学習
        """
        detector = self.get_detector()
        
        if context.mode == AppMode.OPERATIONAL:
            # 運用モード: 保存済みモデルをロード試行
            store = self.get_model_store()
            mounts = provider.get_mount_info()
            
            # マウント情報からequip/devを取得
            mount = next(
                (m for m in mounts if m.sensor_id == context.sensor_id),
                None
            )
            
            if mount is not None:
                # IFモデルをロード試行
                if_model = store.load_model(
                    algorithm="IF",
                    equipment=mount.equipment,
                    device=mount.device
                )
                
                if if_model is not None:
                    return TrainedModels(
                        isolation_forest=if_model,
                        metadata={"loaded_from": "store"}
                    )
        
        # モデルがないか、研究モードの場合は学習
        models = detector.fit(
            sensor_data.dataframe,
            value_columns=sensor_data.value_columns,
            random_state=context.random_seed
        )
        
        return models
    
    @contextmanager
    def seed_context(self, seed: int):
        """
        乱数シードを一時的に設定するコンテキストマネージャー（研究モード専用）
        
        研究モードで再現性を保証するため、グローバル乱数シードを設定する。
        運用モードでは使用しない。
        
        Note:
            - random/numpy の状態は終了時に復元される
            - TensorFlowは復元不可能だが、研究モード後も設定されたままで実害なし
            - 複数セッション間での干渉は Streamlit のプロセス分離により回避される
        
        Usage:
            with self.seed_context(42):
                # ここで推論実行
                result = model.predict(data)
        """
        import random
        
        # 現在の状態を保存
        state_random = random.getstate()
        state_np = np.random.get_state()
        
        # シード設定
        random.seed(seed)
        np.random.seed(seed)
        
        # TensorFlowがあればシード設定（復元はしない）
        try:
            import tensorflow as tf
            tf.random.set_seed(seed)
        except ImportError:
            pass
        
        try:
            yield
        finally:
            # random/numpyのみ復元（TensorFlowは復元不要）
            random.setstate(state_random)
            np.random.set_state(state_np)
    
    def _empty_result(self, sensor_id: str) -> Dict[str, Any]:
        """空の結果を返す"""
        return {
            "sensor_data": SensorData(sensor_id=sensor_id, dataframe=None),
            "analysis_result": AnalysisResult(sensor_id=sensor_id),
            "forecast": FutureForecast(sensor_id=sensor_id),
            "metadata": {
                "error": "no_data",
                "analyzed_at": datetime.now().isoformat()
            }
        }
