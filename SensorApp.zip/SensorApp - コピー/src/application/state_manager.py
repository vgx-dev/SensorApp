"""
状態管理モジュール (Version 3.0)

Streamlit SessionStateのファサードとして機能し、
運用モード/研究モードのコンテキストを分離管理する。
"""

from typing import Any, Dict, Optional
from pydantic import BaseModel, Field
from cachetools import LRUCache

# LRUキャッシュの最大サイズ（結果キャッシュ用）
MAX_RESULT_CACHE_SIZE = 10

# Note: streamlitはUI層でのみインポートされることを想定
# テスト時はモック化する
try:
    import streamlit as st
    _HAS_STREAMLIT = True
except ImportError:
    _HAS_STREAMLIT = False
    st = None

from .context import AppMode


class OperationalContext(BaseModel):
    """
    運用モードの状態コンテキスト
    
    実機センサデータの監視に必要な状態を保持する。
    セッション終了時に破棄される（永続性はセッション限り）。
    """
    
    # 選択中のセンサ
    selected_sensor_id: Optional[str] = Field(
        default=None,
        description="現在選択されているセンサID"
    )
    
    # 期間フィルタ
    date_range_start: Optional[str] = Field(
        default=None,
        description="表示期間の開始日（ISO形式）"
    )
    date_range_end: Optional[str] = Field(
        default=None,
        description="表示期間の終了日（ISO形式）"
    )
    
    # 表示設定
    show_anomaly_score: bool = Field(
        default=True,
        description="異常スコアを表示するか"
    )
    show_forecast: bool = Field(
        default=True,
        description="未来予測を表示するか"
    )
    
    class Config:
        """Pydantic設定"""
        validate_assignment = True


class ResearchContext(BaseModel):
    """
    研究検証モードの状態コンテキスト
    
    アルゴリズム評価・論文用データ生成に必要な状態を保持する。
    パラメータ変更がない限り結果をキャッシュする。
    """
    
    # 対象センサ（仮想）
    target_sensor_id: str = Field(
        default="VIRT-001",
        description="評価対象の仮想センサID"
    )
    
    # シナリオパラメータ
    params: Dict[str, Any] = Field(
        default_factory=lambda: {
            "type": "spike",       # 異常タイプ: spike, shift, trend
            "amplitude": 2.0,      # 異常の振幅
            "duration": 10,        # 異常の継続期間
            "injection_point": 0.7 # データの何割地点で注入するか (0.0-1.0)
        },
        description="異常注入シナリオのパラメータ"
    )
    
    # 再現性用シード
    random_seed: int = Field(
        default=42,
        description="乱数シード（再現性保証用）"
    )
    
    # 結果キャッシュのキー（パラメータのハッシュ）
    _cache_key: Optional[str] = None
    
    class Config:
        """Pydantic設定"""
        validate_assignment = True
    
    def get_cache_key(self) -> str:
        """現在のパラメータに基づくキャッシュキーを生成"""
        import hashlib
        import json
        
        key_data = {
            "sensor_id": self.target_sensor_id,
            "params": self.params,
            "seed": self.random_seed
        }
        key_str = json.dumps(key_data, sort_keys=True)
        return hashlib.md5(key_str.encode()).hexdigest()


class StateManager:
    """
    SessionState管理クラス
    
    Streamlit st.session_state のファサードとして機能し、
    モードごとの状態（Context）を分離管理する。
    シングルトン的に振る舞う（同一セッション内で状態を共有）。
    
    Usage:
        state = StateManager()
        
        # モード切替
        state.mode = AppMode.RESEARCH
        
        # コンテキスト取得
        if state.mode.is_operational():
            sensor_id = state.operational.selected_sensor_id
        else:
            params = state.research.params
    """
    
    # SessionState のキー名
    _KEY_MODE = "app_mode"
    _KEY_CTX_OPS = "ctx_ops"
    _KEY_CTX_RES = "ctx_res"
    _KEY_RESULT_CACHE = "result_cache"
    
    def __init__(self):
        """
        StateManagerを初期化
        
        SessionStateに各コンテキストが存在しない場合は初期化する。
        """
        self._ensure_initialized()
    
    def _ensure_initialized(self) -> None:
        """SessionStateの初期化を保証"""
        if not _HAS_STREAMLIT or st is None:
            # Streamlit外での実行時（テスト等）は何もしない
            return
        
        if self._KEY_MODE not in st.session_state:
            st.session_state[self._KEY_MODE] = AppMode.OPERATIONAL
        
        if self._KEY_CTX_OPS not in st.session_state:
            st.session_state[self._KEY_CTX_OPS] = OperationalContext()
        
        if self._KEY_CTX_RES not in st.session_state:
            st.session_state[self._KEY_CTX_RES] = ResearchContext()
        
        if self._KEY_RESULT_CACHE not in st.session_state:
            st.session_state[self._KEY_RESULT_CACHE] = LRUCache(maxsize=MAX_RESULT_CACHE_SIZE)
    
    @property
    def mode(self) -> AppMode:
        """現在のアプリケーションモードを取得"""
        if not _HAS_STREAMLIT or st is None:
            return AppMode.OPERATIONAL
        return st.session_state.get(self._KEY_MODE, AppMode.OPERATIONAL)
    
    @mode.setter
    def mode(self, value: AppMode) -> None:
        """アプリケーションモードを設定"""
        if not _HAS_STREAMLIT or st is None:
            return
        st.session_state[self._KEY_MODE] = value
    
    @property
    def operational(self) -> OperationalContext:
        """運用モードのコンテキストを取得"""
        if not _HAS_STREAMLIT or st is None:
            return OperationalContext()
        return st.session_state.get(self._KEY_CTX_OPS, OperationalContext())
    
    @property
    def research(self) -> ResearchContext:
        """研究モードのコンテキストを取得"""
        if not _HAS_STREAMLIT or st is None:
            return ResearchContext()
        return st.session_state.get(self._KEY_CTX_RES, ResearchContext())
    
    def update_operational(self, **kwargs) -> None:
        """
        運用コンテキストを更新
        
        Args:
            **kwargs: 更新するフィールドと値
        """
        if not _HAS_STREAMLIT or st is None:
            return
        
        ctx = self.operational
        for key, value in kwargs.items():
            if hasattr(ctx, key):
                setattr(ctx, key, value)
        st.session_state[self._KEY_CTX_OPS] = ctx
    
    def update_research(self, **kwargs) -> None:
        """
        研究コンテキストを更新
        
        Args:
            **kwargs: 更新するフィールドと値
        """
        if not _HAS_STREAMLIT or st is None:
            return
        
        ctx = self.research
        for key, value in kwargs.items():
            if hasattr(ctx, key):
                setattr(ctx, key, value)
        st.session_state[self._KEY_CTX_RES] = ctx
    
    def cache_result(self, key: str, result: Any) -> None:
        """
        計算結果をキャッシュに保存
        
        Args:
            key: キャッシュキー
            result: 保存する結果
        """
        if not _HAS_STREAMLIT or st is None:
            return
        st.session_state[self._KEY_RESULT_CACHE][key] = result
    
    def get_cached_result(self, key: str) -> Optional[Any]:
        """
        キャッシュから結果を取得
        
        Args:
            key: キャッシュキー
            
        Returns:
            キャッシュされた結果、なければNone
        """
        if not _HAS_STREAMLIT or st is None:
            return None
        return st.session_state.get(self._KEY_RESULT_CACHE, {}).get(key)
    
    def clear_cache(self) -> None:
        """結果キャッシュをクリア"""
        if not _HAS_STREAMLIT or st is None:
            return
        st.session_state[self._KEY_RESULT_CACHE] = {}
    
    def reset(self) -> None:
        """すべての状態をリセット"""
        if not _HAS_STREAMLIT or st is None:
            return
        
        st.session_state[self._KEY_MODE] = AppMode.OPERATIONAL
        st.session_state[self._KEY_CTX_OPS] = OperationalContext()
        st.session_state[self._KEY_CTX_RES] = ResearchContext()
        st.session_state[self._KEY_RESULT_CACHE] = {}
