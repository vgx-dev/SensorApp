"""
ロギング設定モジュール (Version 3.0)

アプリケーション全体のログ出力を設定する。
- コンソール出力: 開発用（INFOレベル以上）
- ファイル出力: 運用監視用（INFOレベル以上、ローテーション付き）
- フォーマット: 時刻、レベル、モジュール名、メッセージ
"""

import logging
import logging.handlers
from pathlib import Path
import sys
from typing import Optional

def configure_logging(log_dir: Optional[Path] = None, log_level: int = logging.INFO) -> None:
    """
    ロギング設定を初期化
    
    Args:
        log_dir: ログファイルの保存先ディレクトリ（Noneの場合はファイル出力なし）
        log_level: ログレベル
    """
    # ルートロガーの取得
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    
    # 既存のハンドラをクリア（二重登録防止）
    if root_logger.handlers:
        root_logger.handlers.clear()
    
    # フォーマッタ
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(name)s - %(message)s'
    )
    
    # 1. コンソールハンドラ
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(log_level)
    root_logger.addHandler(console_handler)
    
    # 2. ファイルハンドラ（ディレクトリ指定がある場合）
    if log_dir:
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / "app.log"
            
            # ローテーション設定: 10MB x 5世代
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=10*1024*1024,
                backupCount=5,
                encoding='utf-8'
            )
            file_handler.setFormatter(formatter)
            file_handler.setLevel(log_level)
            root_logger.addHandler(file_handler)
            
        except Exception as e:
            # ログ設定自体のエラーは標準エラーに出力して続行
            sys.stderr.write(f"Failed to setup log file handler: {e}\n")

    # ライブラリのログ抑制（必要に応じて）
    logging.getLogger("matplotlib").setLevel(logging.WARNING)
    logging.getLogger("PIL").setLevel(logging.WARNING)
    logging.getLogger("fsevents").setLevel(logging.WARNING)
