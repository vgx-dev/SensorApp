"""
設定管理モジュール (Version 3.0)

Pydanticモデルによる型安全な設定スキーマ定義。
運用モード/研究モード共通のアプリケーション設定を管理する。
"""

from pathlib import Path
from typing import Optional
import json

from pydantic import BaseModel, Field, field_validator


class PathConfig(BaseModel):
    """データ/モデル/出力ディレクトリのパス設定"""
    
    data_dir: str = Field(
        default="",
        description="センサデータ(CSV)が格納されているディレクトリ（Log）"
    )
    appsetting_dir: str = Field(
        default="",
        description="設定ファイル（ヘッダ定義等）が格納されているディレクトリ（AppSetting）"
    )
    model_dir: str = Field(
        default="",
        description="学習済みAIモデルの保存ディレクトリ"
    )
    output_dir: str = Field(
        default="",
        description="レポート等の出力先ディレクトリ"
    )
    
    @field_validator("data_dir", "appsetting_dir", "model_dir", "output_dir", mode="before")
    @classmethod
    def convert_path_to_str(cls, v):
        """PathオブジェクトをstrにPath変換"""
        if isinstance(v, Path):
            return str(v)
        return v
    
    def get_data_path(self) -> Path:
        """データディレクトリのPathオブジェクトを取得"""
        return Path(self.data_dir) if self.data_dir else Path(".")
    
    def get_appsetting_path(self) -> Path:
        """AppSettingディレクトリのPathオブジェクトを取得"""
        if self.appsetting_dir:
            return Path(self.appsetting_dir)
        # フォールバック: data_dirの兄弟
        if self.data_dir:
            return Path(self.data_dir).parent / "AppSetting"
        return Path(".")
    
    def get_model_path(self) -> Path:
        """モデルディレクトリのPathオブジェクトを取得"""
        return Path(self.model_dir) if self.model_dir else Path("./models")
    
    def get_output_path(self) -> Path:
        """出力ディレクトリのPathオブジェクトを取得"""
        return Path(self.output_dir) if self.output_dir else Path("./output")
    
    def is_valid(self) -> bool:
        """パス設定が有効かチェック（空でなく、ディレクトリが存在する）"""
        if not self.data_dir:
            return False
        data_path = self.get_data_path()
        return data_path.exists() and data_path.is_dir()


class AIParams(BaseModel):
    """AIモデルパラメータ"""
    
    # Isolation Forest
    if_n_estimators: int = Field(default=100, ge=10, le=1000)
    if_contamination: float = Field(default=0.05, ge=0.01, le=0.5)
    
    # AutoEncoder
    ae_epochs: int = Field(default=50, ge=10, le=500)
    ae_batch_size: int = Field(default=32, ge=8, le=256)
    ae_learning_rate: float = Field(default=0.001, ge=0.0001, le=0.1)
    
    # LSTM
    lstm_sequence_length: int = Field(default=10, ge=5, le=100)
    lstm_epochs: int = Field(default=50, ge=10, le=500)
    
    # スコア統合の重み
    weight_if: float = Field(default=0.4, ge=0.0, le=1.0)
    weight_ae: float = Field(default=0.3, ge=0.0, le=1.0)
    weight_lstm: float = Field(default=0.0, ge=0.0, le=1.0)  # 無効化（現状未実装のため）
    
    # 動的閾値
    threshold_percentile: float = Field(
        default=86.0,  # 88.0から86.0に調整（感度向上）
        ge=50.0,
        le=99.0,
        description="動的閾値のパーセンタイル（デフォルト86 = 上位14%を異常とする）"
    )
    
    @field_validator("weight_if", "weight_ae", "weight_lstm", mode="after")
    @classmethod
    def validate_weights_sum(cls, v, info):
        """重みの合計が1.0になることを推奨（警告のみ）"""
        # Note: 個別バリデータでは合計チェックは困難
        # model_validator で対応する場合もある
        return v


class ForecastParams(BaseModel):
    """未来予測パラメータ"""
    
    forecast_days: int = Field(
        default=365,  # 1年先まで予測
        ge=1,
        le=365,
        description="予測する日数"
    )
    confidence_level: float = Field(
        default=0.95,
        ge=0.5,
        le=0.99,
        description="信頼区間のレベル（例：0.95 = 95%信頼区間）"
    )
    trend_window: int = Field(
        default=7,
        ge=1,
        le=30,
        description="トレンド抽出の移動平均窓サイズ（日数）"
    )
    decompose_period: int = Field(
        default=7,
        ge=1,
        le=30,
        description="季節成分分解の周期"
    )
    
    # ★ S+級改善: 適応的予測パラメータ
    use_adaptive_forecast: bool = Field(
        default=True,
        description="適応的予測を有効化（急激な変化に2次曲線でフィット）"
    )
    recent_weight: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="直近データの重み（0.5-0.9推奨、高いほど急変に敏感）"
    )
    recent_window_ratio: float = Field(
        default=0.2,
        ge=0.1,
        le=0.5,
        description="直近ウィンドウの比率（全データの何%を直近と見なすか）"
    )
    
    # ★ S級改善: 絶対値ベース信頼区間パラメータ（振動値専用）
    use_absolute_margin: bool = Field(
        default=True,
        description="絶対値ベースのマージンを使用（振動値では+1が明確な悪化指標）"
    )
    base_margin_mps2: float = Field(
        default=0.15,  # センサノイズフロア(0.05) × 3σ
        ge=0.0,
        le=1.0,
        description="基準マージン [m/s²]（1日後の信頼区間幅）"
    )
    margin_growth_exponent: float = Field(
        default=0.5,  # √t成長（学術的標準）
        ge=0.0,
        le=1.0,
        description="マージン成長の指数（0.5=√t成長、1.0=線形成長）"
    )
    sensor_noise_floor_mps2: float = Field(
        default=0.05,
        ge=0.001,
        le=0.5,
        description="センサノイズフロア [m/s²]（ISO 10816準拠、典型値0.01-0.05）"
    )
    
    # ★ S級改善: メンテナンス閾値（単位明記）
    critical_delta_mps2: float = Field(
        default=1.0,
        ge=0.1,
        le=10.0,
        description="危険レベル増分 [m/s²]（この値を超えると即メンテナンス）"
    )
    warning_delta_mps2: float = Field(
        default=0.5,
        ge=0.05,
        le=5.0,
        description="警告レベル増分 [m/s²]（この値を超えると要注意）"
    )
    
    @classmethod
    def from_sensor_noise(
        cls,
        noise_floor_mps2: float = 0.05,
        critical_delta: float = 1.0,
        warning_delta: float = 0.5
    ) -> "ForecastParams":
        """
        センサ特性に基づくパラメータ自動設定
        
        Args:
            noise_floor_mps2: センサノイズフロア [m/s²]
            critical_delta: 危険レベル増分 [m/s²]
            warning_delta: 警告レベル増分 [m/s²]
            
        Returns:
            センサ特性に最適化されたForecastParams
            
        Note:
            - base_margin = noise_floor × 3 (3σ相当)
            - √t成長を採用（予測分散の時系列理論に準拠）
        """
        return cls(
            use_absolute_margin=True,
            base_margin_mps2=noise_floor_mps2 * 3.0,  # 3σ相当
            margin_growth_exponent=0.5,  # √t成長
            sensor_noise_floor_mps2=noise_floor_mps2,
            critical_delta_mps2=critical_delta,
            warning_delta_mps2=warning_delta
        )


class AppConfig(BaseModel):
    """
    アプリケーション設定（統合）
    
    JSONファイルからロード/保存が可能な設定クラス。
    運用モードでは読み取り専用として使用し、
    研究モードではコピーを編集して実験する。
    """
    
    paths: PathConfig = Field(default_factory=PathConfig)
    ai_params: AIParams = Field(default_factory=AIParams)
    forecast_params: ForecastParams = Field(default_factory=ForecastParams)
    
    # アプリケーションメタ情報
    version: str = Field(default="3.0.0")
    last_updated: Optional[str] = Field(default=None)
    
    @classmethod
    def load(cls, path: Path) -> "AppConfig":
        """
        JSONファイルから設定をロード
        
        Args:
            path: 設定ファイルのパス
            
        Returns:
            AppConfigインスタンス
            
        Raises:
            FileNotFoundError: ファイルが存在しない場合
            json.JSONDecodeError: JSONパースエラー
            ValidationError: Pydanticバリデーションエラー
        """
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.model_validate(data)
    
    @classmethod
    def load_or_default(cls, path: Path) -> "AppConfig":
        """
        設定ファイルをロード。存在しない場合はデフォルト設定を返す
        
        Args:
            path: 設定ファイルのパス
            
        Returns:
            AppConfigインスタンス
        """
        if path.exists():
            try:
                return cls.load(path)
            except (json.JSONDecodeError, Exception):
                # 不正なファイルの場合はデフォルトを返す
                return cls()
        return cls()
    
    @classmethod
    def load_or_default_master(cls, path: Path) -> "AppConfig":
        """
        マスタデフォルト値をロード（config.jsonを無視）
        
        研究検証モード等で「コード上の定義が真実」とする場合に使用。
        setting.pyに定義されたデフォルト値をマスタとして扱い、
        ローカルのconfig.jsonに古い設定が残っていても無視する。
        
        Args:
            path: 設定ファイルのパス（参照のみ、実際にはロードしない）
            
        Returns:
            AppConfigインスタンス（コード上のデフォルト値）
        """
        # 常にデフォルト値を返す（config.jsonを無視）
        config = cls()
        
        # パス設定のみはconfig.jsonから取得（データディレクトリ等は環境依存のため）
        if path.exists():
            try:
                loaded = cls.load(path)
                config.paths = loaded.paths  # パス設定のみ引き継ぐ
            except (json.JSONDecodeError, Exception):
                pass  # ロード失敗時はデフォルトのまま
        
        return config

    
    def save(self, path: Path) -> None:
        """
        設定をJSONファイルに保存
        
        Args:
            path: 保存先のパス
        """
        from datetime import datetime
        
        # 更新日時を記録
        self.last_updated = datetime.now().isoformat()
        
        # 親ディレクトリが存在しない場合は作成
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.model_dump(),
                f,
                ensure_ascii=False,
                indent=2
            )
    
    @property
    def is_valid(self) -> bool:
        """
        設定が有効かチェック
        
        最低限、データディレクトリのパスが設定されていて、
        そのディレクトリが存在することを確認する。
        """
        return self.paths.is_valid()
    
    def copy_for_research(self) -> "AppConfig":
        """
        研究モード用に設定のコピーを作成
        
        研究モードではこのコピーを自由に編集し、
        必要に応じて運用設定へマージする。
        """
        return self.model_copy(deep=True)


# デフォルトの設定ファイル名
DEFAULT_CONFIG_FILENAME = "config.json"


def get_default_config_path(base_dir: Optional[Path] = None) -> Path:
    """
    デフォルトの設定ファイルパスを取得
    
    Args:
        base_dir: ベースディレクトリ（省略時はカレントディレクトリ）
        
    Returns:
        設定ファイルのPath
    """
    if base_dir is None:
        base_dir = Path.cwd()
    return base_dir / DEFAULT_CONFIG_FILENAME
