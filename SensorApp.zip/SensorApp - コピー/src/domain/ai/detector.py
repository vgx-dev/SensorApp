"""
異常検知モジュール (Version 3.0)

IF (Isolation Forest), AE (AutoEncoder), LSTM残差を用いた異常スコア算出。
Streamlit非依存の純粋なPythonクラス。
運用モード・研究モードで完全に同一のロジックを使用。

Note:
    このモジュールは st.session_state に依存せず、
    必要な状態やモデルは引数で受け取る設計。
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
import numpy as np
import pandas as pd

from ..entities.analysis import AnalysisResult, ScoreComponent
from ...config.settings import AIParams


@dataclass
class TrainedModels:
    """
    学習済みモデルのコンテナ
    
    各モデル（IF/AE/LSTM等）とスケーラーを保持。
    """
    
    isolation_forest: Any = None
    autoencoder: Any = None
    lstm_model: Any = None
    scaler: Any = None
    
    # キャリブレーション情報（スコア正規化用）
    calibration: Dict[str, Dict[str, float]] = field(default_factory=dict)
    
    # 学習時のメタ情報
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def is_trained(self) -> bool:
        """少なくとも1つのモデルが学習済みか"""
        return any([
            self.isolation_forest is not None,
            self.autoencoder is not None,
            self.lstm_model is not None
        ])


class AnomalyDetector:
    """
    異常検知クラス
    
    IF (Isolation Forest), AE (AutoEncoder), LSTM残差を組み合わせて
    時系列データの異常スコアを算出する。
    
    Usage:
        # 研究モード: fitしてからscore
        params = AIParams()
        detector = AnomalyDetector(params)
        models = detector.fit(training_data)
        result = detector.score(current_data, models)
        
        # 運用モード: 事前学習済みモデルでscore
        result = detector.score(current_data, loaded_models)
    """
    
    def __init__(self, params: Optional[AIParams] = None):
        """
        初期化
        
        Args:
            params: AIパラメータ。Noneの場合はデフォルト値を使用
        """
        self.params = params or AIParams()
    
    def fit(
        self,
        data: pd.DataFrame,
        value_columns: Optional[List[str]] = None,
        random_state: int = 42
    ) -> TrainedModels:
        """
        モデルを学習
        
        研究モードやバッチ学習で使用。
        
        Args:
            data: 学習用データ（正常データを想定）
            value_columns: 使用する列名リスト
            random_state: 乱数シード（再現性用）
            
        Returns:
            TrainedModels: 学習済みモデル
        """
        from sklearn.ensemble import IsolationForest
        from sklearn.preprocessing import StandardScaler
        
        # 値列の取得
        if value_columns is None:
            value_columns = data.select_dtypes(include=['number']).columns.tolist()
        
        X = data[value_columns].fillna(0).values.astype(float)
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        
        if len(X) < 10:
            return TrainedModels(metadata={"error": "insufficient_data"})
        
        # スケーラー
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Isolation Forest
        if_model = IsolationForest(
            n_estimators=self.params.if_n_estimators,
            contamination=self.params.if_contamination,
            random_state=random_state
        )
        if_model.fit(X_scaled)
        
        # AutoEncoder（オプション - TensorFlow依存）
        ae_model = self._fit_autoencoder(X_scaled, random_state)
        
        # キャリブレーション情報の計算
        if_scores = -if_model.decision_function(X_scaled)
        calibration = {
            "if": self._compute_calibration(if_scores)
        }
        
        if ae_model is not None:
            ae_scores = self._compute_ae_scores(ae_model, X_scaled)
            calibration["ae"] = self._compute_calibration(ae_scores)
        
        return TrainedModels(
            isolation_forest=if_model,
            autoencoder=ae_model,
            scaler=scaler,
            calibration=calibration,
            metadata={
                "trained_at": datetime.now().isoformat(),
                "n_samples": len(X),
                "n_features": X.shape[1],
                "random_state": random_state
            }
        )
    
    def score(
        self,
        data: pd.DataFrame,
        models: TrainedModels,
        value_columns: Optional[List[str]] = None,
        sensor_id: str = "unknown"
    ) -> AnalysisResult:
        """
        異常スコアを算出
        
        Args:
            data: 評価対象データ
            models: 学習済みモデル
            value_columns: 使用する列名リスト
            sensor_id: センサID
            
        Returns:
            AnalysisResult: 分析結果
        """
        # データ準備
        if value_columns is None:
            value_columns = data.select_dtypes(include=['number']).columns.tolist()
        
        X = data[value_columns].fillna(0).values.astype(float)
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        
        n = len(X)
        if n == 0 or not models.is_trained:
            return self._empty_result(sensor_id, n)
        
        # スケーリング
        if models.scaler is not None:
            X_scaled = models.scaler.transform(X)
        else:
            X_scaled = X
        
        components = []
        
        # Isolation Forest スコア
        if models.isolation_forest is not None:
            if_raw = -models.isolation_forest.decision_function(X_scaled)
            if_norm = self._normalize_scores(if_raw, models.calibration.get("if"))
            components.append(ScoreComponent(
                model_name="IF",
                raw_scores=if_raw,
                normalized_scores=if_norm,
                weight=0.5  # IFの重要性を高める（旧0.4）
            ))
        
        # AutoEncoder スコア
        if models.autoencoder is not None:
            ae_raw = self._compute_ae_scores(models.autoencoder, X_scaled)
            ae_norm = self._normalize_scores(ae_raw, models.calibration.get("ae"))
            components.append(ScoreComponent(
                model_name="AE",
                raw_scores=ae_raw,
                normalized_scores=ae_norm,
                weight=0.5  # AEの重要性も高める（旧0.3）
            ))
        
        # LSTM残差スコア（重みが0より大きい場合のみ）
        if self.params.weight_lstm > 0:
            lstm_raw = self._compute_residual_scores(X)
            lstm_norm = self._normalize_scores(lstm_raw)
            components.append(ScoreComponent(
                model_name="LSTM",
                raw_scores=lstm_raw,
                normalized_scores=lstm_norm,
                weight=self.params.weight_lstm
            ))
        
        # スコア統合（ボーナスなし）
        integrated_raw = self._integrate_scores(components, apply_bonus=False)
        
        # 動的閾値を計算（ボーナス適用前のスコアで計算）
        # Note: ボーナス適用後に閾値を計算すると、スコアと閾値が同時に上昇し効果が相殺される
        dynamic_threshold = self._compute_dynamic_threshold(integrated_raw)
        
        # 連続性ボーナス適用（閾値計算後）
        integrated = self._apply_continuity_bonus(integrated_raw)
        
        return AnalysisResult(
            sensor_id=sensor_id,
            integrated_scores=integrated,
            components=components,
            threshold=dynamic_threshold,
            metadata={
                "n_samples": n,
                "n_components": len(components)
            }
        )
    
    def _fit_autoencoder(
        self,
        X: np.ndarray,
        random_state: int
    ) -> Optional[Any]:
        """AutoEncoderを学習（TensorFlow利用可能時のみ）"""
        try:
            import tensorflow as tf
            from tensorflow import keras
            from tensorflow.keras import layers
            
            tf.random.set_seed(random_state)
            
            inp_dim = X.shape[1]
            
            model = keras.Sequential([
                layers.Input(shape=(inp_dim,)),
                layers.Dense(16, activation="relu"),
                layers.Dense(8, activation="relu"),
                layers.Dense(16, activation="relu"),
                layers.Dense(inp_dim),
            ])
            model.compile(optimizer="adam", loss="mse")
            
            # 学習（サイレントモード）
            model.fit(
                X, X,
                epochs=self.params.ae_epochs,
                batch_size=self.params.ae_batch_size,
                verbose=0,
                validation_split=0.1
            )
            
            return model
            
        except ImportError:
            # TensorFlowがない場合はNone
            return None
        except Exception:
            return None
    
    def _compute_ae_scores(
        self,
        ae_model: Any,
        X: np.ndarray
    ) -> np.ndarray:
        """AutoEncoderの再構成誤差を計算"""
        try:
            reconstructed = ae_model.predict(X, verbose=0)
            mse = np.mean((X - reconstructed) ** 2, axis=1)
            return mse
        except Exception:
            return np.full(len(X), np.nan)
    
    def _compute_residual_scores(self, X: np.ndarray) -> np.ndarray:
        """
        残差スコアを計算（簡易LSTM代替）
        
        過去の値からの予測残差を使用。
        """
        n = len(X)
        if n < 3:
            return np.zeros(n)
        
        # 各列について残差を計算
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        
        residuals = np.zeros(n)
        
        for col in range(X.shape[1]):
            values = X[:, col]
            # 1ステップ前との差分を残差とする（簡易版）
            diff = np.abs(np.diff(values, prepend=values[0]))
            residuals += diff
        
        return residuals / X.shape[1]
    
    def _compute_calibration(
        self,
        scores: np.ndarray,
        p_low: float = 5.0,
        p_high: float = 95.0
    ) -> Dict[str, float]:
        """キャリブレーション情報を計算"""
        valid = scores[np.isfinite(scores)]
        if len(valid) == 0:
            return {"lo": 0.0, "hi": 1.0}
        
        lo = float(np.percentile(valid, p_low))
        hi = float(np.percentile(valid, p_high))
        
        return {"lo": lo, "hi": hi}
    
    def _normalize_scores(
        self,
        scores: np.ndarray,
        calibration: Optional[Dict[str, float]] = None
    ) -> np.ndarray:
        """
        スコアを0〜1に正規化
        
        app.py の build_ai_scores_unified_v1 内の _norm 関数と同等。
        """
        scores = np.asarray(scores, dtype=float)
        out = np.full_like(scores, np.nan, dtype=float)
        mask = np.isfinite(scores)
        
        if not mask.any():
            return out
        
        if calibration is not None:
            lo = calibration.get("lo", 0.0)
            hi = calibration.get("hi", 1.0)
        else:
            try:
                lo, hi = np.nanpercentile(scores[mask], [5, 95])
            except Exception:
                return out
        
        if not np.isfinite(lo) or not np.isfinite(hi) or (hi - lo) < 1e-9:
            return out
        
        out[mask] = np.clip((scores[mask] - lo) / (hi - lo), 0.0, 1.0)
        return out
    
    def _compute_dynamic_threshold(
        self,
        scores: np.ndarray
    ) -> float:
        """
        データ分布に基づく動的閾値を計算
        
        Args:
            scores: 統合スコア
            
        Returns:
            動的閾値（0.0〜1.0）
        """
        percentile = self.params.threshold_percentile
        valid = scores[np.isfinite(scores)]
        if len(valid) < 10:
            return 0.5  # データ不足時はデフォルト
        
        threshold = float(np.percentile(valid, percentile))
        
        # 閾値が極端に低い/高い場合は調整
        threshold = np.clip(threshold, 0.3, 0.7)
        
        return threshold
    
    def _apply_continuity_bonus(
        self,
        scores: np.ndarray,
        window: int = 3,
        bonus_factor: float = 1.3  # 1.2→1.3に強化
    ) -> np.ndarray:
        """
        連続する高スコア区間にボーナスを付与
        
        Spike/Shiftのような局所的異常パターンの検出精度を向上させる。
        
        Args:
            scores: 統合スコア
            window: 連続判定のウィンドウサイズ
            bonus_factor: ボーナス倍率（1.2 = 20%増）
            
        Returns:
            ボーナス適用後のスコア
        """
        result = scores.copy()
        
        # スコア>0.3を「予備的に高い」と判定
        high_mask = scores > 0.3
        
        # 連続window点以上高スコアの区間にボーナス
        for i in range(len(scores) - window + 1):
            if np.all(high_mask[i:i+window]):
                result[i:i+window] *= bonus_factor
        
        return np.clip(result, 0.0, 1.0)
    
    def _integrate_scores(
        self,
        components: List[ScoreComponent],
        apply_bonus: bool = True
    ) -> np.ndarray:
        """
        複数モデルのスコアを統合
        
        app.py の build_ai_scores_unified_v1 と同等のロジック。
        NaNは「評価不能」として保持し、有効なモデルだけで重みを再正規化。
        
        Args:
            components: スコアコンポーネントのリスト
            apply_bonus: 連続性ボーナスを適用するか（デフォルトTrue）
        """
        if not components:
            return np.array([])
        
        # 最小長に揃える
        n = min(len(c.normalized_scores) for c in components)
        if n == 0:
            return np.array([])
        
        # スコアと重みを行列化
        X = np.vstack([c.normalized_scores[-n:] for c in components]).T
        W = np.array([c.weight for c in components])
        
        valid = np.isfinite(X)
        
        numerator = np.sum(np.where(valid, X * W, 0.0), axis=1)
        denom = np.sum(np.where(valid, W, 0.0), axis=1)
        
        # 全無効の場合はNaN
        out = np.full_like(numerator, np.nan, dtype=float)
        
        integrated = np.divide(
            numerator,
            denom,
            out=out,
            where=(denom > 0.0),
        )
        
        # クリップ（NaNはそのまま）
        integrated = np.where(
            np.isfinite(integrated),
            np.clip(integrated, 0.0, 1.0),
            integrated
        )
        
        # 連続性ボーナス適用（オプション）
        if apply_bonus:
            integrated = self._apply_continuity_bonus(integrated)
        
        return integrated
    
    def _empty_result(self, sensor_id: str, n: int = 0) -> AnalysisResult:
        """空の分析結果を返す"""
        return AnalysisResult(
            sensor_id=sensor_id,
            integrated_scores=np.zeros(n) if n > 0 else np.array([]),
            metadata={"error": "no_models_or_data"}
        )
