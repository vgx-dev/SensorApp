"""
未来予測モジュール (Version 3.0)

時系列データのトレンド分析と将来予測を行う。
Streamlit非依存の純粋なPythonクラス。
運用モード・研究モードで完全に同一のロジックを使用。
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional, Tuple
import numpy as np
import pandas as pd

from ..entities.analysis import FutureForecast, TrendComponents
from ...config.settings import ForecastParams


class Forecaster:
    """
    未来予測クラス
    
    時系列データのトレンド成分と変動成分を分解し、
    将来の劣化進行と不確実性（信頼区間）を予測する。
    
    Usage:
        params = ForecastParams(forecast_days=30, confidence_level=0.95)
        forecaster = Forecaster(params)
        result = forecaster.predict(history_df, time_col="timestamp", value_col="RMS")
    """
    
    def __init__(self, params: Optional[ForecastParams] = None):
        """
        初期化
        
        Args:
            params: 予測パラメータ。Noneの場合はデフォルト値を使用
        """
        self.params = params or ForecastParams()
    
    def predict(
        self,
        history: pd.DataFrame,
        time_col: str = "timestamp",
        value_col: str = "RMS",
        sensor_id: str = "unknown",
        trend_components: Optional[TrendComponents] = None,
        current_anomaly_score: Optional[float] = None
    ) -> FutureForecast:
        """
        未来予測を実行
        
        Args:
            history: 過去の時系列データ
            time_col: 時刻列名
            value_col: 値列名
            sensor_id: センサID
            trend_components: 事前計算済みのトレンド成分（オプション）
                Noneの場合は内部で計算する
            current_anomaly_score: 現在の異常スコア（0.0~1.0、オプション）
                Noneの場合は信頼区間を通常通り計算
                指定された場合は信頼区間を動的に調整
            
        Returns:
            FutureForecast: 予測結果
        """
        # データ検証
        if history.empty or value_col not in history.columns:
            return self._empty_forecast(
                sensor_id, 
                reason_code="NOT_ENOUGH_DATA",
                reason_message="データが空または値列が見つかりません"
            )
        
        # 値列を取得
        values = history[value_col].dropna().values.astype(float)
        if len(values) < 10:
            return self._empty_forecast(
                sensor_id,
                reason_code="NOT_ENOUGH_DATA",
                reason_message=f"データ蓄積中（現在{len(values)}/10点）"
            )
        
        # 時刻情報の取得
        if time_col in history.columns:
            times = pd.to_datetime(history[time_col])
            base_end_date = times.iloc[-1]
        else:
            base_end_date = datetime.now()
        
        # トレンド分解（事前計算済みの場合はスキップ）
        if trend_components is None:
            trend_components = self._decompose_trend(values)
        
        # 将来予測
        forecast_values, lower, upper = self._extrapolate(
            values,
            trend_components,
            self.params.forecast_days,
            current_anomaly_score
        )
        
        # 予測日付の生成
        forecast_dates = self._generate_forecast_dates(
            base_end_date,
            self.params.forecast_days
        )
        
        # メッセージ生成（Phase 3）
        reason_message = ""
        if current_anomaly_score is not None and current_anomaly_score > 0.7:
            reason_message = (
                "⚠️ データに変動傾向があり、予測の不確実性が増大しています"
            )
        
        return FutureForecast(
            sensor_id=sensor_id,
            base_end_date=base_end_date,
            forecast_dates=forecast_dates,
            forecast_values=forecast_values,
            lower_bound=lower,
            upper_bound=upper,
            confidence_level=self.params.confidence_level,
            forecast_days=self.params.forecast_days,
            trend_slope=trend_components.slope,
            trend_intercept=trend_components.intercept,
            reason_code="OK",
            reason_message=reason_message,
            metadata={
                "input_length": len(values),
                "trend_window": self.params.trend_window
            }
        )
    
    def _decompose_trend(self, values: np.ndarray) -> TrendComponents:
        """
        トレンド成分を分解
        
        移動平均によるトレンド抽出と線形回帰による傾き計算。
        """
        n = len(values)
        window = min(self.params.trend_window, n // 3)
        if window < 1:
            window = 1
        
        # 移動平均でトレンド抽出
        trend = self._moving_average(values, window)
        
        # 季節成分（簡易版：トレンド除去後の周期平均）
        detrended = values - trend
        period = min(self.params.decompose_period, n // 2)
        if period > 1:
            seasonal = self._extract_seasonal(detrended, period)
        else:
            seasonal = np.zeros_like(values)
        
        # 残差
        residual = values - trend - seasonal
        
        # 線形回帰でトレンドの傾き
        x = np.arange(n)
        slope, intercept = self._linear_regression(x, trend)
        
        return TrendComponents(
            trend=trend,
            seasonal=seasonal,
            residual=residual,
            slope=slope,
            intercept=intercept
        )
    
    def _extrapolate(
        self,
        values: np.ndarray,
        components: TrendComponents,
        forecast_days: int,
        current_anomaly_score: Optional[float] = None
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        将来値を外挿
        
        線形トレンドの延長と信頼区間を計算。
        use_adaptive_forecast=Trueの場合、直近の加速度を考慮した適応的予測を行う。
        
        Args:
            current_anomaly_score: 異常スコア（Phase 3）
                Noneまたは0.0の場合は通常の信頼区間
                > 0.0の場合は信頼区間を動的に拡大
        """
        if self.params.use_adaptive_forecast:
            return self._extrapolate_adaptive(values, components, forecast_days, current_anomaly_score)
        else:
            return self._extrapolate_linear(values, components, forecast_days, current_anomaly_score)
    
    def _calculate_margin(
        self,
        forecast_days: int,
        residual_std: float,
        current_anomaly_score: Optional[float] = None
    ) -> np.ndarray:
        """
        信頼区間マージンを計算（Strategy Pattern）
        
        use_absolute_margin=Trueの場合は絶対値ベース（振動値専用）、
        Falseの場合は相対値ベース（従来方式）で計算。
        
        Args:
            forecast_days: 予測日数
            residual_std: 残差標準偏差 [m/s²]
            current_anomaly_score: 現在の異常スコア（0.0〜1.0）
            
        Returns:
            各予測日における信頼区間マージン [m/s²]
            
        Note:
            絶対値ベース: margin = base × (1 + √(t/30))^exponent
            相対値ベース: margin = z × std × (1 + (t^0.4 - 1) × sensitivity)
        """
        from scipy import stats
        z_score = stats.norm.ppf((1 + self.params.confidence_level) / 2)
        
        if self.params.use_absolute_margin:
            # ★ S級: 絶対値ベースマージン（振動値専用）
            days = np.arange(1, forecast_days + 1)
            # 基準マージン × (1 + √(t/30))^exponent
            # 30日で約1.5倍、365日で約4.5倍（exponent=0.5の場合）
            growth_factor = 1.0 + np.power(days / 30.0, self.params.margin_growth_exponent)
            margin = self.params.base_margin_mps2 * growth_factor
        else:
            # 従来の相対値ベースマージン
            base_growth = np.power(np.arange(1, forecast_days + 1), 0.4)
            uncertainty_growth = 1.0 + (base_growth - 1.0)
            margin = z_score * residual_std * uncertainty_growth
        
        # 異常スコアに基づく動的調整 (Phase 3)
        if current_anomaly_score is not None and current_anomaly_score > 0.0:
            adjustment_factor = 1.0 + current_anomaly_score
            margin = margin * adjustment_factor
        
        return margin
    
    def _extrapolate_linear(
        self,
        values: np.ndarray,
        components: TrendComponents,
        forecast_days: int,
        current_anomaly_score: Optional[float] = None
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """従来の線形外挿（互換性維持用）"""
        n = len(values)
        
        # 将来のx値
        future_x = np.arange(n, n + forecast_days)
        
        # トレンド外挿 (Phase 6b: 勾配不感帯の導入)
        # 傾きがごくわずか（例: 0.05% / day以下）なら、トレンドなし（水平）とみなす
        intercept_val = max(abs(components.intercept), 1e-6)
        slope_ratio = abs(components.slope) / intercept_val
        
        # 閾値: 0.0005 (0.05%)
        effective_slope = components.slope if slope_ratio > 0.0005 else 0.0
        
        # ★ S級修正: 下降トレンドの抑制（物理的妥当性担保）
        # 振動値の減少（改善）は予知保全において保守的に「現状維持」とみなす
        if effective_slope < 0:
            effective_slope = 0.0
        
        forecast_values = effective_slope * future_x + components.intercept
        
        # ★ S級: 統一マージン計算
        residual_std = np.nanstd(components.residual)
        if not np.isfinite(residual_std) or residual_std < 1e-10:
            residual_std = np.nanstd(values) * 0.1
        
        margin = self._calculate_margin(forecast_days, residual_std, current_anomaly_score)
        
        lower = forecast_values - margin
        upper = forecast_values + margin
        
        return forecast_values, lower, upper
    
    def _extrapolate_adaptive(
        self,
        values: np.ndarray,
        components: TrendComponents,
        forecast_days: int,
        current_anomaly_score: Optional[float] = None
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        適応的外挿（S+級: 急激な変化に2次曲線でフィット）
        
        Design Decision:
            - 全期間の線形トレンドをベースラインとする
            - 直近ウィンドウで2次回帰を行い、加速度成分を抽出
            - 加速度が有意な場合のみ補正を適用（recent_weightで調整）
        """
        n = len(values)
        
        # ベースライン: 線形外挿 (Phase 6b: 勾配不感帯の導入)
        future_x = np.arange(n, n + forecast_days)
        intercept_val = max(abs(components.intercept), 1e-6)
        slope_ratio = abs(components.slope) / intercept_val
        
        effective_slope = components.slope if slope_ratio > 0.0005 else 0.0
        
        # ★ S級修正: ベースラインの下降トレンド抑制
        if effective_slope < 0:
            effective_slope = 0.0
        
        base_forecast = effective_slope * future_x + components.intercept
        
        # 直近ウィンドウで2次回帰
        recent_window = max(int(n * self.params.recent_window_ratio), 10)
        recent_values = values[-recent_window:]
        recent_x = np.arange(len(recent_values))
        
        # 2次回帰 (ax^2 + bx + c)
        try:
            coeffs = np.polyfit(recent_x, recent_values, deg=2)
            accel = coeffs[0]  # 2次係数 = 加速度
        except Exception:
            # 回帰失敗時は線形に戻す
            accel = 0.0
        
        # ★ S級修正: 加速度の物理的妥当性チェック
        # 1. 負の加速度（減少加速）は無視
        if accel < 0:
            accel = 0.0
            
        # 2. 符号整合性チェック（上昇トレンド中の減少加速など）は上記1で包含されるが、
        #    正の加速度かつベースライン上昇の場合のみ許容するなど、より厳密に制御可能
        
        if abs(accel) > 1e-6:  # 有意な正の加速度がある場合のみ
            future_offset = future_x - (n - recent_window)
            accel_correction = accel * (future_offset ** 2)
            forecast_values = base_forecast + self.params.recent_weight * accel_correction
        else:
            forecast_values = base_forecast
        
        # ★ S級: 統一マージン計算
        residual_std = np.nanstd(components.residual)
        if not np.isfinite(residual_std) or residual_std < 1e-10:
            residual_std = np.nanstd(values) * 0.1
        
        margin = self._calculate_margin(forecast_days, residual_std, current_anomaly_score)
        
        lower = forecast_values - margin
        upper = forecast_values + margin
        
        # ★ S級修正: 物理的制約 - RMSは非負
        # 振動値（RMS）は物理的に0未満になり得ない
        forecast_values = np.maximum(forecast_values, 0.0)
        lower = np.maximum(lower, 0.0)
        # upper は制約不要（上限なし）
        
        return forecast_values, lower, upper
    
    def _moving_average(self, values: np.ndarray, window: int) -> np.ndarray:
        """移動平均を計算"""
        if window <= 1:
            return values.copy()
        
        # パディングして端を処理
        padded = np.pad(values, (window // 2, window - 1 - window // 2), mode='edge')
        cumsum = np.cumsum(padded)
        cumsum[window:] = cumsum[window:] - cumsum[:-window]
        return cumsum[window - 1:] / window
    
    def _extract_seasonal(self, detrended: np.ndarray, period: int) -> np.ndarray:
        """季節成分を抽出（簡易版）"""
        n = len(detrended)
        seasonal = np.zeros(n)
        
        # 各周期位置の平均を計算
        for i in range(period):
            indices = np.arange(i, n, period)
            seasonal[indices] = np.nanmean(detrended[indices])
        
        return seasonal
    
    def _linear_regression(
        self,
        x: np.ndarray,
        y: np.ndarray
    ) -> Tuple[float, float]:
        """単純線形回帰"""
        mask = np.isfinite(y)
        if not mask.any():
            return 0.0, 0.0
        
        x_valid = x[mask]
        y_valid = y[mask]
        
        n = len(x_valid)
        if n < 2:
            return 0.0, float(y_valid[0]) if n == 1 else 0.0
        
        x_mean = np.mean(x_valid)
        y_mean = np.mean(y_valid)
        
        numerator = np.sum((x_valid - x_mean) * (y_valid - y_mean))
        denominator = np.sum((x_valid - x_mean) ** 2)
        
        if abs(denominator) < 1e-10:
            return 0.0, y_mean
        
        slope = numerator / denominator
        intercept = y_mean - slope * x_mean
        
        return float(slope), float(intercept)
    
    def _generate_forecast_dates(
        self,
        base_date: datetime,
        days: int
    ) -> np.ndarray:
        """予測日付を生成"""
        if isinstance(base_date, pd.Timestamp):
            base_date = base_date.to_pydatetime()
        
        dates = []
        for i in range(1, days + 1):
            dates.append(base_date + timedelta(days=i))
        
        return np.array(dates)
    
    def _empty_forecast(
        self, 
        sensor_id: str,
        reason_code: str = "NOT_ENOUGH_DATA",
        reason_message: str = ""
    ) -> FutureForecast:
        """空の予測結果を返す（理由コード付き）"""
        return FutureForecast(
            sensor_id=sensor_id,
            forecast_days=self.params.forecast_days,
            confidence_level=self.params.confidence_level,
            reason_code=reason_code,
            reason_message=reason_message or self._get_default_message(reason_code),
            metadata={"error": reason_code.lower()}
        )
    
    def _get_default_message(self, reason_code: str) -> str:
        """理由コードに対応するデフォルトメッセージを取得"""
        messages = {
            "NOT_ENOUGH_DATA": "データ蓄積中（最低10点必要）",
            "LOW_VARIANCE": "データ変動が少ないため予測不能",
            "NO_MOUNT": "マウント情報がありません",
            "ERROR": "予測処理中にエラーが発生",
            "OK": ""
        }
        return messages.get(reason_code, "")
