"""
稼働状態フィルタモジュール (Version 1.0)

GMMを用いて稼働/停止状態を自動判別し、稼働データのみを抽出する。
Streamlit非依存の純粋なPythonクラス。

論文貢献:
    固定閾値ではなく、設備・センサ個体差に応じて動的にクラスタリングすることで、
    パラメータ調整レスで多種多様な設備に対応可能。
"""

from dataclasses import dataclass, field
from typing import Optional, Literal, List, Dict, Any
import numpy as np


@dataclass
class FilterResult:
    """稼働フィルタ結果"""
    
    filtered_indices: np.ndarray
    """稼働状態と判定されたインデックス配列"""
    
    mode: Literal["running", "stopped", "mixed", "insufficient", "uniform"]
    """判定結果モード:
        - running: 全データが稼働状態
        - stopped: 全データが停止状態
        - mixed: 稼働/停止の混在
        - insufficient: データ不足でフィルタ不可
        - uniform: 分散が小さく分離不可
    """
    
    reason_code: str = ""
    """詳細理由コード"""
    
    reason_message: str = ""
    """ユーザー向けメッセージ"""
    
    cluster_info: Dict[str, Any] = field(default_factory=dict)
    """GMMクラスタ情報（デバッグ・論文検証用）"""


class OperationFilter:
    """
    稼働状態フィルタ
    
    GMMを用いてRMS値を稼働/停止クラスタに分類し、
    稼働データのインデックスのみを抽出する。
    
    Usage:
        filter = OperationFilter()
        result = filter.filter(rms_values)
        
        if result.mode == "mixed":
            # 稼働データのみ使用
            running_data = original_df.iloc[result.filtered_indices]
        else:
            # 全データ使用
            running_data = original_df
    """
    
    # ハイパーパラメータ（論文用に固定）
    MIN_POINTS: int = 20
    """フィルタ適用に必要な最小データ点数"""
    
    MIN_STD: float = 0.01
    """分散がこれ以下なら単一クラスタ扱い"""
    
    CLUSTER_DIFF_THRESHOLD: float = 0.03
    """クラスタ平均値の差がこれ以下なら分離不可"""
    
    MIN_CLUSTER_RATIO: float = 0.2
    """稼働クラスタの最小比率（これ以下ならフォールバック）"""
    
    RANDOM_STATE: int = 42
    """GMMの乱数シード（再現性用）"""
    
    def __init__(
        self,
        min_points: int = 20,
        min_std: float = 0.01,
        cluster_diff_threshold: float = 0.03,
        random_state: int = 42
    ):
        """
        初期化
        
        Args:
            min_points: フィルタ適用に必要な最小データ点数
            min_std: 分散がこれ以下なら単一クラスタ扱い
            cluster_diff_threshold: クラスタ平均値の差がこれ以下なら分離不可
            random_state: GMMの乱数シード
        """
        self.min_points = min_points
        self.min_std = min_std
        self.cluster_diff_threshold = cluster_diff_threshold
        self.random_state = random_state
    
    def filter(self, rms_values: np.ndarray) -> FilterResult:
        """
        稼働データのみを抽出
        
        GMMでRMS値をクラスタリングし、平均値が高いクラスタを
        「稼働状態」と判定してそのインデックスを返す。
        
        Args:
            rms_values: RMS値の1次元配列
        
        Returns:
            FilterResult: フィルタ結果
        """
        rms_values = np.asarray(rms_values, dtype=float)
        n = len(rms_values)
        all_indices = np.arange(n)
        
        # ケース0: データ点数不足
        if n < self.min_points:
            return FilterResult(
                filtered_indices=all_indices,
                mode="insufficient",
                reason_code="NOT_ENOUGH_DATA",
                reason_message=f"データ点数不足（{n}/{self.min_points}点）のため、全データを使用",
                cluster_info={"n_points": n, "threshold": self.min_points}
            )
        
        # ケース1: 分散が小さすぎる（停止中 or 完全定常）
        std = float(np.std(rms_values))
        if std < self.min_std:
            return FilterResult(
                filtered_indices=all_indices,
                mode="uniform",
                reason_code="LOW_VARIANCE",
                reason_message=f"データ変動が少ない（σ={std:.4f}）のため、全データを使用",
                cluster_info={"std": std, "threshold": self.min_std}
            )
        
        # GMMクラスタリング
        try:
            return self._apply_gmm(rms_values, all_indices)
        except Exception as e:
            # フォールバック：全データ使用
            return FilterResult(
                filtered_indices=all_indices,
                mode="running",
                reason_code="GMM_ERROR",
                reason_message=f"GMMエラー: {str(e)}. 全データを使用",
                cluster_info={"error": str(e)}
            )
    
    def _apply_gmm(
        self, 
        rms_values: np.ndarray, 
        all_indices: np.ndarray
    ) -> FilterResult:
        """GMMクラスタリングを適用"""
        from sklearn.mixture import GaussianMixture
        
        X = rms_values.reshape(-1, 1)
        n = len(rms_values)
        
        # クラスタ数候補（1〜3）でBICが最小のモデルを選択
        k_candidates = [1, 2, 3]
        bic_list = []
        models = []
        
        for k in k_candidates:
            gmm = GaussianMixture(
                n_components=k,
                covariance_type="full",
                random_state=self.random_state,
                reg_covar=1e-6
            )
            gmm.fit(X)
            bic_list.append(gmm.bic(X))
            models.append(gmm)
        
        best_idx = int(np.argmin(bic_list))
        best_model = models[best_idx]
        labels = best_model.predict(X)
        means = best_model.means_.flatten()
        
        cluster_info = {
            "n_clusters": len(means),
            "cluster_means": [float(m) for m in means],
            "bic_values": [float(b) for b in bic_list],
            "selected_k": k_candidates[best_idx]
        }
        
        # ケース2: クラスタ平均値の差が小さすぎる
        if len(means) >= 2 and (np.max(means) - np.min(means)) < self.cluster_diff_threshold:
            cluster_info["reason"] = "cluster_diff_too_small"
            return FilterResult(
                filtered_indices=all_indices,
                mode="uniform",
                reason_code="CLUSTERS_SIMILAR",
                reason_message="クラスタ間の差が小さいため、全データを使用",
                cluster_info=cluster_info
            )
        
        # 稼働クラスタ = 平均値が最も高いクラスタ
        run_cluster = int(np.argmax(means))
        run_indices = np.where(labels == run_cluster)[0]
        
        cluster_info["selected_cluster"] = run_cluster
        cluster_info["run_indices_len"] = len(run_indices)
        
        # ケース3: 稼働クラスタが小さすぎる
        min_size = max(10, int(n * self.MIN_CLUSTER_RATIO))
        if len(run_indices) < min_size:
            cluster_info["reason"] = "run_cluster_too_small"
            return FilterResult(
                filtered_indices=all_indices,
                mode="stopped",
                reason_code="RUN_CLUSTER_SMALL",
                reason_message=f"稼働データが少ない（{len(run_indices)}/{min_size}点）のため、全データを使用",
                cluster_info=cluster_info
            )
        
        # 正常な稼働/停止分離
        cluster_info["reason"] = "successfully_separated"
        return FilterResult(
            filtered_indices=run_indices,
            mode="mixed",
            reason_code="OK",
            reason_message=f"稼働データ {len(run_indices)}/{n} 点を抽出",
            cluster_info=cluster_info
        )
    
    def compare_with_threshold(
        self, 
        rms_values: np.ndarray, 
        threshold: float = 0.1
    ) -> Dict[str, Any]:
        """
        固定閾値との比較（論文Ablation Study用）
        
        Args:
            rms_values: RMS値の1次元配列
            threshold: 固定閾値
        
        Returns:
            比較結果:
                - gmm_result: GMMフィルタ結果
                - threshold_indices: 閾値ベースで抽出されたインデックス
                - overlap_ratio: 両手法の重複率
        """
        gmm_result = self.filter(rms_values)
        
        # 固定閾値ベースの抽出
        threshold_indices = np.where(rms_values >= threshold)[0]
        
        # 重複率の計算
        gmm_set = set(gmm_result.filtered_indices.tolist())
        threshold_set = set(threshold_indices.tolist())
        
        if len(gmm_set) > 0 and len(threshold_set) > 0:
            overlap = len(gmm_set & threshold_set)
            union = len(gmm_set | threshold_set)
            overlap_ratio = overlap / union if union > 0 else 0.0
        else:
            overlap_ratio = 0.0
        
        return {
            "gmm_result": gmm_result,
            "threshold_indices": threshold_indices,
            "gmm_count": len(gmm_result.filtered_indices),
            "threshold_count": len(threshold_indices),
            "overlap_ratio": overlap_ratio,
            "threshold_used": threshold
        }
