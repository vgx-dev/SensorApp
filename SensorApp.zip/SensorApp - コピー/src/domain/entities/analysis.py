"""
分析結果エンティティモジュール (Version 3.0)

AI推論結果と未来予測結果を保持するデータクラス。
Streamlit非依存の純粋なPythonデータ構造。
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any, List
import numpy as np
import pandas as pd


@dataclass
class ScoreComponent:
    """
    個別モデルのスコア成分
    
    IF/AE/LSTMなど各モデルの生スコアと正規化スコアを保持。
    """
    
    model_name: str  # "IF", "AE", "LSTM" など
    raw_scores: np.ndarray
    normalized_scores: np.ndarray
    weight: float = 1.0
    
    @property
    def length(self) -> int:
        return len(self.raw_scores)
    
    @property
    def has_valid_scores(self) -> bool:
        """有効なスコアが存在するか"""
        return np.any(np.isfinite(self.normalized_scores))


@dataclass
class AnalysisResult:
    """
    AI異常検知の分析結果
    
    複数モデルの統合スコアと各成分スコアを保持する。
    運用モード・研究モードで同一の構造を使用。
    """
    
    sensor_id: str
    timestamp: datetime = field(default_factory=datetime.now)
    
    # 統合スコア（0.0〜1.0）
    integrated_scores: np.ndarray = field(default_factory=lambda: np.array([]))
    
    # 各モデルのスコア成分
    components: List[ScoreComponent] = field(default_factory=list)
    
    # 閾値情報
    threshold: float = 0.5
    
    # メタ情報
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def length(self) -> int:
        """スコアの長さ"""
        return len(self.integrated_scores)
    
    @property
    def max_score(self) -> float:
        """最大スコア"""
        if len(self.integrated_scores) == 0:
            return 0.0
        valid = self.integrated_scores[np.isfinite(self.integrated_scores)]
        if len(valid) == 0:
            return 0.0
        return float(np.max(valid))
    
    @property
    def mean_score(self) -> float:
        """平均スコア"""
        if len(self.integrated_scores) == 0:
            return 0.0
        valid = self.integrated_scores[np.isfinite(self.integrated_scores)]
        if len(valid) == 0:
            return 0.0
        return float(np.mean(valid))
    
    @property
    def has_anomaly(self) -> bool:
        """閾値を超える異常があるか"""
        return self.max_score > self.threshold
    
    def get_anomaly_indices(self) -> np.ndarray:
        """異常と判定されたインデックスを取得"""
        return np.where(self.integrated_scores > self.threshold)[0]
    
    def to_dataframe(self) -> pd.DataFrame:
        """DataFrameに変換"""
        data = {"integrated_score": self.integrated_scores}
        for comp in self.components:
            data[f"{comp.model_name}_score"] = comp.normalized_scores
        return pd.DataFrame(data)


@dataclass
class FutureForecast:
    """
    未来予測結果
    
    時系列データの将来予測と信頼区間を保持する。
    
    Attributes:
        reason_code: 予測結果の理由コード
            - 'OK': 正常に予測完了
            - 'NOT_ENOUGH_DATA': データ点数不足
            - 'LOW_VARIANCE': データ変動が少ない
            - 'NO_MOUNT': マウント情報なし
            - 'ERROR': 予測処理中のエラー
        reason_message: ユーザー向けの説明メッセージ
    """
    
    sensor_id: str
    timestamp: datetime = field(default_factory=datetime.now)
    
    # 予測対象のベースデータ情報
    base_end_date: Optional[datetime] = None
    
    # 予測値
    forecast_dates: np.ndarray = field(default_factory=lambda: np.array([]))
    forecast_values: np.ndarray = field(default_factory=lambda: np.array([]))
    
    # 信頼区間
    lower_bound: np.ndarray = field(default_factory=lambda: np.array([]))
    upper_bound: np.ndarray = field(default_factory=lambda: np.array([]))
    
    # 予測パラメータ
    confidence_level: float = 0.95
    forecast_days: int = 30
    
    # トレンド情報
    trend_slope: float = 0.0  # 日あたりの変化率
    trend_intercept: float = 0.0
    
    # 予測状態（Phase 3追加）
    reason_code: str = "OK"
    reason_message: str = ""
    
    # メタ情報
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # ★ S級改善: メンテナンス推奨（Application層で生成）
    maintenance: Optional['MaintenanceRecommendation'] = None

    
    @property
    def length(self) -> int:
        """予測点数"""
        return len(self.forecast_values)
    
    @property
    def is_increasing_trend(self) -> bool:
        """上昇トレンドかどうか"""
        return self.trend_slope > 0
    
    def get_predicted_value_at(self, days_ahead: int) -> Optional[float]:
        """指定日数後の予測値を取得"""
        if days_ahead < 0 or days_ahead >= len(self.forecast_values):
            return None
        return float(self.forecast_values[days_ahead])
    
    def to_dataframe(self) -> pd.DataFrame:
        """DataFrameに変換"""
        return pd.DataFrame({
            "date": self.forecast_dates,
            "forecast": self.forecast_values,
            "lower": self.lower_bound,
            "upper": self.upper_bound
        })


@dataclass
class TrendComponents:
    """
    トレンド分解結果
    
    時系列データをトレンド・季節・残差成分に分解した結果を保持する。
    DetectorとForecasterの両方で利用可能な共通エンティティ。
    """
    
    trend: np.ndarray
    seasonal: np.ndarray
    residual: np.ndarray
    slope: float
    intercept: float


@dataclass
class MaintenanceRecommendation:
    """
    メンテナンス推奨情報（S級改善）
    
    振動値の未来予測からメンテナンス時期を推定。
    """
    
    urgency: str  # "immediate" (即対応), "scheduled" (計画的), "monitor" (監視継続)
    estimated_days: Optional[int] = None  # 推定日数（Noneの場合は特定不可）
    confidence: str = "medium"  # "high", "medium", "low"
    reasoning: str = ""  # 推奨理由（ユーザー向けメッセージ）
