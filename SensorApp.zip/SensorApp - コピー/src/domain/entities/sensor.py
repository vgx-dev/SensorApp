"""
センサエンティティモジュール (Version 3.0)

センサデータとマウント情報を保持するデータクラス。
Streamlit非依存の純粋なPythonデータ構造。
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List
import pandas as pd


@dataclass
class MountInfo:
    """
    センサのマウント情報
    
    センサが設置されている設備、装置、期間を表現する。
    """
    
    sensor_id: str
    equipment: str  # 設備名（例: "Pump-A"）
    device: str     # 装置名（例: "Motor-1"）
    mount_date: Optional[datetime] = None
    unmount_date: Optional[datetime] = None
    description: str = ""
    
    @property
    def base_key(self) -> str:
        """設備_装置のキーを生成（AIモデル保存用）"""
        return f"{self.equipment}_{self.device}"
    
    @property
    def is_active(self) -> bool:
        """現在マウント中かどうか"""
        if self.unmount_date is None:
            return True
        return datetime.now() < self.unmount_date


@dataclass
class SensorData:
    """
    センサの時系列データ
    
    センサから取得した生データとメタ情報を保持する。
    """
    
    sensor_id: str
    dataframe: pd.DataFrame
    time_column: str = "timestamp"
    value_columns: List[str] = field(default_factory=list)
    
    # メタ情報
    source_file: Optional[str] = None
    encoding: str = "utf-8"
    
    def __post_init__(self):
        """初期化後の検証"""
        if self.dataframe is None:
            self.dataframe = pd.DataFrame()
        
        # value_columnsが空の場合、数値列を自動検出
        if not self.value_columns and not self.dataframe.empty:
            numeric_cols = self.dataframe.select_dtypes(include=['number']).columns.tolist()
            if self.time_column in numeric_cols:
                numeric_cols.remove(self.time_column)
            self.value_columns = numeric_cols
    
    @property
    def length(self) -> int:
        """データ点数"""
        return len(self.dataframe)
    
    @property
    def is_empty(self) -> bool:
        """データが空かどうか"""
        return self.dataframe.empty
    
    def get_time_series(self) -> pd.Series:
        """時刻列を取得"""
        if self.time_column in self.dataframe.columns:
            return self.dataframe[self.time_column]
        return pd.Series(dtype='datetime64[ns]')
    
    def get_values(self, column: Optional[str] = None) -> pd.DataFrame:
        """
        値データを取得
        
        Args:
            column: 特定の列名。Noneの場合は全value_columns
            
        Returns:
            値データのDataFrame
        """
        if column is not None:
            if column in self.dataframe.columns:
                return self.dataframe[[column]]
            return pd.DataFrame()
        
        existing_cols = [c for c in self.value_columns if c in self.dataframe.columns]
        if existing_cols:
            return self.dataframe[existing_cols]
        return pd.DataFrame()
    
    def tail(self, n: int) -> "SensorData":
        """末尾n件のデータを取得"""
        return SensorData(
            sensor_id=self.sensor_id,
            dataframe=self.dataframe.tail(n).copy(),
            time_column=self.time_column,
            value_columns=self.value_columns.copy(),
            source_file=self.source_file,
            encoding=self.encoding
        )
