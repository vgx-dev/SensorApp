"""
マウント管理ドメインサービス (Version 3.4)

センサーのマウント履歴に対する時系列整合性チェックとコンテキスト解決を担当。
純粋関数として実装し、副作用を持たない。

DESIGN_SENSOR_CONTEXT.md 準拠:
- complete_time_chain: 時系列チェーン補完（純粋関数）
- resolve_context: 指定時刻のコンテキスト特定
"""

from datetime import datetime
from typing import Optional, Tuple
import pandas as pd

from ..entities.sensor import MountInfo


def complete_time_chain(history: pd.DataFrame) -> pd.DataFrame:
    """
    時系列チェーン補完（純粋関数・表示専用）
    
    【重要】この関数は表示用の補完処理であり、永続化には使用しない。
    元のDataFrameを変更せず、補完済みのコピーを返す。
    
    同一センサの履歴において、次のレコードのStartTimeを
    現在のレコードのEndTimeとして自動設定する。
    最新レコード（現在取付中）はEndTimeを空のままにする。
    
    使用例（推奨）:
        # 表示用のDataFrameを取得
        raw_history = mgmt_service.get_mount_history()
        display_df = complete_time_chain(raw_history)
        st.dataframe(display_df)  # ← これは表示のみ
        
        # 永続化は元のDataFrameで行う
        mgmt_service._save_mount_df()  # ← 補完前のデータを保存
    
    アンチパターン（非推奨）:
        # ❌ 誤った使い方：補完後のデータを永続化してしまう
        df = pd.read_csv("mount_history.csv")
        df = complete_time_chain(df)  # 補完
        df.to_csv("mount_history.csv")  # ← これは推奨しない
        
        # ✅ 正しい使い方：バリデーションはvalidate_mount_periodを使う
        df = pd.read_csv("mount_history.csv")
        is_valid, msg = validate_mount_period(df, sensor_id, start_time)
        if not is_valid:
            st.warning(msg)
    
    Args:
        history: マウント履歴DataFrame（元データは変更されない）
                 必須列: SensorID, StartTime, EndTime
    
    Returns:
        EndTimeが補完されたDataFrame（新しいコピー）
    
    Note:
        - この関数は元のDataFrameを変更しない（純粋関数）。
        - 永続化前にこの関数を呼ぶことは推奨しない。
        - 時系列整合性のバリデーションは validate_mount_period を使用。
        - 日付型の変換と文字列への再変換を内部で行う。
    """
    if history.empty:
        return history.copy()
    
    df = history.copy()
    
    # 必須列の存在確認
    required_cols = ["SensorID", "StartTime", "EndTime"]
    if not all(col in df.columns for col in required_cols):
        return df
    
    # StartTimeを日時に変換
    df["StartTime"] = pd.to_datetime(df["StartTime"], errors="coerce")
    df["EndTime"] = pd.to_datetime(df["EndTime"], errors="coerce")
    
    # センサごとにグループ化してEndTimeを計算
    for sensor_id in df["SensorID"].unique():
        mask = df["SensorID"] == sensor_id
        sensor_rows = df.loc[mask].sort_values("StartTime")
        
        if len(sensor_rows) < 2:
            continue
        
        indices = sensor_rows.index.tolist()
        
        for i in range(len(indices) - 1):
            current_idx = indices[i]
            next_idx = indices[i + 1]
            
            # 次のレコードのStartTimeを現在のEndTimeに設定
            next_start = df.loc[next_idx, "StartTime"]
            if pd.notna(next_start):
                df.loc[current_idx, "EndTime"] = next_start
    
    # 日時を文字列に戻す
    df["StartTime"] = df["StartTime"].apply(
        lambda x: x.strftime("%Y-%m-%d %H:%M:%S") if pd.notna(x) else ""
    )
    df["EndTime"] = df["EndTime"].apply(
        lambda x: x.strftime("%Y-%m-%d %H:%M:%S") if pd.notna(x) else ""
    )
    
    return df


def resolve_context(
    history: pd.DataFrame,
    sensor_id: str,
    timestamp: Optional[datetime] = None
) -> Optional[MountInfo]:
    """
    指定時刻のコンテキスト（設備・装置）を特定
    
    履歴データから、指定されたセンサーIDと時刻に対応する
    マウント情報を検索して返す。
    
    Args:
        history: マウント履歴DataFrame
                 必須列: SensorID, EquipmentID, DeviceID, StartTime, EndTime
        sensor_id: センサーID
        timestamp: 検索対象時刻（省略時は現在時刻）
    
    Returns:
        MountInfo: 対応するマウント情報
        None: 該当期間がない場合
    
    Example:
        >>> mount = resolve_context(history, "SENSOR-001")
        >>> if mount:
        ...     print(f"現在の設備: {mount.equipment}")
    """
    if history.empty:
        return None
    
    if timestamp is None:
        timestamp = datetime.now()
    
    # 必須列の存在確認
    required_cols = ["SensorID", "EquipmentID", "DeviceID", "StartTime"]
    if not all(col in history.columns for col in required_cols):
        return None
    
    df = history.copy()
    
    # センサIDでフィルタ
    df = df[df["SensorID"] == sensor_id]
    if df.empty:
        return None
    
    # 日時変換
    df["StartTime"] = pd.to_datetime(df["StartTime"], errors="coerce")
    if "EndTime" in df.columns:
        df["EndTime"] = pd.to_datetime(df["EndTime"], errors="coerce")
    else:
        df["EndTime"] = pd.NaT
    
    # 有効な期間を持つレコードを抽出
    df = df.dropna(subset=["StartTime"])
    
    # 時刻が範囲内のレコードを検索
    for _, row in df.sort_values("StartTime", ascending=False).iterrows():
        start = row["StartTime"]
        end = row["EndTime"]
        
        # EndTimeがない場合は現在も有効
        if pd.isna(end):
            if start <= timestamp:
                return MountInfo(
                    sensor_id=sensor_id,
                    equipment=str(row.get("EquipmentID", "未設定")),
                    device=str(row.get("DeviceID", "未設定")),
                    mount_date=start,
                    unmount_date=None,
                    description=str(row.get("Remark", ""))
                )
        else:
            if start <= timestamp <= end:
                return MountInfo(
                    sensor_id=sensor_id,
                    equipment=str(row.get("EquipmentID", "未設定")),
                    device=str(row.get("DeviceID", "未設定")),
                    mount_date=start,
                    unmount_date=end,
                    description=str(row.get("Remark", ""))
                )
    
    return None


def get_current_context(
    history: pd.DataFrame,
    sensor_id: str
) -> Optional[MountInfo]:
    """
    現在時刻のコンテキストを取得（resolve_contextのショートカット）
    
    Args:
        history: マウント履歴DataFrame
        sensor_id: センサーID
    
    Returns:
        MountInfo: 現在のマウント情報
        None: 現在マウントされていない場合
    """
    return resolve_context(history, sensor_id, datetime.now())


def validate_mount_period(
    history: pd.DataFrame,
    sensor_id: str,
    start_time: datetime,
    end_time: Optional[datetime] = None
) -> Tuple[bool, str]:
    """
    マウント期間の重複をチェック
    
    同一センサにおいて、指定された期間が既存の期間と
    重複していないかを検証する。
    
    Args:
        history: マウント履歴DataFrame
        sensor_id: センサーID
        start_time: 開始時刻
        end_time: 終了時刻（省略時は無期限）
    
    Returns:
        Tuple[bool, str]: (有効かどうか, エラーメッセージ)
    
    Note:
        この関数は警告目的であり、登録自体をブロックはしない。
        重複がある場合は complete_time_chain で自動的に調整される。
    """
    if history.empty:
        return True, ""
    
    df = history.copy()
    df = df[df["SensorID"] == sensor_id]
    
    if df.empty:
        return True, ""
    
    df["StartTime"] = pd.to_datetime(df["StartTime"], errors="coerce")
    df["EndTime"] = pd.to_datetime(df["EndTime"], errors="coerce")
    
    for _, row in df.iterrows():
        existing_start = row["StartTime"]
        existing_end = row["EndTime"]
        
        if pd.isna(existing_start):
            continue
        
        # EndTimeがない場合は現在も有効（無期限）
        if pd.isna(existing_end):
            existing_end = datetime.max
        
        # 期間の重複チェック
        check_end = end_time if end_time else datetime.max
        
        if start_time < existing_end and check_end > existing_start:
            equip = row.get("EquipmentID", "不明")
            dev = row.get("DeviceID", "不明")
            return False, f"既存の期間 ({equip}/{dev}) と重複しています"
    
    return True, ""
