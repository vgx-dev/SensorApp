"""
スコア統合サービスモジュール (Version 3.0)

複数の異常検知モデルからのスコアを統合する純粋関数。
app.py の build_ai_scores_unified_v1 を独立した関数として移植。
"""

import numpy as np
from typing import Optional


def integrate_scores(
    if_scores: np.ndarray,
    ae_scores: np.ndarray,
    lstm_residual: np.ndarray,
    *,
    w_if: float = 0.4,
    w_ae: float = 0.3,
    w_lstm: float = 0.3,
    nan_when_all_invalid: bool = True,
) -> np.ndarray:
    """
    IF / AE / LSTM residual を統合
    
    - 同一長さに揃える
    - 0〜1 正規化（robust: 5-95パーセンタイル）
    - 重み付きで統合
    → ai_scores (0〜1)
    
    重要：NaNは「評価不能」として保持し、
    各時刻で有効なモデルだけで重みを再正規化して合算する。
    
    Args:
        if_scores: Isolation Forestのスコア
        ae_scores: AutoEncoderのスコア
        lstm_residual: LSTM残差スコア
        w_if: IFの重み
        w_ae: AEの重み
        w_lstm: LSTMの重み
        nan_when_all_invalid: 全無効時にNaNを返すか（Trueなら論文向け、FalseならUI向け）
    
    Returns:
        統合スコア（0〜1）
    """
    if_arr = np.asarray(if_scores, dtype=float)
    ae_arr = np.asarray(ae_scores, dtype=float)
    lstm_arr = np.asarray(lstm_residual, dtype=float)
    
    n = min(len(if_arr), len(ae_arr), len(lstm_arr))
    if n == 0:
        return np.array([], dtype=float)
    
    if_arr = if_arr[-n:]
    ae_arr = ae_arr[-n:]
    lstm_arr = lstm_arr[-n:]
    
    def _norm(x: np.ndarray) -> np.ndarray:
        """0-1正規化（5-95パーセンタイル）"""
        x = np.asarray(x, dtype=float)
        out = np.full_like(x, np.nan, dtype=float)
        mask = np.isfinite(x)
        if not mask.any():
            return out
        try:
            lo, hi = np.nanpercentile(x[mask], [5, 95])
        except Exception:
            return out
        if (not np.isfinite(lo)) or (not np.isfinite(hi)) or (hi - lo) < 1e-9:
            return out
        out[mask] = np.clip((x[mask] - lo) / (hi - lo), 0.0, 1.0)
        return out
    
    if_n = _norm(if_arr)
    ae_n = _norm(ae_arr)
    lstm_n = _norm(lstm_arr)
    
    X = np.vstack([if_n, ae_n, lstm_n]).T
    W = np.asarray([w_if, w_ae, w_lstm], dtype=float)
    
    valid = np.isfinite(X)
    
    numerator = np.sum(np.where(valid, X * W, 0.0), axis=1)
    denom = np.sum(np.where(valid, W, 0.0), axis=1)
    
    if nan_when_all_invalid:
        # 論文向け：全無効なら NaN（"評価不能"）
        out_arr = np.full_like(numerator, np.nan, dtype=float)
    else:
        # UI向け：全無効でも 0（表示が崩れにくい）
        out_arr = np.zeros_like(numerator)
    
    ai_scores = np.divide(
        numerator,
        denom,
        out=out_arr,
        where=(denom > 0.0),
    )
    
    # クリップ（NaNはそのまま）
    ai_scores = np.where(
        np.isfinite(ai_scores),
        np.clip(ai_scores, 0.0, 1.0),
        ai_scores
    )
    
    return ai_scores


def normalize_score_safe(
    x: np.ndarray,
    *,
    p_low: float = 5.0,
    p_high: float = 95.0,
    eps: float = 1e-12
) -> np.ndarray:
    """
    0-1正規化（ロバスト版）
    
    - 有効値がなければ NaN を返す
    - min==max のときは 0.5 を返す（情報保持）
    
    Args:
        x: 入力配列
        p_low: 下側パーセンタイル
        p_high: 上側パーセンタイル
        eps: ゼロ除算防止の小さな値
    
    Returns:
        正規化された配列
    """
    x = np.asarray(x, dtype=float)
    out = np.full_like(x, np.nan, dtype=float)
    mask = np.isfinite(x)
    
    if not mask.any():
        return out
    
    try:
        lo, hi = np.nanpercentile(x[mask], [p_low, p_high])
    except Exception:
        return out
    
    if not np.isfinite(lo) or not np.isfinite(hi):
        return out
    
    if (hi - lo) < eps:
        # min == max の場合は 0.5
        out[mask] = 0.5
        return out
    
    out[mask] = np.clip((x[mask] - lo) / (hi - lo), 0.0, 1.0)
    return out
