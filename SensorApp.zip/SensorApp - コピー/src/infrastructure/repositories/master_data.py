"""
マスタデータリポジトリ (Version 3.6 - S+級)

センサマスタ情報(sensor_master.csv)とマウント履歴(sensor_mount_list.csv)の
読み書きを担当するインフラストラクチャ層コンポーネント。

S+級改善:
- 排他制御（スレッドセーフ）
- バックアップ/リカバリ
- ログ出力

DESIGN_SENSOR_CONTEXT.md 準拠:
- ファイルロック対策（一時コピー読み込み）
- 設備・装置の親子関係
- センサIDリスト取得
- 使用者情報管理
"""

from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
import pandas as pd
import tempfile
import shutil
import os
import threading
import logging

from ...config.settings import PathConfig

# ログ設定
logger = logging.getLogger(__name__)


class MasterDataRepository:
    """
    マスタデータリポジトリ
    
    センサマスタ（設備・装置・管理者）とマウント履歴の
    読み書きを担当する。
    
    ファイル構成:
    - sensor_master.csv: 設備・装置・管理者マスタ
    - sensor_mount_list.csv: センサのマウント履歴
    
    Usage:
        config = PathConfig(data_dir="./data")
        repo = MasterDataRepository(config)
        
        # 設備リスト取得
        equipments = repo.get_equipment_list()
        
        # マウント履歴取得
        history = repo.load_mount_history()
    """
    
    # ファイル名定数
    MOUNT_HISTORY_FILE = "sensor_mount_list.csv"
    SENSOR_MASTER_FILE = "sensor_master.csv"
    
    # マウント履歴の列定義（UserName追加）
    MOUNT_COLUMNS = [
        "SensorID",
        "EquipmentID",
        "DeviceID",
        "UserName",
        "StartTime",
        "EndTime",
        "Remark"
    ]
    
    # センサマスタの列定義（UserName追加）
    MASTER_COLUMNS = [
        "EquipmentID",
        "DeviceID",
        "Manager",
        "UserName",
        "Remark"
    ]
    
    def __init__(self, path_config: PathConfig):
        """
        初期化
        
        Args:
            path_config: パス設定
        """
        self.path_config = path_config
        self._mount_cache: Optional[pd.DataFrame] = None
        self._master_cache: Optional[pd.DataFrame] = None
        # S+級: 排他制御用ロック
        self._mount_lock = threading.Lock()
        self._master_lock = threading.Lock()
    
    def _get_appsetting_path(self) -> Path:
        """AppSettingディレクトリパスを取得"""
        return self.path_config.get_appsetting_path()
    
    def _safe_read_csv(self, file_path: Path) -> Optional[pd.DataFrame]:
        """
        ファイルロック対策付きCSV読み込み
        
        一時ファイルにコピーしてから読み込み、読み込み後に削除する。
        """
        if not file_path.exists():
            return None
        
        tmp_copy = None
        try:
            # 一時コピー作成
            tmp_copy = Path(tempfile.gettempdir()) / f"tmp_{file_path.name}"
            shutil.copy2(file_path, tmp_copy)
            
            # 読み込み
            df = pd.read_csv(tmp_copy, encoding="utf-8-sig")
            return df
            
        except Exception as e:
            # utf-8-sigで失敗したらcp932を試す
            try:
                if tmp_copy and tmp_copy.exists():
                    df = pd.read_csv(tmp_copy, encoding="cp932")
                    return df
            except Exception:
                pass
            return None
        finally:
            # 一時ファイル削除
            if tmp_copy and tmp_copy.exists():
                try:
                    os.remove(tmp_copy)
                except Exception:
                    pass
    
    # ==================== マウント履歴 ====================
    
    def load_mount_history(self, force_reload: bool = False) -> pd.DataFrame:
        """
        マウント履歴を読み込む
        
        Args:
            force_reload: キャッシュを無視して再読み込み
        
        Returns:
            マウント履歴DataFrame
        """
        if self._mount_cache is not None and not force_reload:
            return self._mount_cache.copy()
        
        mount_file = self._get_appsetting_path() / self.MOUNT_HISTORY_FILE
        df = self._safe_read_csv(mount_file)
        
        if df is None:
            self._mount_cache = self._create_empty_mount_df()
        else:
            # 列の存在確認と補完
            for col in self.MOUNT_COLUMNS:
                if col not in df.columns:
                    df[col] = ""
            self._mount_cache = df[self.MOUNT_COLUMNS].copy()
        
        return self._mount_cache.copy()
    
    def save_mount_history(self, df: pd.DataFrame) -> bool:
        """
        マウント履歴を保存（S+級: 排他制御・バックアップ付き）
        
        Args:
            df: 保存するDataFrame
        
        Returns:
            成功時True
        """
        appsetting_path = self._get_appsetting_path()
        
        # 排他制御: 同時実行を防止
        with self._mount_lock:
            try:
                appsetting_path.mkdir(parents=True, exist_ok=True)
                mount_file = appsetting_path / self.MOUNT_HISTORY_FILE
                backup_file = appsetting_path / (self.MOUNT_HISTORY_FILE + ".bak")
                
                # バックアップ作成（既存ファイルがある場合）
                if mount_file.exists():
                    shutil.copy2(mount_file, backup_file)
                
                # 保存
                df.to_csv(mount_file, index=False, encoding="utf-8-sig")
                
                # 成功したらバックアップを削除
                if backup_file.exists():
                    backup_file.unlink()
                
                # キャッシュ更新
                self._mount_cache = df.copy()
                logger.info(f"Mount history saved: {len(df)} records")
                return True
                
            except Exception as e:
                logger.error(f"Failed to save mount history: {e}")
                # リカバリ: バックアップから復元
                backup_file = appsetting_path / (self.MOUNT_HISTORY_FILE + ".bak")
                if backup_file.exists():
                    try:
                        shutil.copy2(backup_file, mount_file)
                        logger.info("Mount history recovered from backup")
                    except Exception as restore_e:
                        logger.error(f"Failed to restore from backup: {restore_e}")
                return False
    
    def _create_empty_mount_df(self) -> pd.DataFrame:
        """空のマウント履歴DataFrameを作成"""
        return pd.DataFrame(columns=self.MOUNT_COLUMNS)
    
    # ==================== センサマスタ ====================
    
    def load_sensor_master(self, force_reload: bool = False) -> pd.DataFrame:
        """
        センサマスタを読み込む
        
        Args:
            force_reload: キャッシュを無視して再読み込み
        
        Returns:
            センサマスタDataFrame
        """
        if self._master_cache is not None and not force_reload:
            return self._master_cache.copy()
        
        master_file = self._get_appsetting_path() / self.SENSOR_MASTER_FILE
        df = self._safe_read_csv(master_file)
        
        if df is None:
            self._master_cache = self._create_empty_master_df()
        else:
            # 列の存在確認と補完
            for col in self.MASTER_COLUMNS:
                if col not in df.columns:
                    df[col] = ""
            self._master_cache = df
        
        return self._master_cache.copy()
    
    def save_sensor_master(self, df: pd.DataFrame) -> bool:
        """
        センサマスタを保存（S+級: 排他制御・バックアップ付き）
        
        Args:
            df: 保存するDataFrame
        
        Returns:
            成功時True
        """
        appsetting_path = self._get_appsetting_path()
        
        # 排他制御: 同時実行を防止
        with self._master_lock:
            try:
                appsetting_path.mkdir(parents=True, exist_ok=True)
                master_file = appsetting_path / self.SENSOR_MASTER_FILE
                backup_file = appsetting_path / (self.SENSOR_MASTER_FILE + ".bak")
                
                # バックアップ作成（既存ファイルがある場合）
                if master_file.exists():
                    shutil.copy2(master_file, backup_file)
                
                # 保存
                df.to_csv(master_file, index=False, encoding="utf-8-sig")
                
                # 成功したらバックアップを削除
                if backup_file.exists():
                    backup_file.unlink()
                
                # キャッシュ更新
                self._master_cache = df.copy()
                logger.info(f"Sensor master saved: {len(df)} records")
                return True
                
            except Exception as e:
                logger.error(f"Failed to save sensor master: {e}")
                # リカバリ: バックアップから復元
                backup_file = appsetting_path / (self.SENSOR_MASTER_FILE + ".bak")
                if backup_file.exists():
                    try:
                        shutil.copy2(backup_file, master_file)
                        logger.info("Sensor master recovered from backup")
                    except Exception as restore_e:
                        logger.error(f"Failed to restore from backup: {restore_e}")
                return False
    
    def _create_empty_master_df(self) -> pd.DataFrame:
        """空のセンサマスタDataFrameを作成"""
        return pd.DataFrame(columns=self.MASTER_COLUMNS)
    
    # ==================== リスト取得 ====================
    
    def get_equipment_list(self) -> List[str]:
        """
        設備IDのユニークリストを取得
        
        マウント履歴とセンサマスタの両方から収集。
        
        Returns:
            設備IDリスト（ソート済み）
        """
        equipments = set()
        
        # マウント履歴から
        mount_df = self.load_mount_history()
        if "EquipmentID" in mount_df.columns:
            equips = mount_df["EquipmentID"].dropna().astype(str)
            equips = equips[equips.str.strip() != ""]
            equipments.update(equips.unique())
        
        # センサマスタから
        master_df = self.load_sensor_master()
        if "EquipmentID" in master_df.columns:
            equips = master_df["EquipmentID"].dropna().astype(str)
            equips = equips[equips.str.strip() != ""]
            equipments.update(equips.unique())
        
        return sorted(equipments)
    
    def get_device_list(self, equipment_id: Optional[str] = None) -> List[str]:
        """
        装置IDのユニークリストを取得
        
        Args:
            equipment_id: 設備IDでフィルタ（省略時は全装置）
        
        Returns:
            装置IDリスト（ソート済み）
        """
        devices = set()
        
        # マウント履歴から
        mount_df = self.load_mount_history()
        if "DeviceID" in mount_df.columns:
            if equipment_id and "EquipmentID" in mount_df.columns:
                mount_df = mount_df[mount_df["EquipmentID"] == equipment_id]
            devs = mount_df["DeviceID"].dropna().astype(str)
            devs = devs[devs.str.strip() != ""]
            devices.update(devs.unique())
        
        # センサマスタから
        master_df = self.load_sensor_master()
        if "DeviceID" in master_df.columns:
            if equipment_id and "EquipmentID" in master_df.columns:
                master_df = master_df[master_df["EquipmentID"] == equipment_id]
            devs = master_df["DeviceID"].dropna().astype(str)
            devs = devs[devs.str.strip() != ""]
            devices.update(devs.unique())
        
        return sorted(devices)
    
    def get_manager_by_equipment(
        self,
        equipment_id: str,
        device_id: Optional[str] = None
    ) -> Optional[str]:
        """
        設備・装置に対応する管理者を取得
        
        Args:
            equipment_id: 設備ID
            device_id: 装置ID（省略時は設備のみでマッチ）
        
        Returns:
            管理者名（見つからない場合はNone）
        """
        master_df = self.load_sensor_master()
        
        if master_df.empty or "Manager" not in master_df.columns:
            return None
        
        # 設備でフィルタ
        df = master_df[master_df["EquipmentID"] == equipment_id]
        
        if df.empty:
            return None
        
        # 装置でもフィルタ
        if device_id and "DeviceID" in df.columns:
            df_device = df[df["DeviceID"] == device_id]
            if not df_device.empty:
                df = df_device
        
        # 最初のマッチを返す
        manager = df["Manager"].iloc[0]
        if pd.notna(manager) and str(manager).strip():
            return str(manager).strip()
        
        return None
    
    def add_or_update_master(
        self,
        equipment_id: str,
        device_id: str,
        manager: str = "",
        remark: str = ""
    ) -> bool:
        """
        センサマスタにレコードを追加または更新
        
        同一の設備・装置の組み合わせが存在する場合は更新。
        
        Args:
            equipment_id: 設備ID
            device_id: 装置ID
            manager: 管理者名
            remark: 備考
        
        Returns:
            成功時True
        """
        df = self.load_sensor_master()
        
        # 既存レコードを検索
        mask = (df["EquipmentID"] == equipment_id) & (df["DeviceID"] == device_id)
        
        if mask.any():
            # 更新
            df.loc[mask, "Manager"] = manager
            df.loc[mask, "Remark"] = remark
        else:
            # 追加
            new_row = {
                "EquipmentID": equipment_id,
                "DeviceID": device_id,
                "Manager": manager,
                "Remark": remark
            }
            df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        
        return self.save_sensor_master(df)
    
    # ==================== キャッシュ管理 ====================
    
    def clear_cache(self) -> None:
        """全キャッシュをクリア"""
        self._mount_cache = None
        self._master_cache = None
    
    # ==================== センサID取得 ====================
    
    def get_sensor_id_list(self) -> List[str]:
        """
        過去に登録されたセンサIDのユニークリストを取得
        
        Returns:
            センサIDリスト（ソート済み）
        """
        sensors = set()
        
        # マウント履歴から
        mount_df = self.load_mount_history()
        if "SensorID" in mount_df.columns:
            ids = mount_df["SensorID"].dropna().astype(str)
            ids = ids[ids.str.strip() != ""]
            sensors.update(ids.unique())
        
        return sorted(sensors)
    
    def get_user_by_sensor(self, sensor_id: str) -> Optional[str]:
        """
        センサIDに対応する使用者を取得（最新のマウントから）
        
        Args:
            sensor_id: センサID
        
        Returns:
            使用者名（見つからない場合はNone）
        """
        mount_df = self.load_mount_history()
        
        if mount_df.empty or "UserName" not in mount_df.columns:
            return None
        
        # センサIDでフィルタ
        df = mount_df[mount_df["SensorID"] == sensor_id]
        if df.empty:
            return None
        
        # 最新のレコードを取得
        df["StartTime"] = pd.to_datetime(df["StartTime"], errors="coerce")
        df = df.sort_values("StartTime", ascending=False)
        
        user = df["UserName"].iloc[0]
        if pd.notna(user) and str(user).strip():
            return str(user).strip()
        
        return None
    
    def get_user_list(self) -> List[str]:
        """
        過去に登録された使用者のユニークリストを取得
        
        Returns:
            使用者名リスト（ソート済み）
        """
        users = set()
        
        # マウント履歴から
        mount_df = self.load_mount_history()
        if "UserName" in mount_df.columns:
            names = mount_df["UserName"].dropna().astype(str)
            names = names[names.str.strip() != ""]
            users.update(names.unique())
        
        # マスタから
        master_df = self.load_sensor_master()
        if "UserName" in master_df.columns:
            names = master_df["UserName"].dropna().astype(str)
            names = names[names.str.strip() != ""]
            users.update(names.unique())
        
        return sorted(users)
    
    def get_equipment_device_pairs(self) -> List[Dict[str, str]]:
        """
        設備・装置のペアリストを取得（親子関係表示用）
        
        Returns:
            [{"equipment": "OPF-1", "device": "CTポンプ"}, ...]
        """
        pairs = set()
        
        # マウント履歴から
        mount_df = self.load_mount_history()
        if "EquipmentID" in mount_df.columns and "DeviceID" in mount_df.columns:
            for _, row in mount_df.iterrows():
                equip = str(row.get("EquipmentID", "")).strip()
                dev = str(row.get("DeviceID", "")).strip()
                if equip and dev:
                    pairs.add((equip, dev))
        
        # マスタから
        master_df = self.load_sensor_master()
        if "EquipmentID" in master_df.columns and "DeviceID" in master_df.columns:
            for _, row in master_df.iterrows():
                equip = str(row.get("EquipmentID", "")).strip()
                dev = str(row.get("DeviceID", "")).strip()
                if equip and dev:
                    pairs.add((equip, dev))
        
        return [{
            "equipment": equip,
            "device": dev
        } for equip, dev in sorted(pairs)]
