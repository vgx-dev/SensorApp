"""
モデル管理モジュール (Version 3.0)

AIモデル（scikit-learn, TensorFlow/Keras）の保存・ロード・バージョン管理を行う。
"""

from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime
import json
import pickle

from ...config.settings import PathConfig


# モデルファイルの拡張子
SKLEARN_EXT = ".pkl"
KERAS_EXT = ".h5"
METADATA_EXT = ".json"

# 命名規則: {algorithm}_{equipment}_{device}_{version}.{ext}
# 例: IF_PumpA_Motor1_v001.pkl


class ModelStore:
    """
    AIモデル管理クラス
    
    scikit-learn (.pkl) および TensorFlow/Keras (.h5) モデルの
    保存・ロード・バージョン管理を行う。
    
    Usage:
        config = PathConfig(model_dir="./models")
        store = ModelStore(config)
        
        # モデル保存
        store.save_model(
            model=if_model,
            algorithm="IF",
            equipment="PumpA",
            device="Motor1"
        )
        
        # モデルロード
        model = store.load_model(
            algorithm="IF",
            equipment="PumpA",
            device="Motor1"
        )
    """
    
    def __init__(self, path_config: PathConfig):
        """
        初期化
        
        Args:
            path_config: パス設定
        """
        self.path_config = path_config
        self._ensure_model_dir()
    
    def _ensure_model_dir(self) -> None:
        """モデルディレクトリの存在を保証"""
        model_path = self.path_config.get_model_path()
        if model_path and not model_path.exists():
            model_path.mkdir(parents=True, exist_ok=True)
    
    def save_model(
        self,
        model: Any,
        algorithm: str,
        equipment: str,
        device: str,
        *,
        version: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        is_keras: bool = False
    ) -> Path:
        """
        モデルを保存
        
        Args:
            model: 保存するモデルオブジェクト
            algorithm: アルゴリズム名（IF, AE, LSTM等）
            equipment: 設備名
            device: 装置名
            version: バージョン（省略時は自動生成）
            metadata: メタ情報
            is_keras: Kerasモデルかどうか
            
        Returns:
            保存したファイルのパス
        """
        model_path = self.path_config.get_model_path()
        
        # バージョン自動生成
        if version is None:
            version = self._generate_version(algorithm, equipment, device)
        
        # ファイル名生成
        base_name = self._make_base_name(algorithm, equipment, device, version)
        
        if is_keras:
            file_path = model_path / f"{base_name}{KERAS_EXT}"
            self._save_keras_model(model, file_path)
        else:
            file_path = model_path / f"{base_name}{SKLEARN_EXT}"
            self._save_sklearn_model(model, file_path)
        
        # メタデータ保存
        meta = {
            "algorithm": algorithm,
            "equipment": equipment,
            "device": device,
            "version": version,
            "saved_at": datetime.now().isoformat(),
            "is_keras": is_keras,
            **(metadata or {})
        }
        meta_path = model_path / f"{base_name}{METADATA_EXT}"
        self._save_metadata(meta, meta_path)
        
        return file_path
    
    def load_model(
        self,
        algorithm: str,
        equipment: str,
        device: str,
        *,
        version: Optional[str] = None
    ) -> Optional[Any]:
        """
        モデルをロード
        
        Args:
            algorithm: アルゴリズム名
            equipment: 設備名
            device: 装置名
            version: バージョン（省略時は最新）
            
        Returns:
            ロードしたモデル（見つからない場合はNone）
        """
        model_path = self.path_config.get_model_path()
        
        # バージョン指定がない場合は最新を探す
        if version is None:
            version = self._find_latest_version(algorithm, equipment, device)
            if version is None:
                return None
        
        base_name = self._make_base_name(algorithm, equipment, device, version)
        
        # Kerasモデルを試す
        keras_path = model_path / f"{base_name}{KERAS_EXT}"
        if keras_path.exists():
            return self._load_keras_model(keras_path)
        
        # scikit-learnモデルを試す
        sklearn_path = model_path / f"{base_name}{SKLEARN_EXT}"
        if sklearn_path.exists():
            return self._load_sklearn_model(sklearn_path)
        
        return None
    
    def load_metadata(
        self,
        algorithm: str,
        equipment: str,
        device: str,
        *,
        version: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        モデルのメタデータをロード
        
        Returns:
            メタデータ辞書（見つからない場合はNone）
        """
        model_path = self.path_config.get_model_path()
        
        if version is None:
            version = self._find_latest_version(algorithm, equipment, device)
            if version is None:
                return None
        
        base_name = self._make_base_name(algorithm, equipment, device, version)
        meta_path = model_path / f"{base_name}{METADATA_EXT}"
        
        if meta_path.exists():
            with open(meta_path, "r", encoding="utf-8") as f:
                return json.load(f)
        
        return None
    
    def list_models(
        self,
        algorithm: Optional[str] = None,
        equipment: Optional[str] = None,
        device: Optional[str] = None
    ) -> List[Dict[str, str]]:
        """
        保存されているモデル一覧を取得
        
        Returns:
            モデル情報のリスト
        """
        model_path = self.path_config.get_model_path()
        if not model_path.exists():
            return []
        
        models = []
        
        # メタデータファイルを探索
        for meta_file in model_path.glob(f"*{METADATA_EXT}"):
            try:
                with open(meta_file, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                
                # フィルタリング
                if algorithm and meta.get("algorithm") != algorithm:
                    continue
                if equipment and meta.get("equipment") != equipment:
                    continue
                if device and meta.get("device") != device:
                    continue
                
                models.append(meta)
            except Exception:
                continue
        
        # 日時でソート（新しい順）
        models.sort(key=lambda x: x.get("saved_at", ""), reverse=True)
        
        return models
    
    def delete_model(
        self,
        algorithm: str,
        equipment: str,
        device: str,
        version: str
    ) -> bool:
        """
        モデルを削除
        
        Returns:
            削除成功でTrue
        """
        model_path = self.path_config.get_model_path()
        base_name = self._make_base_name(algorithm, equipment, device, version)
        
        deleted = False
        
        for ext in [SKLEARN_EXT, KERAS_EXT, METADATA_EXT]:
            file_path = model_path / f"{base_name}{ext}"
            if file_path.exists():
                file_path.unlink()
                deleted = True
        
        return deleted
    
    def get_latest_build_date(
        self,
        equipment: str,
        device: str
    ) -> Optional[datetime]:
        """
        指定した設備・装置の最終ビルド日時を取得
        
        Returns:
            最終ビルド日時（モデルがない場合はNone）
        """
        models = self.list_models(equipment=equipment, device=device)
        
        if not models:
            return None
        
        # 最新のsaved_atを取得
        latest = models[0].get("saved_at")
        if latest:
            return datetime.fromisoformat(latest)
        
        return None
    
    def _make_base_name(
        self,
        algorithm: str,
        equipment: str,
        device: str,
        version: str
    ) -> str:
        """ファイル名のベース部分を生成"""
        # ファイル名に使えない文字を置換
        def sanitize(s: str) -> str:
            return s.replace("/", "_").replace("\\", "_").replace(" ", "_")
        
        return f"{sanitize(algorithm)}_{sanitize(equipment)}_{sanitize(device)}_{version}"
    
    def _generate_version(
        self,
        algorithm: str,
        equipment: str,
        device: str
    ) -> str:
        """バージョン番号を自動生成"""
        latest = self._find_latest_version(algorithm, equipment, device)
        
        if latest is None:
            return "v001"
        
        # vXXX形式からインクリメント
        try:
            num = int(latest[1:])
            return f"v{num + 1:03d}"
        except ValueError:
            return f"v{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    def _find_latest_version(
        self,
        algorithm: str,
        equipment: str,
        device: str
    ) -> Optional[str]:
        """最新バージョンを探す"""
        models = self.list_models(algorithm=algorithm, equipment=equipment, device=device)
        
        if not models:
            return None
        
        return models[0].get("version")
    
    def _save_sklearn_model(self, model: Any, path: Path) -> None:
        """scikit-learnモデルを保存"""
        with open(path, "wb") as f:
            pickle.dump(model, f)
    
    def _load_sklearn_model(self, path: Path) -> Optional[Any]:
        """scikit-learnモデルをロード"""
        try:
            with open(path, "rb") as f:
                return pickle.load(f)
        except Exception:
            return None
    
    def _save_keras_model(self, model: Any, path: Path) -> None:
        """Kerasモデルを保存"""
        try:
            model.save(str(path))
        except Exception as e:
            # .h5が使えない場合はpickleにフォールバック
            pkl_path = path.with_suffix(SKLEARN_EXT)
            with open(pkl_path, "wb") as f:
                pickle.dump(model, f)
    
    def _load_keras_model(self, path: Path) -> Optional[Any]:
        """Kerasモデルをロード"""
        try:
            from tensorflow import keras
            return keras.models.load_model(str(path))
        except ImportError:
            return None
        except Exception:
            return None
    
    def _save_metadata(self, meta: Dict[str, Any], path: Path) -> None:
        """メタデータを保存"""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
