"""
実データアクセスモジュール (Version 3.0)

実機センサのCSVログを読み込み、SensorDataエンティティとして提供する。
Shift-JIS (cp932) エンコーディングと列名揺らぎに対応。

S+級改善:
- マウント履歴の時系列追跡
- 変更差分の自動検出
- 排他制御（スレッドセーフ）
- エラーリカバリ（バックアップ/復旧）

データ仕様 (SensorNode_yyyymmdd.csv):
- ヘッダ行なし（1行目からデータ）
- A列 (Index 0): センサID（文字列として読み込み必須）
- AC列 (Index 28): RMS（主要Value 1）
- AE列 (Index 30): Value 2
- AG列 (Index 32): Value 3
- AM列 (Index 38): 時刻（datetime）
"""

from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime
import pandas as pd
import tempfile
import shutil
import threading
import logging

from ...domain.entities.sensor import SensorData, MountInfo
from ...config.settings import PathConfig

# ログ設定
logger = logging.getLogger(__name__)



# 固定列インデックス（CSV仕様）
COL_IDX_SENSOR_ID = 0   # A列: センサID
COL_IDX_RMS = 28        # AC列: RMS（主要Value 1）
COL_IDX_VALUE2 = 30     # AE列: Value 2
COL_IDX_VALUE3 = 32     # AG列: Value 3
COL_IDX_TIME = 38       # AM列: 時刻

# 列名定義（内部使用）
SENSOR_ID_COL = "ID"
TIME_COL = "Time"
RMS_COL = "RMS"
VALUE2_COL = "Value2"
VALUE3_COL = "Value3"

# エンコーディング優先順
ENCODINGS = ["cp932", "shift-jis", "utf-8", "utf-8-sig"]


class RealDataProvider:
    """
    実データプロバイダ
    
    運用モードで使用。実機センサのCSVログを読み込み、
    SensorDataエンティティとして提供する。
    
    データ仕様:
    - SensorNode_yyyymmdd.csv: ヘッダなし、1行目からデータ
    - 列はインデックスで固定（ID=0, RMS=28, Time=38）
    - 1ファイルに全センサのデータが混在
    
    Usage:
        config = PathConfig(data_dir="./Log", appsetting_dir="./AppSetting")
        provider = RealDataProvider(config)
        
        # センサリスト取得
        sensors = provider.get_sensor_list()
        
        # センサデータ取得
        sensor_data = provider.get_sensor_data("SENSOR-001")
    """
    
    def __init__(self, path_config: PathConfig):
        """
        初期化
        
        Args:
            path_config: パス設定（data_dir, appsetting_dir等を含む）
        """
        self.path_config = path_config
        self._header_cache: Optional[List[str]] = None
        self._mount_cache: Optional[List[MountInfo]] = None
        # S+級: 排他制御用ロック
        self._mount_lock = threading.Lock()
    
    def _load_header(self) -> List[str]:
        """
        ヘッダ定義ファイルを読み込む（オプション）
        
        Returns:
            列名リスト（読み込み失敗時はデフォルト）
        """
        if self._header_cache is not None:
            return self._header_cache
        
        appsetting_dir = self._get_appsetting_path()
        if appsetting_dir is None or not appsetting_dir.exists():
            self._header_cache = self._get_default_header()
            return self._header_cache
        
        # ヘッダファイルを探す
        header_file = appsetting_dir / "SensorNode_yyyymmdd_csv表示データ並び.csv"
        
        if not header_file.exists():
            for f in appsetting_dir.glob("*csv表示データ並び*.csv"):
                header_file = f
                break
        
        if not header_file.exists():
            self._header_cache = self._get_default_header()
            return self._header_cache
        
        try:
            df = pd.read_csv(header_file, header=None, encoding="utf-8-sig")
            header = df.iloc[0].tolist()
            
            # 最初の列をIDに強制
            if len(header) > COL_IDX_SENSOR_ID:
                header[COL_IDX_SENSOR_ID] = SENSOR_ID_COL
            
            # 列名ユニーク化
            seen = {}
            unique_header = []
            for h in header:
                h_str = str(h) if pd.notna(h) else f"col_{len(unique_header)}"
                if h_str not in seen:
                    seen[h_str] = 0
                    unique_header.append(h_str)
                else:
                    seen[h_str] += 1
                    unique_header.append(f"{h_str}_{seen[h_str]}")
            
            self._header_cache = unique_header
            return self._header_cache
            
        except Exception:
            self._header_cache = self._get_default_header()
            return self._header_cache
    
    def _get_default_header(self) -> List[str]:
        """デフォルトのヘッダ（最小限の列名）を生成"""
        # 必要な列数分のヘッダを生成（最低39列必要：Time列が38）
        header = [f"col_{i}" for i in range(max(COL_IDX_TIME + 1, 50))]
        header[COL_IDX_SENSOR_ID] = SENSOR_ID_COL
        header[COL_IDX_RMS] = RMS_COL
        header[COL_IDX_VALUE2] = VALUE2_COL
        header[COL_IDX_VALUE3] = VALUE3_COL
        header[COL_IDX_TIME] = TIME_COL
        return header
    
    def get_latest_csv_path(self) -> Optional[Path]:
        """
        最新のログCSVファイルパスを取得
        
        Returns:
            最新CSVのパス（見つからない場合はNone）
        """
        data_path = self.path_config.get_data_path()
        if data_path is None or not data_path.exists():
            return None
        
        # SensorNode_*.csv をglobして日付順にソート
        csv_files = sorted(data_path.glob("SensorNode_*.csv"))
        
        if not csv_files:
            csv_files = sorted(data_path.glob("*.csv"))
        
        if not csv_files:
            return None
        
        return csv_files[-1]
    
    def _load_csv_raw(self, csv_path: Path) -> Optional[pd.DataFrame]:
        """
        CSVを列インデックスベースで読み込む（堅牢版）
        
        Args:
            csv_path: CSVファイルパス
            
        Returns:
            DataFrame（読み込み失敗時はNone）
        """
        tmp_copy = None
        try:
            # 一時コピーして読み込み（ファイルロック回避）
            tmp_copy = Path(tempfile.gettempdir()) / csv_path.name
            shutil.copy2(csv_path, tmp_copy)
            
            # まず列数を確認
            df_check = pd.read_csv(
                tmp_copy,
                header=None,
                encoding="cp932",
                on_bad_lines="skip",
                nrows=1
            )
            actual_cols = len(df_check.columns)
            
            # 必要な列数があるか確認
            min_required_cols = COL_IDX_TIME + 1  # 38 + 1 = 39列必要
            if actual_cols < min_required_cols:
                # 列数不足の場合は読み込んで後で処理
                pass
            
            # dtype指定でセンサIDを文字列として読み込む
            dtype_spec = {COL_IDX_SENSOR_ID: str}
            
            df = pd.read_csv(
                tmp_copy,
                header=None,
                encoding="cp932",
                on_bad_lines="skip",
                dtype=dtype_spec,
                low_memory=False
            )
            
            return df
            
        except Exception as e:
            # cp932で失敗したらutf-8を試す
            try:
                if tmp_copy and tmp_copy.exists():
                    df = pd.read_csv(
                        tmp_copy,
                        header=None,
                        encoding="utf-8",
                        on_bad_lines="skip",
                        dtype={COL_IDX_SENSOR_ID: str},
                        low_memory=False
                    )
                    return df
            except Exception:
                pass
            return None
        finally:
            # 一時ファイルを確実に削除
            if tmp_copy and tmp_copy.exists():
                try:
                    import os
                    os.remove(tmp_copy)
                except Exception:
                    pass
    
    def _process_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        DataFrameに列名を付与し、時刻列を変換
        
        Args:
            df: 生のDataFrame
            
        Returns:
            処理済みDataFrame
        """
        if df is None or df.empty:
            return pd.DataFrame()
        
        actual_cols = len(df.columns)
        
        # 必要な列が存在するか確認
        has_id = actual_cols > COL_IDX_SENSOR_ID
        has_rms = actual_cols > COL_IDX_RMS
        has_time = actual_cols > COL_IDX_TIME
        
        # 列名を付与（インデックスベース）
        new_columns = [f"col_{i}" for i in range(actual_cols)]
        
        if has_id:
            new_columns[COL_IDX_SENSOR_ID] = SENSOR_ID_COL
        if has_rms:
            new_columns[COL_IDX_RMS] = RMS_COL
        if actual_cols > COL_IDX_VALUE2:
            new_columns[COL_IDX_VALUE2] = VALUE2_COL
        if actual_cols > COL_IDX_VALUE3:
            new_columns[COL_IDX_VALUE3] = VALUE3_COL
        if has_time:
            new_columns[COL_IDX_TIME] = TIME_COL
        
        df.columns = new_columns
        
        # センサIDを文字列に強制変換
        if has_id and SENSOR_ID_COL in df.columns:
            df[SENSOR_ID_COL] = df[SENSOR_ID_COL].astype(str).str.strip()
        
        # 時刻列を変換（エラーは coerce で NaT に）
        if has_time and TIME_COL in df.columns:
            df[TIME_COL] = pd.to_datetime(df[TIME_COL], errors="coerce")
            # 無効な時刻行を警告（削除はしない、フィルタリング時に除外される）
        
        # RMS列を数値に変換
        if has_rms and RMS_COL in df.columns:
            df[RMS_COL] = pd.to_numeric(df[RMS_COL], errors="coerce")
        
        return df
    
    def get_sensor_list(self) -> List[str]:
        """
        利用可能なセンサIDリストを取得
        
        Returns:
            List[str]: センサIDリスト
        """
        latest_csv = self.get_latest_csv_path()
        if latest_csv is None:
            return []
        
        df = self._load_csv_raw(latest_csv)
        if df is None or df.empty:
            return []
        
        df = self._process_dataframe(df)
        
        if SENSOR_ID_COL in df.columns:
            # 空文字や nan を除外
            sensors = df[SENSOR_ID_COL].dropna().astype(str)
            sensors = sensors[sensors.str.strip() != ""]
            sensors = sensors.unique().tolist()
            return sorted(sensors)
        
        return []
    
    def list_sensors(self) -> List[str]:
        """get_sensor_list のエイリアス"""
        return self.get_sensor_list()
    
    def get_sensor_data(
        self,
        sensor_id: str,
        *,
        tail_rows: Optional[int] = None
    ) -> SensorData:
        """
        指定センサIDのデータを取得
        
        Args:
            sensor_id: センサID
            tail_rows: 末尾から取得する行数（Noneなら全件）
            
        Returns:
            SensorData: センサデータエンティティ
        """
        latest_csv = self.get_latest_csv_path()
        if latest_csv is None:
            return self._empty_sensor_data(sensor_id)
        
        df = self._load_csv_raw(latest_csv)
        if df is None or df.empty:
            return self._empty_sensor_data(sensor_id, source_file=str(latest_csv))
        
        df = self._process_dataframe(df)
        
        if df.empty:
            return self._empty_sensor_data(sensor_id, source_file=str(latest_csv))
        
        # センサIDでフィルタリング
        if SENSOR_ID_COL in df.columns:
            df = df[df[SENSOR_ID_COL] == str(sensor_id)].copy()
        
        if df.empty:
            return self._empty_sensor_data(sensor_id, source_file=str(latest_csv))
        
        # 有効な時刻行のみ抽出
        if TIME_COL in df.columns:
            df = df.dropna(subset=[TIME_COL])
            df = df.sort_values(TIME_COL)
        
        if df.empty:
            return self._empty_sensor_data(sensor_id, source_file=str(latest_csv))
        
        # tail_rows指定時は末尾のみ
        if tail_rows is not None and len(df) > tail_rows:
            df = df.tail(tail_rows).reset_index(drop=True)
        
        # 値列を特定
        value_cols = []
        for col in [RMS_COL, VALUE2_COL, VALUE3_COL]:
            if col in df.columns:
                value_cols.append(col)
        
        return SensorData(
            sensor_id=sensor_id,
            dataframe=df,
            time_column=TIME_COL if TIME_COL in df.columns else None,
            value_columns=value_cols,
            source_file=str(latest_csv),
            encoding="cp932"
        )
    
    def get_mount_info(self) -> List[MountInfo]:
        """
        マウント情報を取得
        
        Returns:
            List[MountInfo]: マウント情報リスト
        """
        if self._mount_cache is not None:
            return self._mount_cache
        
        appsetting_dir = self._get_appsetting_path()
        if appsetting_dir is None or not appsetting_dir.exists():
            self._mount_cache = []
            return self._mount_cache
        
        mount_file = appsetting_dir / "sensor_mount_list.csv"
        if not mount_file.exists():
            for f in appsetting_dir.glob("*mount*.csv"):
                mount_file = f
                break
        
        if not mount_file.exists():
            self._mount_cache = []
            return self._mount_cache
        
        try:
            df = pd.read_csv(mount_file, encoding="utf-8-sig")
            mounts = []
            
            for _, row in df.iterrows():
                mount = MountInfo(
                    sensor_id=str(row.get("SensorID", "")),
                    equipment=str(row.get("EquipmentID", "Unknown")),
                    device=str(row.get("DeviceID", "Unknown")),
                    description=str(row.get("Remark", ""))
                )
                if mount.sensor_id:
                    mounts.append(mount)
            
            self._mount_cache = mounts
            return mounts
            
        except Exception:
            self._mount_cache = []
            return self._mount_cache
    
    def _get_appsetting_path(self) -> Optional[Path]:
        """AppSettingディレクトリパスを取得"""
        appsetting_path = self.path_config.get_appsetting_path()
        if appsetting_path and appsetting_path.exists():
            return appsetting_path
        return None
    
    def _empty_sensor_data(
        self,
        sensor_id: str,
        source_file: Optional[str] = None
    ) -> SensorData:
        """空のSensorDataを返す"""
        return SensorData(
            sensor_id=sensor_id,
            dataframe=pd.DataFrame(),
            source_file=source_file
        )
    
    def save_mount_info(self, mount_df: pd.DataFrame, record_history: bool = True) -> bool:
        """
        マウント情報をCSVに保存（排他制御・履歴連動版）
        
        S+級改善:
        - 変更差分を自動検出し、履歴に記録
        - 排他制御でスレッドセーフ
        - バックアップ/リカバリで堅牢性確保
        
        Args:
            mount_df: マウント情報DataFrame
            record_history: 履歴を記録するか（デフォルトTrue）
            
        Returns:
            成功時True
        """
        appsetting_dir = self._get_appsetting_path()
        if appsetting_dir is None:
            logger.warning("AppSetting directory not configured")
            return False
        
        # 排他制御: 同時実行を防止
        with self._mount_lock:
            try:
                appsetting_dir.mkdir(parents=True, exist_ok=True)
                mount_file = appsetting_dir / "sensor_mount_list.csv"
                backup_file = appsetting_dir / "sensor_mount_list.csv.bak"
                
                # バックアップ作成（既存ファイルがある場合）
                if mount_file.exists():
                    shutil.copy2(mount_file, backup_file)
                
                # 履歴記録: 変更差分を検出
                if record_history:
                    self._record_mount_changes(mount_df)
                
                # 保存
                mount_df.to_csv(mount_file, index=False, encoding="utf-8-sig")
                
                # 成功したらバックアップを削除
                if backup_file.exists():
                    backup_file.unlink()
                
                # キャッシュをクリア
                self._mount_cache = None
                logger.info(f"Mount info saved: {len(mount_df)} sensors")
                return True
                
            except Exception as e:
                logger.error(f"Failed to save mount info: {e}")
                # リカバリ: バックアップから復元
                if backup_file.exists():
                    try:
                        shutil.copy2(backup_file, mount_file)
                        logger.info("Mount info recovered from backup")
                    except Exception as restore_e:
                        logger.error(f"Failed to restore from backup: {restore_e}")
                return False
    
    def _record_mount_changes(self, new_mount_df: pd.DataFrame) -> None:
        """
        マウント情報の変更差分を履歴に記録（内部メソッド）
        
        現在の状態と新しい状態を比較し、差分を履歴として記録する。
        """
        # 現在の状態を取得
        current_mounts = self.get_mount_info()
        current_dict = {m.sensor_id: m for m in current_mounts}
        
        # 新しい状態をDictに変換
        new_dict = {}
        for _, row in new_mount_df.iterrows():
            sensor_id = str(row.get("SensorID", ""))
            if sensor_id:
                new_dict[sensor_id] = {
                    "equipment": str(row.get("EquipmentID", "Unknown")),
                    "device": str(row.get("DeviceID", "Unknown")),
                    "description": str(row.get("Remark", ""))
                }
        
        # 削除されたセンサ（現在あるが新規にない）
        for sensor_id, mount in current_dict.items():
            if sensor_id not in new_dict:
                self.save_mount_history(
                    sensor_id=sensor_id,
                    equipment=mount.equipment,
                    device=mount.device,
                    action="unmount",
                    description="UIから削除"
                )
        
        # 追加されたセンサ（新規にあるが現在ない）
        for sensor_id, info in new_dict.items():
            if sensor_id not in current_dict:
                self.save_mount_history(
                    sensor_id=sensor_id,
                    equipment=info["equipment"],
                    device=info["device"],
                    action="mount",
                    description="UIから追加"
                )
            else:
                # 変更されたセンサ（設備/装置が変わった）
                old = current_dict[sensor_id]
                if old.equipment != info["equipment"] or old.device != info["device"]:
                    # 旧マウントをunmount
                    self.save_mount_history(
                        sensor_id=sensor_id,
                        equipment=old.equipment,
                        device=old.device,
                        action="unmount",
                        description="ローテーション（旧）"
                    )
                    # 新マウントをmount
                    self.save_mount_history(
                        sensor_id=sensor_id,
                        equipment=info["equipment"],
                        device=info["device"],
                        action="mount",
                        description="ローテーション（新）"
                    )
    
    def save_mount_history(
        self,
        sensor_id: str,
        equipment: str,
        device: str,
        action: str,
        description: str = ""
    ) -> bool:
        """
        マウント履歴を記録（S+級: 時系列追跡）
        
        センサの取付/取外しイベントを時刻付きで記録する。
        
        Args:
            sensor_id: センサID
            equipment: 設備ID
            device: 装置ID
            action: "mount" または "unmount"
            description: 備考
            
        Returns:
            成功時True
        """
        appsetting_dir = self._get_appsetting_path()
        if appsetting_dir is None:
            return False
        
        try:
            appsetting_dir.mkdir(parents=True, exist_ok=True)
            history_file = appsetting_dir / "sensor_mount_history.csv"
            
            # 新しい履歴レコード
            new_record = {
                "Timestamp": datetime.now().isoformat(),
                "SensorID": sensor_id,
                "EquipmentID": equipment,
                "DeviceID": device,
                "Action": action,
                "Description": description
            }
            
            # 既存の履歴を読み込み（存在する場合）
            if history_file.exists():
                existing_df = pd.read_csv(history_file, encoding="utf-8-sig")
                history_df = pd.concat([
                    existing_df,
                    pd.DataFrame([new_record])
                ], ignore_index=True)
            else:
                history_df = pd.DataFrame([new_record])
            
            # 保存
            history_df.to_csv(history_file, index=False, encoding="utf-8-sig")
            logger.debug(f"Mount history recorded: {sensor_id} {action} at {equipment}/{device}")
            return True
            
        except Exception as e:
            logger.warning(f"Failed to record mount history: {sensor_id} {action} - {e}")
            return False
    
    def get_mount_history(
        self,
        sensor_id: Optional[str] = None,
        equipment: Optional[str] = None
    ) -> pd.DataFrame:
        """
        マウント履歴を取得（S+級: 時系列追跡）
        
        Args:
            sensor_id: フィルタするセンサID（Noneで全件）
            equipment: フィルタする設備ID（Noneで全件）
            
        Returns:
            履歴DataFrame（Timestamp, SensorID, EquipmentID, DeviceID, Action, Description）
        """
        appsetting_dir = self._get_appsetting_path()
        if appsetting_dir is None:
            return pd.DataFrame()
        
        history_file = appsetting_dir / "sensor_mount_history.csv"
        if not history_file.exists():
            return pd.DataFrame()
        
        try:
            df = pd.read_csv(history_file, encoding="utf-8-sig")
            
            # フィルタリング
            if sensor_id is not None:
                df = df[df["SensorID"] == sensor_id]
            if equipment is not None:
                df = df[df["EquipmentID"] == equipment]
            
            # 時刻順でソート
            if "Timestamp" in df.columns:
                df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
                df = df.sort_values("Timestamp", ascending=False)
            
            return df
            
        except Exception:
            return pd.DataFrame()


