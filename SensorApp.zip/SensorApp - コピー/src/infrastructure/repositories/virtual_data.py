"""
仮想データ生成モジュール (Version 3.0)

研究検証モード用の仮想時系列データを生成する。
シード固定による完全再現可能な乱数生成を行う。
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Literal
import numpy as np
import pandas as pd

from ...domain.entities.sensor import SensorData, MountInfo


# 異常タイプ定義
AnomalyType = Literal["spike", "shift", "trend", "none"]


@dataclass
class AnomalyScenario:
    """
    異常注入シナリオ
    
    仮想データに注入する異常パターンを定義する。
    """
    
    anomaly_type: AnomalyType = "spike"
    amplitude: float = 2.0          # 異常の振幅（標準偏差の倍数）
    duration: int = 10              # 異常の継続期間（ポイント数）
    injection_point: float = 0.7    # 注入位置（0.0-1.0、データ長に対する割合）
    
    # トレンド用パラメータ
    trend_slope: float = 0.01       # トレンドの傾き
    
    # スパイク用パラメータ
    spike_count: int = 5            # スパイクの数


class VirtualDataProvider:
    """
    仮想データプロバイダ
    
    研究検証モードで使用。シード固定で再現可能な仮想時系列データを生成し、
    異常パターンを注入する。
    
    Usage:
        provider = VirtualDataProvider(seed=42)
        
        # 正常データ生成
        normal_data = provider.get_sensor_data("VIRT-001")
        
        # 異常を注入したデータ生成
        scenario = AnomalyScenario(anomaly_type="spike", amplitude=3.0)
        anomaly_data = provider.get_sensor_data("VIRT-002", scenario=scenario)
    
    Important:
        同一シード・同一パラメータでは必ず同一の結果が得られる（再現性保証）
    """
    
    def __init__(self, seed: int = 42):
        """
        初期化
        
        Args:
            seed: 乱数シード（再現性用）
        """
        self.seed = seed
        self._rng = np.random.default_rng(seed)
        self._mount_cache: Optional[List[MountInfo]] = None
    
    def reset_seed(self, seed: Optional[int] = None) -> None:
        """
        乱数シードをリセット
        
        Args:
            seed: 新しいシード（Noneなら初期シードを再利用）
        """
        if seed is not None:
            self.seed = seed
        self._rng = np.random.default_rng(self.seed)
    
    def get_sensor_data(
        self,
        sensor_id: str,
        *,
        n_points: int = 1000,
        scenario: Optional[AnomalyScenario] = None,
        start_date: Optional[datetime] = None
    ) -> SensorData:
        """
        仮想センサデータを生成
        
        Args:
            sensor_id: センサID
            n_points: データ点数
            scenario: 異常シナリオ（Noneなら正常データのみ）
            start_date: 開始日時（Noneなら現在時刻から計算）
            
        Returns:
            SensorData: 仮想センサデータ
        """
        # シードをセンサIDで調整（同じIDなら同じデータ）
        sensor_seed = self.seed + hash(sensor_id) % 10000
        rng = np.random.default_rng(sensor_seed)
        
        # 時刻列生成
        if start_date is None:
            start_date = datetime.now() - timedelta(hours=n_points)
        
        timestamps = pd.date_range(start=start_date, periods=n_points, freq="h")
        
        # 正常データ生成（現実的な振動RMSデータを模倣）
        rms_values = self._generate_normal_rms(rng, n_points)
        
        # 異常注入
        if scenario is not None:
            rms_values, labels = self._inject_anomaly(
                rms_values, scenario, rng
            )
        else:
            labels = np.zeros(n_points, dtype=int)
        
        # DataFrameを構築
        df = pd.DataFrame({
            "timestamp": timestamps,
            "RMS": rms_values,
            "label": labels  # Ground Truth（研究用）
        })
        
        return SensorData(
            sensor_id=sensor_id,
            dataframe=df,
            time_column="timestamp",
            value_columns=["RMS"]
        )
    
    def get_mount_info(self) -> List[MountInfo]:
        """
        仮想マウント情報を取得
        
        Returns:
            List[MountInfo]: 仮想マウント情報リスト
        """
        if self._mount_cache is not None:
            return self._mount_cache
        
        # 固定の仮想マウント情報を生成
        mounts = [
            MountInfo(
                sensor_id="VIRT-001",
                equipment="VirtualPump-A",
                device="VirtualMotor-1",
                description="仮想センサ（正常パターン）"
            ),
            MountInfo(
                sensor_id="VIRT-002",
                equipment="VirtualPump-A",
                device="VirtualMotor-2",
                description="仮想センサ（スパイク異常）"
            ),
            MountInfo(
                sensor_id="VIRT-003",
                equipment="VirtualPump-B",
                device="VirtualMotor-1",
                description="仮想センサ（トレンド異常）"
            ),
            MountInfo(
                sensor_id="VIRT-004",
                equipment="VirtualPump-B",
                device="VirtualMotor-2",
                description="仮想センサ（シフト異常）"
            ),
        ]
        
        self._mount_cache = mounts
        return mounts
    
    def list_sensors(self) -> List[str]:
        """
        利用可能な仮想センサIDリストを取得
        
        Returns:
            List[str]: センサIDリスト
        """
        return [m.sensor_id for m in self.get_mount_info()]
    
    def generate_case_dataset(
        self,
        base_sensor_id: str = "CASE",
        n_points: int = 500,
        include_anomaly: bool = True
    ) -> Dict[str, SensorData]:
        """
        論文用ケースデータセットを生成
        
        Case0: 正常データ（ベースライン）
        Case1: スパイク異常
        Case2: シフト異常
        Case3: トレンド異常
        
        Returns:
            Dict[str, SensorData]: ケース名 -> データの辞書
        """
        cases = {}
        
        # Case0: 正常
        cases["case0"] = self.get_sensor_data(
            f"{base_sensor_id}-CASE0",
            n_points=n_points,
            scenario=None
        )
        
        if include_anomaly:
            # Case1: スパイク
            cases["case1"] = self.get_sensor_data(
                f"{base_sensor_id}-CASE1",
                n_points=n_points,
                scenario=AnomalyScenario(
                    anomaly_type="spike",
                    amplitude=3.0,
                    spike_count=3
                )
            )
            
            # Case2: シフト
            cases["case2"] = self.get_sensor_data(
                f"{base_sensor_id}-CASE2",
                n_points=n_points,
                scenario=AnomalyScenario(
                    anomaly_type="shift",
                    amplitude=2.0,
                    duration=50
                )
            )
            
            # Case3: トレンド
            cases["case3"] = self.get_sensor_data(
                f"{base_sensor_id}-CASE3",
                n_points=n_points,
                scenario=AnomalyScenario(
                    anomaly_type="trend",
                    trend_slope=0.02
                )
            )
        
        return cases
    
    def _generate_normal_rms(
        self,
        rng: np.random.Generator,
        n_points: int
    ) -> np.ndarray:
        """
        正常なRMS時系列を生成
        
        現実的な振動RMSデータを模倣：
        - ベースレベル + ノイズ
        - 日周期の変動
        - ゆるやかなドリフト
        """
        # ベースレベル（0.5〜1.5 m/s²程度）
        base_level = 1.0 + rng.uniform(-0.3, 0.3)
        
        # ホワイトノイズ（標準偏差 0.1程度）
        noise = rng.normal(0, 0.1, n_points)
        
        # 日周期変動（振幅 0.1程度）
        t = np.arange(n_points)
        daily_cycle = 0.1 * np.sin(2 * np.pi * t / 24)
        
        # ゆるやかなドリフト
        drift = 0.0002 * t
        
        rms = base_level + noise + daily_cycle + drift
        
        # 負値を防ぐ
        rms = np.maximum(rms, 0.01)
        
        return rms
    
    def _inject_anomaly(
        self,
        values: np.ndarray,
        scenario: AnomalyScenario,
        rng: np.random.Generator
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        異常パターンを注入
        
        Returns:
            (異常注入後の値, ラベル配列)
        """
        n = len(values)
        labels = np.zeros(n, dtype=int)
        
        # 注入開始位置
        start_idx = int(n * scenario.injection_point)
        
        if scenario.anomaly_type == "spike":
            values, labels = self._inject_spike(
                values, labels, start_idx, scenario, rng
            )
        
        elif scenario.anomaly_type == "shift":
            values, labels = self._inject_shift(
                values, labels, start_idx, scenario
            )
        
        elif scenario.anomaly_type == "trend":
            values, labels = self._inject_trend(
                values, labels, start_idx, scenario
            )
        
        return values, labels
    
    def _inject_spike(
        self,
        values: np.ndarray,
        labels: np.ndarray,
        start_idx: int,
        scenario: AnomalyScenario,
        rng: np.random.Generator
    ) -> tuple[np.ndarray, np.ndarray]:
        """スパイク異常を注入"""
        n = len(values)
        std = np.std(values)
        
        for i in range(scenario.spike_count):
            # スパイク位置をランダムに決定
            spike_idx = start_idx + rng.integers(0, n - start_idx)
            if spike_idx >= n:
                continue
            
            # スパイクの幅
            spike_width = min(scenario.duration, n - spike_idx)
            
            for j in range(spike_width):
                idx = spike_idx + j
                if idx < n:
                    # ガウシアンスパイク形状
                    decay = np.exp(-0.5 * (j / max(spike_width / 2, 1)) ** 2)
                    values[idx] += scenario.amplitude * std * decay
                    labels[idx] = 1
        
        return values, labels
    
    def _inject_shift(
        self,
        values: np.ndarray,
        labels: np.ndarray,
        start_idx: int,
        scenario: AnomalyScenario
    ) -> tuple[np.ndarray, np.ndarray]:
        """シフト異常（レベル変化）を注入"""
        n = len(values)
        std = np.std(values)
        
        end_idx = min(start_idx + scenario.duration, n)
        
        # 急激なレベル変化
        values[start_idx:end_idx] += scenario.amplitude * std
        labels[start_idx:end_idx] = 1
        
        return values, labels
    
    def _inject_trend(
        self,
        values: np.ndarray,
        labels: np.ndarray,
        start_idx: int,
        scenario: AnomalyScenario
    ) -> tuple[np.ndarray, np.ndarray]:
        """トレンド異常（徐変劣化）を注入"""
        n = len(values)
        
        # start_idx以降に上昇トレンドを追加
        for i in range(start_idx, n):
            values[i] += scenario.trend_slope * (i - start_idx)
            # トレンドが顕著になる後半をラベル付け
            if (i - start_idx) > (n - start_idx) * 0.3:
                labels[i] = 1
        
        return values, labels
