"""
グラフコンポーネントモジュール (Version 3.0)

Altairを使用したグラフ描画関数群。
RMS推移、異常スコア、未来予測のグラフを生成する。

Note:
    - 明示的なオブジェクト指定（field=, type=）を使用
    - LayerChartにはmark系メソッドを呼ばない
"""

import altair as alt
import pandas as pd
import numpy as np
from typing import Optional, Union

from ...domain.entities.analysis import AnalysisResult, FutureForecast
from ...domain.entities.sensor import SensorData


def _get_time_type(df: pd.DataFrame, col: str) -> str:
    """列の型に応じたAltairタイプを返す"""
    if col in df.columns and pd.api.types.is_datetime64_any_dtype(df[col]):
        return "temporal"
    return "quantitative"


def _normalize_width(width) -> Optional[int]:
    """widthを数値に正規化（"container"などは無視）"""
    if isinstance(width, int):
        return width
    return None


def create_rms_chart(
    sensor_data: SensorData,
    analysis_result: Optional[AnalysisResult] = None,
    *,
    height: int = 300,
    width: Union[int, str] = 600
) -> alt.Chart:
    """
    RMS推移グラフを作成（異常スコアとの2軸表示）
    
    Args:
        sensor_data: センサデータ
        analysis_result: 分析結果（異常スコア表示用）
        height: グラフ高さ
        width: グラフ幅（"container"の場合は無視）
        
    Returns:
        Altair Chart
    """
    if sensor_data.is_empty:
        return _empty_chart("データがありません", 600, height)
    
    df = sensor_data.dataframe.copy()
    time_col = sensor_data.time_column
    value_col = sensor_data.value_columns[0] if sensor_data.value_columns else "RMS"
    
    # 時刻列がない場合はインデックスを使用
    if time_col is None or time_col not in df.columns:
        df["_index"] = range(len(df))
        time_col = "_index"
    
    # 値列がない場合
    if value_col not in df.columns:
        return _empty_chart(f"値列 '{value_col}' がありません", 600, height)
    
    time_type = _get_time_type(df, time_col)
    
    # RMSラインチャート
    rms_line = alt.Chart(df).mark_line(
        color="#1f77b4",
        strokeWidth=2
    ).encode(
        x=alt.X(field=time_col, type=time_type, title="時刻"),
        y=alt.Y(field=value_col, type="quantitative", title="RMS [m/s²]", scale=alt.Scale(zero=False)),
        tooltip=[
            alt.Tooltip(field=time_col, type=time_type), 
            alt.Tooltip(field=value_col, type="quantitative")
        ]
    )
    
    # 異常スコアがある場合は2軸表示
    if analysis_result is not None and analysis_result.length > 0:
        scores = analysis_result.integrated_scores
        n = min(len(df), len(scores))
        
        if n > 0:
            df_score = df.tail(n).copy()
            df_score["_anomaly_score"] = scores[-n:]
            
            score_time_type = _get_time_type(df_score, time_col)
            
            # スコアライン（青緑一色 - 赤は心理的負担が大きいため排除）
            score_line = alt.Chart(df_score).mark_line(
                color="#17becf",  # 青緑一色
                strokeWidth=1.5,
                strokeDash=[4, 2]
            ).encode(
                x=alt.X(field=time_col, type=score_time_type),
                y=alt.Y(
                    field="_anomaly_score",
                    type="quantitative",
                    title="異常スコア",
                    scale=alt.Scale(domain=[0, 1])
                ),
                tooltip=[alt.Tooltip(field="_anomaly_score", type="quantitative", title="異常スコア")]
            )
            
            # 2軸表示: 各チャートを独立してレイヤー化
            # resolve_scaleはLayerChart全体に適用
            chart = alt.layer(rms_line, score_line).resolve_scale(
                y="independent"
            ).properties(
                height=height,
                title="RMS推移と異常スコア"
            )
            
            return chart
    
    # 異常スコアなしの場合
    chart = rms_line.properties(
        height=height,
        title="RMS推移"
    )
    
    return chart


def create_forecast_chart(
    forecast: FutureForecast,
    history: Optional[pd.DataFrame] = None,
    history_time_col: str = "timestamp",
    history_value_col: str = "RMS",
    *,
    height: int = 300,
    width: Union[int, str] = 600
) -> alt.Chart:
    """
    未来予測グラフを作成（信頼区間の帯付き）
    
    Args:
        forecast: 予測結果
        history: 過去データ（表示用）
        history_time_col: 時刻列名
        history_value_col: 値列名
        height: グラフ高さ
        width: グラフ幅
        
    Returns:
        Altair Chart
    """
    if forecast.length == 0:
        return _empty_chart("予測データがありません", 600, height)
    
    # 予測データをDataFrame化
    df_forecast = forecast.to_dataframe()
    
    # 信頼区間の帯
    band = alt.Chart(df_forecast).mark_area(
        opacity=0.3,
        color="#ff7f0e"
    ).encode(
        x=alt.X(field="date", type="temporal", title="日付"),
        y=alt.Y(field="lower", type="quantitative", title="予測値"),
        y2=alt.Y2(field="upper")
    )
    
    # 予測ライン
    forecast_line = alt.Chart(df_forecast).mark_line(
        color="#ff7f0e",
        strokeWidth=2
    ).encode(
        x=alt.X(field="date", type="temporal"),
        y=alt.Y(field="forecast", type="quantitative", scale=alt.Scale(zero=False)),
        tooltip=[
            alt.Tooltip(field="date", type="temporal"),
            alt.Tooltip(field="forecast", type="quantitative"),
            alt.Tooltip(field="lower", type="quantitative"),
            alt.Tooltip(field="upper", type="quantitative")
        ]
    )
    
    layers = [band, forecast_line]
    
    # 過去データがあれば追加
    if history is not None and not history.empty:
        if history_time_col in history.columns and history_value_col in history.columns:
            df_hist = history[[history_time_col, history_value_col]].copy()
            df_hist.columns = ["_hist_date", "_hist_value"]
            
            history_line = alt.Chart(df_hist).mark_line(
                color="#1f77b4",
                strokeWidth=1.5
            ).encode(
                x=alt.X(field="_hist_date", type="temporal"),
                y=alt.Y(field="_hist_value", type="quantitative", scale=alt.Scale(zero=False))
            )
            layers.insert(0, history_line)
    
    chart = alt.layer(*layers).properties(
        height=height,
        title=f"未来予測（{int(forecast.confidence_level * 100)}%信頼区間）"
    )
    
    return chart


def create_score_components_chart(
    analysis_result: AnalysisResult,
    *,
    height: int = 200,
    width: Union[int, str] = 600
) -> alt.Chart:
    """
    スコア成分の内訳チャートを作成
    
    Args:
        analysis_result: 分析結果
        height: グラフ高さ
        width: グラフ幅
        
    Returns:
        Altair Chart
    """
    if not analysis_result.components:
        return _empty_chart("スコア成分がありません", 600, height)
    
    # 各成分の平均スコアをバーチャートで表示
    data = []
    for comp in analysis_result.components:
        valid_scores = comp.normalized_scores[np.isfinite(comp.normalized_scores)]
        if len(valid_scores) > 0:
            data.append({
                "model": comp.model_name,
                "score": float(np.mean(valid_scores)),
                "weight": comp.weight
            })
    
    if not data:
        return _empty_chart("有効なスコアがありません", 600, height)
    
    df = pd.DataFrame(data)
    
    chart = alt.Chart(df).mark_bar().encode(
        x=alt.X(field="model", type="nominal", title="モデル"),
        y=alt.Y(field="score", type="quantitative", title="平均スコア", scale=alt.Scale(domain=[0, 1])),
        color=alt.Color(field="model", type="nominal", legend=None),
        tooltip=[
            alt.Tooltip(field="model", type="nominal"),
            alt.Tooltip(field="score", type="quantitative"),
            alt.Tooltip(field="weight", type="quantitative")
        ]
    ).properties(
        height=height,
        title="モデル別スコア内訳"
    )
    
    return chart


def create_anomaly_timeline(
    sensor_data: SensorData,
    analysis_result: AnalysisResult,
    *,
    height: int = 120,
    width: Union[int, str] = 600
) -> alt.Chart:
    """
    異常検出タイムラインを作成
    """
    if sensor_data.is_empty or analysis_result.length == 0:
        return _empty_chart("データがありません", 600, height)
    
    df = sensor_data.dataframe.copy()
    time_col = sensor_data.time_column
    
    scores = analysis_result.integrated_scores
    n = min(len(df), len(scores))
    
    if n == 0:
        return _empty_chart("データがありません", 600, height)
    
    df = df.tail(n).copy()
    df["_score"] = scores[-n:]
    df["_is_anomaly"] = df["_score"] > analysis_result.threshold
    
    if time_col is None or time_col not in df.columns:
        df["_index"] = range(len(df))
        time_col = "_index"
    
    time_type = _get_time_type(df, time_col)
    anomaly_count = int(df["_is_anomaly"].sum())
    
    # 異常データのみ抽出
    df_anomaly = df[df["_is_anomaly"]].copy()
    
    # ベースチャート（全期間のX軸確保用）
    base = alt.Chart(df).mark_point(size=0, opacity=0).encode(
        x=alt.X(field=time_col, type=time_type, title="時刻")
    )
    
    # 異常点を赤いtickで表示（Y軸エンコードでX軸との重なりを防止）
    if not df_anomaly.empty:
        anomalies = alt.Chart(df_anomaly).mark_tick(
            color="#d62728",
            thickness=3,
            size=35  # tickの長さ
        ).encode(
            x=alt.X(field=time_col, type=time_type),
            y=alt.Y(
                datum=0.7,  # プロット領域の上部70%の位置を基準に描画
                type="quantitative",
                axis=None,
                scale=alt.Scale(domain=[0, 1])
            ),
            tooltip=[
                alt.Tooltip(field=time_col, type=time_type, title="時刻"),
                alt.Tooltip(field="_score", type="quantitative", title="スコア", format=".3f")
            ]
        )
        chart = base + anomalies
    else:
        chart = base
    
    return chart.properties(
        height=height,
        title=f"異常タイムライン（{anomaly_count}件）"
    )


def _empty_chart(message: str, width: int, height: int) -> alt.Chart:
    """空のチャートを作成"""
    df = pd.DataFrame({"_msg": [message]})
    return alt.Chart(df).mark_text(
        fontSize=14,
        color="gray"
    ).encode(
        text=alt.Text(field="_msg", type="nominal")
    ).properties(
        height=height
    )
