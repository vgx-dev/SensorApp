"""
サイドバーコンポーネントモジュール (Version 3.0)

Streamlit サイドバーの描画を担当。
モード切替、アプリ情報、設定へのリンクを提供する。
"""

import streamlit as st
from typing import Callable, Optional

from ...application.state_manager import StateManager
from ...application.context import AppMode


def render_sidebar(
    state: StateManager,
    *,
    on_mode_change: Optional[Callable[[AppMode], None]] = None
) -> None:
    """
    サイドバーを描画
    
    Args:
        state: 状態マネージャー
        on_mode_change: モード変更時のコールバック
    """
    with st.sidebar:
        # アプリタイトル
        st.markdown("## 🔧 SensorApp v3.0")
        st.divider()
        
        # モード切替
        st.markdown("### モード選択")
        
        mode_options = {
            AppMode.OPERATIONAL: "🏭 運用モード",
            AppMode.RESEARCH: "🧪 研究検証モード"
        }
        
        current_mode = state.mode
        
        selected_label = st.radio(
            "動作モード",
            options=list(mode_options.values()),
            index=0 if current_mode == AppMode.OPERATIONAL else 1,
            label_visibility="collapsed"
        )
        
        # ラベルからモードを逆引き
        new_mode = AppMode.OPERATIONAL
        for mode, label in mode_options.items():
            if label == selected_label:
                new_mode = mode
                break
        
        # モード変更時の処理
        if new_mode != current_mode:
            state.mode = new_mode
            if on_mode_change:
                on_mode_change(new_mode)
            st.rerun()
        
        st.divider()
        
        # モード別情報
        if state.mode == AppMode.OPERATIONAL:
            _render_operational_info(state)
        else:
            _render_research_info(state)
        
        st.divider()
        
        # アプリ情報
        _render_app_info()


def _render_operational_info(state: StateManager) -> None:
    """運用モード情報を表示"""
    st.markdown("### 📊 運用情報")
    
    ctx = state.operational
    
    if ctx.selected_sensor_id:
        st.info(f"選択中: **{ctx.selected_sensor_id}**")
    else:
        st.warning("センサ未選択")
    
    # 表示設定
    st.markdown("**表示設定**")
    
    show_score = st.checkbox(
        "異常スコア表示",
        value=ctx.show_anomaly_score,
        key="sidebar_show_score"
    )
    if show_score != ctx.show_anomaly_score:
        state.update_operational(show_anomaly_score=show_score)
    
    show_forecast = st.checkbox(
        "未来予測表示",
        value=ctx.show_forecast,
        key="sidebar_show_forecast"
    )
    if show_forecast != ctx.show_forecast:
        state.update_operational(show_forecast=show_forecast)


def _render_research_info(state: StateManager) -> None:
    """研究モード情報を表示"""
    st.markdown("### 🔬 研究設定")
    
    ctx = state.research
    
    st.info(f"シード: **{ctx.random_seed}**")
    
    # シナリオタイプ
    scenario_type = ctx.params.get("type", "spike")
    st.markdown(f"シナリオ: **{scenario_type}**")
    
    # パラメータサマリ
    with st.expander("パラメータ詳細"):
        for key, value in ctx.params.items():
            st.text(f"{key}: {value}")


def _render_app_info() -> None:
    """アプリ情報を表示"""
    st.markdown("### ℹ️ アプリ情報")
    
    st.markdown("""
    **センサデータ監視・AI予兆検知システム**  
    Version 3.0
    
    - 運用: 実データ監視
    - 研究: 再現性検証
    """)
    
    with st.expander("バージョン情報"):
        st.code("""
アーキテクチャ: レイヤード
UI: Streamlit
AI: IF/AE/LSTM
        """)
