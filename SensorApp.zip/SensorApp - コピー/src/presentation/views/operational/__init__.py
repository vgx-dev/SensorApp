"""
運用モード画面パッケージ (Version 3.6)

実機センサデータの監視・保全判断支援を行う画面。
外部からは従来通り `from src.presentation.views import operational; operational.render()` で使用可能。

v3.7: モジュール分割
- 責務ごとに4モジュールに分割（data_view, sensor_management, measurement_stats, settings）
- インポート互換性を維持（main.pyの変更不要）
"""

import streamlit as st
import pandas as pd
from typing import Dict, Any
from pathlib import Path
from functools import lru_cache
import time

from ....application.state_manager import StateManager
from ....application.services import AnalysisService
from ....application.management_service import ManagementService

# サブモジュールのインポート
from . import data_view
from . import sensor_management
from . import measurement_stats


# ==================== キャッシュユーティリティ ====================
# NOTE: 2種類のキャッシュを使い分ける
# 1. @st.cache_data: Streamlit管理、セッション横断型（マスタデータ）
# 2. @lru_cache: Pythonビルトイン、プロセス単位（stat()呼び出し抑制）

@st.cache_data(show_spinner=False)
def _get_cached_master_data(_mgmt_service: ManagementService, _file_mtime: float) -> Dict[str, Any]:
    """
    マスタデータをキャッシュ付きで取得
    
    ファイル更新時刻が変わるとキャッシュ無効化される（TTLなし）。
    """
    return {
        "sensor_options": _mgmt_service.get_sensor_options(),
        "user_options": _mgmt_service.get_user_options(),
        "equipment_options": _mgmt_service.get_equipment_options(),
        "device_pairs": _mgmt_service.get_equipment_device_pairs(),
    }


@lru_cache(maxsize=1)
def _get_cached_mtime_ref(path_str: str, ttl_bucket: int) -> float:
    """
    ファイル更新時刻を取得（メモリキャッシュ付き）
    
    TTLバケットが変わるまで（＝1秒間）はキャッシュを返すことで、
    ループ内などでの過剰なディスクアクセスを抑制する。
    """
    p = Path(path_str)
    try:
        if p.exists():
            return p.stat().st_mtime
    except Exception:
        pass
    return 0.0


def _get_file_mtime(mgmt_service: ManagementService) -> float:
    """マウント履歴ファイルの更新時刻を取得（最適化版）"""
    path = mgmt_service.get_mount_file_path()  # パブリックAPIを使用
    # 現在時刻を1秒単位で丸めたものをキーにする＝1秒間はキャッシュ有効
    return _get_cached_mtime_ref(str(path), int(time.time()))


def _get_master_data(mgmt_service: ManagementService) -> Dict[str, Any]:
    """マスタデータを取得（キャッシュ経由）"""
    file_mtime = _get_file_mtime(mgmt_service)
    return _get_cached_master_data(mgmt_service, file_mtime)


def _save_last_input(equipment_id: str, device_id: str) -> None:
    """前回の入力を保存"""
    if "last_mount_input" not in st.session_state:
        st.session_state.last_mount_input = {}
    st.session_state.last_mount_input["equipment"] = equipment_id
    st.session_state.last_mount_input["device"] = device_id


def _get_last_input() -> Dict[str, str]:
    """前回の入力を取得"""
    if "last_mount_input" in st.session_state:
        return st.session_state.last_mount_input
    return {"equipment": "", "device": ""}


@st.cache_data(show_spinner=False)
def _get_cached_stats(_mgmt_service: ManagementService, _file_mtime: float) -> pd.DataFrame:
    """測定実績統計をキャッシュ付きで取得"""
    return _mgmt_service.aggregate_measurement_stats()


@st.cache_data(show_spinner=False)
def _get_cached_mount_history(_mgmt_service: ManagementService, _file_mtime: float) -> pd.DataFrame:
    """マウント履歴をキャッシュ付きで取得（v3.7追加）"""
    return _mgmt_service.get_mount_history()


def _get_mount_history(mgmt_service: ManagementService) -> pd.DataFrame:
    """マウント履歴を取得（キャッシュ経由）"""
    file_mtime = _get_file_mtime(mgmt_service)
    return _get_cached_mount_history(mgmt_service, file_mtime)

# ==================== メインrender関数 ====================

def render(state: StateManager, service: AnalysisService) -> None:
    """
    運用モード画面のエントリーポイント
    
    NOTE: 外部APIの互換性を維持。main.pyのインポートは変更不要。
    """
    mgmt_service = ManagementService(service.config)
    
    # タブ構成（運用モード）
    tabs = st.tabs([
        "📊 データビュー",
        "📡 センサ管理",
        "📈 測定実績",
        "🤖 AIモデル",
        "⚙️ 設定"
    ])
    
    with tabs[0]:
        data_view.render_data_view(state, service, mgmt_service)
    
    with tabs[1]:
        sensor_management.render_sensor_management(
            state, service, mgmt_service,
            _get_cached_master_data, _get_cached_stats, _get_mount_history
        )
    
    with tabs[2]:
        measurement_stats.render_measurement_stats(
            state, mgmt_service,
            _get_file_mtime, _get_cached_stats
        )
    
    with tabs[3]:
        data_view.render_ai_model(state, service)
    
    with tabs[4]:
        measurement_stats.render_settings(state, service)
