"""
データビュータブとAIモデルタブ (Version 3.6)

実機センサデータの監視画面とAIモデル情報表示を担当。
"""

import streamlit as st
from typing import Optional
from datetime import datetime

from ....application.state_manager import StateManager
from ....application.services import AnalysisService, AnalysisContext
from ....application.management_service import ManagementService
from ....application.context import AppMode
from ...components.charts import (
    create_rms_chart,
    create_forecast_chart
)


def render_data_view(state: StateManager, service: AnalysisService, mgmt_service: ManagementService) -> None:
    """データビュータブを描画"""
    
    st.markdown("### センサデータ監視")
    
    # センサ選択
    sensors = service.list_sensors(AppMode.OPERATIONAL)
    
    if not sensors:
        st.warning("📭 利用可能なセンサがありません。「センサ管理」タブでセンサを登録するか、データフォルダを確認してください。")
        
        # デモ用：仮想データで表示
        with st.expander("🧪 デモモードで表示（仮想データ）"):
            if st.button("デモデータを表示"):
                _show_demo_data(state, service)
        return
    
    # センサ選択ボックス
    ctx = state.operational
    current_sensor = ctx.selected_sensor_id
    
    # 初期選択: stateが未設定またはリストにない場合は先頭を選択
    if current_sensor is None or current_sensor not in sensors:
        current_sensor = sensors[0]
        state.update_operational(selected_sensor_id=current_sensor)
    
    # センサ選択UI
    try:
        current_index = sensors.index(current_sensor)
    except ValueError:
        current_index = 0
    
    selected_sensor = st.selectbox(
        "センサ選択",
        options=sensors,
        index=current_index,
        key="operational_sensor_select"
    )
    
    # 選択が変更された場合はstateを更新
    if selected_sensor != ctx.selected_sensor_id:
        state.update_operational(selected_sensor_id=selected_sensor)
        st.rerun()
    
    # データ表示
    if selected_sensor:  
        _display_sensor_data(state, service, selected_sensor, mgmt_service)


def _display_sensor_data(
    state: StateManager,
    service: AnalysisService,
    sensor_id: str,
    mgmt_service: Optional[ManagementService] = None
) -> None:
    """センサデータを表示"""
    
    ctx = state.operational
    
    # センサコンテキスト（設備・装置・管理者）を表示
    if mgmt_service:
        context = mgmt_service.get_sensor_context(sensor_id)
        if context:
            # 管理者情報を取得
            manager = mgmt_service.get_manager_suggestion(context.equipment, context.device)
            
            # マウント期間を表示
            mount_info_text = f"📍 **設備:** {context.equipment} 　**装置:** {context.device}"
            if manager:
                mount_info_text += f" 　**管理者:** {manager}"
            
            st.info(mount_info_text)
            
            # マウント期間の明示（データフィルタリング範囲の説明）
            if context.mount_date:
                if context.unmount_date:
                    # 遊休センサー（EndTime記録済）
                    st.caption(
                        f"📅 マウント期間: {context.mount_date.strftime('%Y-%m-%d %H:%M')} 〜 "
                        f"{context.unmount_date.strftime('%Y-%m-%d %H:%M')} （分析対象期間）"
                    )
                else:
                    # 測定中センサー（EndTime未記録）
                    st.caption(
                        f"📅 マウント開始: {context.mount_date.strftime('%Y-%m-%d %H:%M')} 〜 現在 （分析対象期間）"
                    )
        else:
            st.caption("⚠️ このセンサのマウント情報が未登録です。「センサ管理」タブから登録してください。")
    
    # 分析実行
    with st.spinner("データを読み込み中..."):
        try:
            context = AnalysisContext(
                sensor_id=sensor_id,
                mode=AppMode.OPERATIONAL,
                tail_rows=1000  # 最新1000点
            )
            result = service.run_analysis(context)
            
        except Exception as e:
            st.error(f"❌ データの読み込みに失敗しました: {str(e)}")
            return
    
    sensor_data = result.get("sensor_data")
    analysis_result = result.get("analysis_result")
    forecast = result.get("forecast")
    
    if sensor_data is None or sensor_data.is_empty:
        st.warning("📭 データが見つかりません")
        return
    
    # メトリクス
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("データ点数", sensor_data.length)
    
    with col2:
        if analysis_result:
            score = analysis_result.mean_score
            delta_color = "inverse" if score > 0.7 else "normal"
            st.metric("平均異常スコア", f"{score:.3f}", delta_color=delta_color)
    
    with col3:
        if forecast:
            st.metric("予測トレンド", "↗️ 上昇" if forecast.is_increasing_trend else "↘️ 安定")
    
    with col4:
        # Phase 3: ステータス判定をForecasterと統一 (mean_score > 0.7)
        if analysis_result and analysis_result.mean_score > 0.7:
            st.metric("ステータス", "⚠️ 要注意", delta="変動傾向", delta_color="inverse")
        else:
            st.metric("ステータス", "✅ 正常")
    
    st.divider()
    
    # グラフ表示
    if ctx.show_anomaly_score:
        st.markdown("#### RMS推移・異常スコア")
        chart = create_rms_chart(sensor_data, analysis_result)
        st.altair_chart(chart, use_container_width=True)
    else:
        st.markdown("#### RMS推移")
        chart = create_rms_chart(sensor_data, None)
        st.altair_chart(chart, use_container_width=True)
    
    # 未来予測
    if ctx.show_forecast and forecast and forecast.length > 0:
        with st.expander("📈 未来予測", expanded=False):
            chart = create_forecast_chart(
                forecast,
                history=sensor_data.dataframe,
                history_time_col=sensor_data.time_column,
                history_value_col=sensor_data.value_columns[0] if sensor_data.value_columns else "RMS"
            )
            st.altair_chart(chart, use_container_width=True)
            
            # ★ S級: メンテナンス推奨の表示
            if forecast.maintenance:
                st.divider()
                maint = forecast.maintenance
                if maint.urgency == "immediate":
                    st.error(f"🚨 **即対応が必要** ({maint.confidence}信頼度)\n\n{maint.reasoning}")
                elif maint.urgency == "scheduled":
                    st.warning(f"⚠️ **計画的メンテナンス推奨** ({maint.confidence}信頼度)\n\n{maint.reasoning}")
                else:
                    st.success(f"✅ **監視継続** ({maint.confidence}信頼度)\n\n{maint.reasoning}")
            
            # Phase 3: 異常検知による不確実性警告を表示
            if forecast.reason_message:
                st.warning(forecast.reason_message)
            
            st.info(f"📊 トレンド傾き: {forecast.trend_slope:.4f} /日")
    
    
    
    # データテーブル
    with st.expander("📋 生データ"):
        st.dataframe(sensor_data.dataframe.tail(100), use_container_width=True)


def _show_demo_data(state: StateManager, service: AnalysisService) -> None:
    """デモデータを表示（仮想データ使用）"""
    
    with st.spinner("デモデータを生成中..."):
        # NOTE: デモデータ生成には仮想データプロバイダを使用するためRESEARCHモードを指定
        # 運用画面内での使用だが、VirtualDataProviderへのアクセスにはRESEARCHモードが必要
        context = AnalysisContext(
            sensor_id="DEMO-001",
            mode=AppMode.RESEARCH,
            n_points=300,
            random_seed=42
        )
        result = service.run_analysis(context)
    
    sensor_data = result.get("sensor_data")
    analysis_result = result.get("analysis_result")
    
    if sensor_data:
        st.success("デモデータを表示しています")
        chart = create_rms_chart(sensor_data, analysis_result)
        st.altair_chart(chart, use_container_width=True)


def render_ai_model(state: StateManager, service: AnalysisService) -> None:
    """AIモデルタブを描画"""
    
    st.markdown("### AIモデル情報")
    
    # モデル設定の表示
    config = service.config
    
    st.markdown("#### 現在の設定")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**異常検知パラメータ**")
        st.json({
            "IF n_estimators": config.ai_params.if_n_estimators,
            "IF contamination": config.ai_params.if_contamination,
            "IF weight": config.ai_params.weight_if,
            "AE weight": config.ai_params.weight_ae,
            "LSTM weight": config.ai_params.weight_lstm
        })
    
    with col2:
        st.markdown("**予測パラメータ**")
        st.json({
            "Forecast days": config.forecast_params.forecast_days,
            "Confidence level": config.forecast_params.confidence_level,
            "Trend window": config.forecast_params.trend_window
        })
    
    st.divider()
    
    # モデルストレージ情報
    st.markdown("#### モデルストレージ")
    
    model_dir = config.paths.get_model_path()
    
    st.info(f"📂 モデル保存先: `{model_dir}`")
    
    if st.button("モデル一覧を更新"):
        st.rerun()

