"""
測定実績タブと設定タブ (Version 3.6)

測定実績の集計表示とシステム設定を担当。
"""

import streamlit as st
import pandas as pd
import altair as alt

from ....application.state_manager import StateManager
from ....application.services import AnalysisService
from ....application.management_service import ManagementService


def render_measurement_stats(state: StateManager, mgmt_service: ManagementService, get_file_mtime, get_cached_stats) -> None:
    """測定実績タブを描画"""
    
    st.markdown("### 測定実績")
    
    # キャッシュ付きで集計データ取得
    file_mtime = get_file_mtime(mgmt_service)
    stats = get_cached_stats(mgmt_service, file_mtime)
    
    if stats.empty:
        st.info("📭 測定実績データがありません。「センサ管理」タブでマウント履歴を登録してください。")
        return
    
    # ヘッダーとフィルタを横並び
    col_title, col_filter = st.columns([3, 1])
    with col_title:
        pass  # タイトルは上に表示済み
    with col_filter:
        show_current_only = st.checkbox("現在取付中のみ", value=False, key="stats_filter_current")
    
    # フィルタ適用
    if show_current_only:
        stats = stats[stats["is_current"] == True]
        if stats.empty:
            st.info("📭 現在取付中の設備/装置はありません。")
            return
    
    # メトリクス
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("総登録数", len(stats))
    
    with col2:
        current_count = stats["is_current"].sum()
        st.metric("現在取付中", int(current_count))
    
    with col3:
        total_measurements = stats["count"].sum()
        st.metric("総測定回数", int(total_measurements))
    
    st.divider()
    
    # 設備ごとにグラフを分割表示
    st.markdown("#### 設備別 測定回数")
    
    for equipment in sorted(stats["equipment"].unique()):
        equip_stats = stats[stats["equipment"] == equipment].copy()
        
        # 測定回数の降順ソート
        equip_stats = equip_stats.sort_values("count", ascending=False)
        
        st.markdown(
            f"""
            <div style='font-size:20px; font-weight:bold; margin-top:10px;'>
                設備: {equipment}
            </div>
            <br>
            """,
            unsafe_allow_html=True,
        )
        
        # グラフの最大値
        x_max = equip_stats["count"].max()
        if pd.isna(x_max) or x_max < 1:
            x_max = 1
        else:
            x_max = int(x_max)
        
        # 軸目盛りを完全整数化
        tick_values = [i for i in range(x_max + 1)] if x_max <= 20 else None
        
        # 降順ソート済みの装置リスト
        order_list = equip_stats["device"].tolist()

        base = alt.Chart(equip_stats).encode(
            y=alt.Y(
                "device:N",
                sort=order_list,
                axis=alt.Axis(title=None, labelFontSize=13, labelLimit=400)
            ),
            x=alt.X(
                "count:Q",
                title="測定回数",
                scale=alt.Scale(domain=[0, x_max], nice=False),
                axis=alt.Axis(
                    tickMinStep=1,
                    tickCount=x_max + 1,
                    values=tick_values,
                    labelFontSize=12,
                    format="d"
                )
            )
        )
        
        bars = base.mark_bar(cornerRadius=6).encode(
            color=alt.Color(
                "is_current:N",
                scale=alt.Scale(
                    domain=[True, False],
                    range=["orange", "steelblue"]
                ),
                legend=None
            ),
            tooltip=[
                alt.Tooltip(field="device", type="nominal", title="装置"),
                alt.Tooltip(field="count", type="quantitative", title="測定回数"),
                alt.Tooltip(field="is_current", type="nominal", title="現在取付中")
            ]
        )
        
        chart_height = max(120, 50 * len(equip_stats["device"].unique()))
        
        chart = bars.properties(
            height=chart_height
        )
        
        st.altair_chart(chart, use_container_width=True)
        
        st.markdown("")  # 空行でマージン
    
    st.caption("🟠 オレンジ = 現在取付中、🔵 青 = 過去の取付")
    
    # データテーブル
    with st.expander("📋 詳細データ"):
        display_stats = stats[["equipment", "device", "count", "is_current"]].copy()
        display_stats = display_stats.sort_values(["equipment", "count"], ascending=[True, False])
        display_stats.columns = ["設備", "装置", "測定回数", "現在取付中"]
        display_stats["現在取付中"] = display_stats["現在取付中"].map({True: "✅", False: ""})
        st.dataframe(display_stats, use_container_width=True)


def render_settings(state: StateManager, service: AnalysisService) -> None:
    """設定タブを描画"""
    
    st.markdown("### 運用設定")
    
    config = service.config
    
    # パス設定
    with st.expander("📁 パス設定", expanded=True):
        st.text_input(
            "データディレクトリ",
            value=config.paths.data_dir,
            disabled=True,
            key="settings_data_dir"
        )
        st.text_input(
            "AppSettingディレクトリ",
            value=config.paths.appsetting_dir,
            disabled=True,
            key="settings_appsetting_dir"
        )
        st.text_input(
            "モデルディレクトリ",
            value=config.paths.model_dir,
            disabled=True,
            key="settings_model_dir"
        )
        st.caption("パス設定を変更するには設定ファイルを編集してください")
    
    # AIパラメータ
    with st.expander("🤖 AIパラメータ"):
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Isolation Forest**")
            st.text(f"n_estimators: {config.ai_params.if_n_estimators}")
            st.text(f"contamination: {config.ai_params.if_contamination}")
        
        with col2:
            st.markdown("**AutoEncoder**")
            st.text(f"epochs: {config.ai_params.ae_epochs}")
            st.text(f"batch_size: {config.ai_params.ae_batch_size}")
    
    # 予測パラメータ
    with st.expander("📈 予測パラメータ"):
        st.text(f"予測日数: {config.forecast_params.forecast_days}")
        st.text(f"信頼区間: {int(config.forecast_params.confidence_level * 100)}%")
        st.text(f"トレンド窓: {config.forecast_params.trend_window}")
    
    st.divider()
    
    # 設定ファイル
    st.markdown("#### 設定ファイル")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("💾 設定を保存", disabled=True, use_container_width=True):
            pass
    
    with col2:
        if st.button("🔄 設定を再読込", disabled=True, use_container_width=True):
            pass
    
    st.warning("⚠️ 設定変更機能は今後実装予定です")
