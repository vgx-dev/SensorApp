"""
センサ管理タブ (Version 3.6)

センサマウント履歴の登録・編集・削除を担当。
"""

import streamlit as st
import pandas as pd
from typing import Dict, Any

from ....application.state_manager import StateManager
from ....application.services import AnalysisService
from ....application.management_service import ManagementService

# 新規入力オプションの定数
NEW_ENTRY = "[+ 新規入力]"


def render_sensor_management(
    state: StateManager,
    service: AnalysisService,
    mgmt_service: ManagementService,
    get_cached_master_data,
    get_cached_stats,
    get_mount_history=None
) -> None:
    """センサ管理タブを描画"""
    
    st.markdown("###センサ管理")

    # 操作結果メッセージ（共通）
    if "mount_msg" in st.session_state:
        msg_type, msg_text = st.session_state.pop("mount_msg")
        if msg_type == "success":
            st.success(msg_text)
        else:
            st.error(msg_text)
    
    # マウント履歴取得（キャッシュ付き）
    if get_mount_history is not None:
        mount_df = get_mount_history(mgmt_service)
    else:
        mount_df = mgmt_service.get_mount_history()
    
    # 登録フォーム
    with st.expander("➕ 新規マウント登録", expanded=not mount_df.empty):
        _render_mount_registration_form(mgmt_service, get_cached_master_data, get_cached_stats)
    
    # マウント一覧
    if mount_df.empty:
        st.info("📭 マウント履歴がありません。上記フォームから登録してください。")
    else:
        _render_mount_history_table(mount_df)
        _render_mount_edit_delete(mgmt_service, mount_df, get_cached_master_data, get_cached_stats)


def _render_mount_history_table(mount_df: pd.DataFrame) -> None:
    """マウント履歴テーブルを表示"""
    
    # ヘッダーとフィルタを横並び
    col_title, col_filter = st.columns([3, 1])
    with col_title:
        st.markdown("#### マウント履歴")
    with col_filter:
        show_current_only = st.checkbox("現在取付中のみ", value=False, key="mount_filter_current")
    
    # 表示用に整形
    display_df = mount_df.copy()
    
    # 降順ソート（最新順）
    display_df["StartTime"] = pd.to_datetime(display_df["StartTime"], errors="coerce")
    display_df = display_df.sort_values("StartTime", ascending=False)
    
    # フィルタ適用
    if show_current_only:
        display_df = display_df[
            (display_df["EndTime"].isna()) | 
            (display_df["EndTime"].astype(str).str.strip() == "")
        ]
        if display_df.empty:
            st.info("📭 現在取付中のセンサはありません。")
    
    if not display_df.empty:
        # 列名を日本語に変換
        rename_map = {
            "SensorID": "センサID",
            "EquipmentID": "設備",
            "DeviceID": "装置",
            "UserName": "使用者",
            "StartTime": "開始日時",
            "EndTime": "終了日時",
            "Remark": "備考"
        }
        display_df = display_df.rename(columns={k: v for k, v in rename_map.items() if k in display_df.columns})
        
        # 現在取付中を強調
        def highlight_current(row):
            if pd.isna(row.get("終了日時")) or str(row.get("終了日時", "")).strip() == "":
                return ["background-color: #e6ffe6"] * len(row)
            return [""] * len(row)
        
        st.dataframe(
            display_df.style.apply(highlight_current, axis=1),
            use_container_width=True
        )
        
        st.caption("🟢 緑色の行 = 現在取付中")


def _render_mount_edit_delete(
    mgmt_service: ManagementService,
    mount_df: pd.DataFrame,
    get_cached_master_data,
    get_cached_stats
) -> None:
    """編集・削除機能を描画"""
    
    col_del, col_edit = st.columns(2)
    
    with col_del:
        with st.expander("🗑️ 削除"):
            if len(mount_df) > 0:
                delete_idx = st.number_input(
                    "削除する行番号（0から）",
                    min_value=0,
                    max_value=len(mount_df) - 1,
                    value=0,
                    key="delete_mount_idx"
                )
                st.button(
                    "削除実行",
                    type="primary",
                    key="delete_mount_btn",
                    on_click=_handle_mount_delete,
                    args=(mgmt_service, get_cached_master_data, get_cached_stats)
                )
    
    with col_edit:
        with st.expander("✏️ 修正"):
            if len(mount_df) > 0:
                _render_mount_edit_form(mgmt_service, mount_df, get_cached_master_data, get_cached_stats)


def _render_mount_edit_form(
    mgmt_service: ManagementService,
    mount_df: pd.DataFrame,
    get_cached_master_data,
    get_cached_stats
) -> None:
    """マウント編集フォームを描画"""
    
    # 対象行の選択
    edit_idx = st.number_input(
        "修正する行番号（0から）",
        min_value=0,
        max_value=len(mount_df) - 1,
        value=0,
        key="edit_mount_idx"
    )
    
    # 現在の値を取得
    current_row = mount_df.iloc[edit_idx]
    
    # 修正フォーム
    st.markdown("**修正内容:**")
    
    # センサID
    sensor_options = mgmt_service.get_sensor_options()
    current_sensor = str(current_row.get("SensorID", ""))
    sensor_idx = sensor_options.index(current_sensor) if current_sensor in sensor_options else 0
    new_sensor_id = st.selectbox(
        "センサID",
        options=sensor_options if sensor_options else [current_sensor],
        index=sensor_idx if sensor_options else 0,
        key="edit_sensor_id"
    )
    
    # 設備
    equipment_options = mgmt_service.get_equipment_options()
    current_equip = str(current_row.get("EquipmentID", ""))
    equip_idx = equipment_options.index(current_equip) if current_equip in equipment_options else 0
    new_equipment_id = st.selectbox(
        "設備",
        options=equipment_options if equipment_options else [current_equip],
        index=equip_idx if equipment_options else 0,
        key="edit_equipment_id"
    )
    
    # 装置（カスケード選択）
    pairs = mgmt_service.get_equipment_device_pairs()
    filtered_devices = [p["device"] for p in pairs if p["equipment"] == new_equipment_id]
    device_options = sorted(set(filtered_devices)) if filtered_devices else []
    current_device = str(current_row.get("DeviceID", ""))
    device_idx = device_options.index(current_device) if current_device in device_options else 0
    new_device_id = st.selectbox(
        "装置",
        options=device_options if device_options else [current_device],
        index=device_idx if device_options else 0,
        key="edit_device_id"
    )
    
    # 使用者
    current_user = str(current_row.get("UserName", "")) if pd.notna(current_row.get("UserName")) else ""
    new_user_name = st.text_input("使用者", value=current_user, key="edit_user_name")
    
    # 保存ボタン
    st.button(
        "修正を保存",
        type="primary",
        key="save_edit_btn",
        on_click=_handle_mount_edit,
        args=(mgmt_service, get_cached_master_data, get_cached_stats)
    )


def _render_mount_registration_form(
    mgmt_service: ManagementService,
    get_cached_master_data,
    get_cached_stats
) -> None:
    """マウント登録フォーム"""
    
    st.markdown("#### マウント登録")
    
    # キャッシュからマスタデータ取得
    # NOTE: キャッシュ関数は__init__.pyから渡される
    from . import _get_file_mtime
    file_mtime = _get_file_mtime(mgmt_service)
    master_data = get_cached_master_data(mgmt_service, file_mtime)
    
    sensor_options = master_data["sensor_options"]
    user_options = master_data["user_options"]
    equipment_options = master_data["equipment_options"]
    pairs = master_data["device_pairs"]
    
    # 前回の入力を取得
    last_input = st.session_state.get("last_mount_input", {"equipment": "", "device": ""})
    
    # センサIDと使用者
    col1, col2 = st.columns(2)
    
    with col1:
        sensor_choices = [NEW_ENTRY] + sensor_options if sensor_options else []
        if sensor_choices:
            sensor_selection = st.selectbox("センサID", sensor_choices, key="mount_sensor_select")
            if sensor_selection == NEW_ENTRY:
                sensor_id = st.text_input("センサID（新規）", placeholder="例: SENS-001", key="mount_sensor_new")
            else:
                sensor_id = sensor_selection
        else:
            sensor_id = st.text_input("センサID", placeholder="例: SENS-001", key="mount_sensor_text")
    
    with col2:
        # 使用者の自動転記
        user_suggestion = ""
        is_existing_sensor = sensor_id and sensor_id != NEW_ENTRY and sensor_id in sensor_options
        
        if is_existing_sensor:
            user_suggestion = mgmt_service.get_user_suggestion(sensor_id)
        
        user_choices = [NEW_ENTRY] + user_options if user_options else []
        
        if user_choices:
            default_idx = 0
            if user_suggestion and user_suggestion in user_options:
                default_idx = user_options.index(user_suggestion) + 1
            
            user_selection = st.selectbox("使用者", user_choices, index=default_idx, key="mount_user_select")
            if user_selection == NEW_ENTRY:
                user_name = st.text_input("使用者（新規）", placeholder="例: 山田太郎", key="mount_user_new")
            else:
                user_name = user_selection
        else:
            user_name = st.text_input("使用者", placeholder="例: 山田太郎", value=user_suggestion, key="mount_user_text")
        
        if is_existing_sensor and user_suggestion:
            st.caption(f"📋 前回の使用者「{user_suggestion}」を自動転記")
    
    # 設備→装置
    st.markdown("##### 設備 → 装置")
    
    col3, col4 = st.columns(2)
    
    with col3:
        equip_choices = [NEW_ENTRY] + equipment_options if equipment_options else []
        
        # 前回の設備をデフォルト選択
        equip_default_idx = 0
        if last_input.get("equipment") and last_input["equipment"] in equipment_options:
            equip_default_idx = equipment_options.index(last_input["equipment"]) + 1
        
        if equip_choices:
            equip_selection = st.selectbox("設備", equip_choices, index=equip_default_idx, key="mount_equip_select")
            if equip_selection == NEW_ENTRY:
                equipment_id = st.text_input("設備ID（新規）", placeholder="例: OPF-1", key="mount_equip_new")
            else:
                equipment_id = equip_selection
        else:
            equipment_id = st.text_input("設備ID", placeholder="例: OPF-1", key="mount_equip_text")
        
        if last_input.get("equipment") and equip_default_idx > 0:
            st.caption("📋 前回の設備を選択中")
    
    with col4:
        # カスケード
        if equipment_id and equipment_id != NEW_ENTRY:
            filtered_devices = [p["device"] for p in pairs if p["equipment"] == equipment_id]
            device_choices = [NEW_ENTRY] + sorted(set(filtered_devices)) if filtered_devices else [NEW_ENTRY]
        else:
            device_choices = [NEW_ENTRY]
        
        # 前回の装置をデフォルト選択
        device_default_idx = 0
        if last_input.get("device") and last_input.get("equipment") == equipment_id:
            if last_input["device"] in [d for d in device_choices if d != NEW_ENTRY]:
                device_default_idx = device_choices.index(last_input["device"])
        
        device_selection = st.selectbox("装置", device_choices, index=device_default_idx, key="mount_device_select")
        if device_selection == NEW_ENTRY:
            device_id = st.text_input("装置ID（新規）", placeholder="例: CTポンプ", key="mount_device_new")
        else:
            device_id = device_selection
    
    # 登録ボタン
    st.button(
        "登録",
        type="primary",
        use_container_width=True,
        key="mount_submit",
        on_click=_handle_mount_registration,
        args=(mgmt_service, get_cached_master_data, get_cached_stats)
    )


def _handle_mount_delete(
    mgmt_service: ManagementService,
    get_cached_master_data,
    get_cached_stats
) -> None:
    """削除処理のコールバック"""
    idx = st.session_state.get("delete_mount_idx")
    if idx is not None:
        if mgmt_service.delete_mount(idx):
            get_cached_master_data.clear()
            get_cached_stats.clear()
            st.session_state.mount_msg = ("success", f"行 {idx} を削除しました")
        else:
            st.session_state.mount_msg = ("error", "削除に失敗しました")


def _handle_mount_edit(
    mgmt_service: ManagementService,
    get_cached_master_data,
    get_cached_stats
) -> None:
    """修正処理のコールバック（Phase 2でレイヤー違反を修正）"""
    idx = st.session_state.get("edit_mount_idx")
    if idx is None:
        return

    # 入力値取得
    new_sensor_id = st.session_state.get("edit_sensor_id")
    new_equipment_id = st.session_state.get("edit_equipment_id")
    new_device_id = st.session_state.get("edit_device_id")
    new_user_name = st.session_state.get("edit_user_name")
    
    # ManagementService.update_mount()を使用（レイヤー境界を遵守）
    if mgmt_service.update_mount(
        idx,
        sensor_id=new_sensor_id,
        equipment_id=new_equipment_id,
        device_id=new_device_id,
        user_name=new_user_name
    ):
        get_cached_master_data.clear()
        get_cached_stats.clear()
        st.session_state.mount_msg = ("success", f"行 {idx} を修正しました")
    else:
        st.session_state.mount_msg = ("error", "修正に失敗しました")


def _handle_mount_registration(
    mgmt_service: ManagementService,
    get_cached_master_data,
    get_cached_stats
) -> None:
    """マウント登録のコールバック"""
    
    NEW_ENTRY_STR = "[+ 新規入力]"
    
    # 入力値取得ヘルパー
    def _get_val(key_select, key_new, key_text):
        if key_select in st.session_state:
            val = st.session_state[key_select]
            if val == NEW_ENTRY_STR:
                return st.session_state.get(key_new, "").strip()
            return val
        return st.session_state.get(key_text, "").strip()

    sensor_id = _get_val("mount_sensor_select", "mount_sensor_new", "mount_sensor_text")
    equipment_id = _get_val("mount_equip_select", "mount_equip_new", "mount_equip_text")
    device_id = _get_val("mount_device_select", "mount_device_new", "mount_device_text")
    
    user_selection = st.session_state.get("mount_user_select")
    user_new = st.session_state.get("mount_user_new")
    if user_selection:
        user_name = user_new if user_selection == NEW_ENTRY_STR else user_selection
    else:
        user_name = st.session_state.get("mount_user_text", "")
    
    # バリデーション
    if not sensor_id:
        st.session_state.mount_msg = ("error", "センサIDを入力してください")
        return
    if not equipment_id:
        st.session_state.mount_msg = ("error", "設備IDを入力してください")
        return
    if not device_id:
        st.session_state.mount_msg = ("error", "装置IDを入力してください")
        return
        
    # 登録実行
    if mgmt_service.register_mount_with_user(sensor_id, equipment_id, device_id, user_name):
        # 前回入力を保存
        if "last_mount_input" not in st.session_state:
            st.session_state.last_mount_input = {}
        st.session_state.last_mount_input["equipment"] = equipment_id
        st.session_state.last_mount_input["device"] = device_id
        
        # キャッシュクリア
        mgmt_service.clear_cache()
        get_cached_master_data.clear()
        get_cached_stats.clear()
        
        st.session_state.mount_msg = ("success", f"✅ {sensor_id} を {equipment_id}/{device_id} に登録しました")
    else:
        st.session_state.mount_msg = ("error", "登録に失敗しました")
