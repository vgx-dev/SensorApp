"""
研究検証モード画面 (Version 3.0)

仮想データによるアルゴリズム評価・論文用データ生成を行う画面。
シード固定による完全再現可能な実験を提供する。
"""

import streamlit as st
import pandas as pd
import numpy as np
import json
import zipfile
import io
from datetime import datetime
from typing import Dict, Any

from ...application.state_manager import StateManager
from ...application.services import AnalysisService
from ...application.context import AppMode
from ..components.charts import (
    create_rms_chart,
    create_forecast_chart,
    create_score_components_chart
)


def render(state: StateManager, service: AnalysisService) -> None:
    """
    研究検証モード画面を描画
    
    Args:
        state: 状態マネージャー
        service: 分析サービス
    """
    # モードバナー
    st.info("🧪 **研究検証モード**（仮想データ使用・シード固定による再現性保証）")
    
    # タブ構成
    tabs = st.tabs(["検証実行・評価", "設定"])
    
    with tabs[0]:
        _render_verification_tab(state, service)
    
    with tabs[1]:
        _render_settings_tab(state)


def _render_verification_tab(state: StateManager, service: AnalysisService) -> None:
    """検証実行・評価タブを描画"""
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        _render_parameter_form(state)
    
    with col2:
        st.markdown("### 実行・結果")
        _render_execution_panel(state, service)


def _render_parameter_form(state: StateManager) -> None:
    """パラメータ入力フォームを描画"""
    
    ctx = state.research
    current_params = ctx.params.copy()
    
    # シナリオタイプ
    scenario_types = ["spike", "shift", "trend", "none"]
    current_type = current_params.get("type", "spike")
    selected_type = st.selectbox(
        "異常タイプ",
        options=scenario_types,
        index=scenario_types.index(current_type) if current_type in scenario_types else 0,
        key="research_scenario_type"
    )
    
    # 共通パラメータ
    amplitude = st.slider(
        "振幅（標準偏差の倍数）",
        min_value=0.5,
        max_value=5.0,
        value=float(current_params.get("amplitude", 2.0)),
        step=0.1,
        key="research_amplitude"
    )
    
    duration = st.slider(
        "継続期間（ポイント数）",
        min_value=5,
        max_value=100,
        value=int(current_params.get("duration", 10)),
        key="research_duration"
    )
    
    injection_point = st.slider(
        "注入位置（データ長の割合）",
        min_value=0.3,
        max_value=0.9,
        value=float(current_params.get("injection_point", 0.7)),
        step=0.05,
        key="research_injection_point"
    )
    
    # タイプ別パラメータ
    if selected_type == "spike":
        spike_count = st.slider(
            "スパイク回数",
            min_value=1,
            max_value=10,
            value=int(current_params.get("spike_count", 5)),
            key="research_spike_count"
        )
        current_params["spike_count"] = spike_count
    
    elif selected_type == "trend":
        trend_slope = st.slider(
            "トレンド傾き",
            min_value=0.001,
            max_value=0.1,
            value=float(current_params.get("trend_slope", 0.01)),
            step=0.001,
            format="%.3f",
            key="research_trend_slope"
        )
        current_params["trend_slope"] = trend_slope
    
    # データ点数
    n_points = st.number_input(
        "データ点数",
        min_value=100,
        max_value=2000,
        value=int(current_params.get("n_points", 500)),
        step=100,
        key="research_n_points"
    )
    
    # 乱数シード
    seed = st.number_input(
        "乱数シード",
        min_value=0,
        max_value=99999,
        value=ctx.random_seed,
        key="research_seed"
    )
    
    # パラメータ更新
    new_params = {
        "type": selected_type,
        "amplitude": amplitude,
        "duration": duration,
        "injection_point": injection_point,
        "n_points": n_points,
        **{k: v for k, v in current_params.items() if k not in ["type", "amplitude", "duration", "injection_point", "n_points"]}
    }
    
    if new_params != ctx.params or seed != ctx.random_seed:
        state.update_research(params=new_params, random_seed=seed)


def _render_execution_panel(state: StateManager, service: AnalysisService) -> None:
    """実行パネルを描画"""
    
    # 実行結果メッセージ表示（コールバック処理の結果）
    if "research_msg" in st.session_state:
        msg_type, msg_text = st.session_state.pop("research_msg")
        if msg_type == "success":
            st.toast(msg_text, icon="✅")
        else:
            st.error(msg_text)
    
    # 実行ボタン（Reactive UI）
    st.button(
        "🚀 検証実行",
        type="primary",
        use_container_width=True,
        on_click=_handle_execute_analysis,
        args=(state, service)
    )
    
    # キャッシュされた結果の表示
    cache_key = state.research.get_cache_key()
    cached_result = state.get_cached_result(cache_key)
    
    if cached_result is not None:
        _render_results(cached_result, state)
    else:
        st.markdown("---")
        st.markdown("*パラメータを設定して「検証実行」をクリックしてください*")


def _handle_execute_analysis(state: StateManager, service: AnalysisService) -> None:
    """分析実行のコールバック（Atomic State Update）"""
    
    ctx = state.research
    
    try:
        result = service.run_research_scenario(
            params=ctx.params,
            seed=ctx.random_seed
        )
        
        # キャッシュに保存
        cache_key = ctx.get_cache_key()
        state.cache_result(cache_key, result)
        
        st.session_state.research_msg = ("success", "✅ 検証完了しました")
        # ✅ st.rerun() 削除 - 自動再描画に委ねる
        
    except Exception as e:
        st.session_state.research_msg = ("error", f"❌ エラーが発生しました: {str(e)}")


def _render_results(result: Dict[str, Any], state: StateManager) -> None:
    """結果を描画"""
    
    st.markdown("---")
    
    sensor_data = result.get("sensor_data")
    analysis_result = result.get("analysis_result")
    forecast = result.get("forecast")
    metadata = result.get("metadata", {})
    
    # メトリクス
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("データ点数", metadata.get("data_points", "N/A"))
    
    with col2:
        if analysis_result:
            score = analysis_result.mean_score
            delta_color = "inverse" if score > 0.7 else "normal"
            st.metric("平均スコア", f"{score:.3f}", delta_color=delta_color)
    
    with col3:
        if analysis_result:
            st.metric("最大スコア", f"{analysis_result.max_score:.3f}")
    
    with col4:
        if analysis_result:
            anomaly_count = len(analysis_result.get_anomaly_indices())
            st.metric("異常検出数", anomaly_count)
    
    # グラフ
    st.markdown("### 📊 結果グラフ")
    
    # RMS + 異常スコア
    if sensor_data and not sensor_data.is_empty:
        chart = create_rms_chart(sensor_data, analysis_result, width="container")
        st.altair_chart(chart, use_container_width=True)
    
    # 予測グラフ
    if forecast and forecast.length > 0:
        with st.expander("未来予測", expanded=True):
            history_df = sensor_data.dataframe if sensor_data else None
            chart = create_forecast_chart(
                forecast,
                history=history_df,
                history_time_col=sensor_data.time_column if sensor_data else "timestamp",
                history_value_col=sensor_data.value_columns[0] if sensor_data and sensor_data.value_columns else "RMS",
                width="container"
            )
            st.altair_chart(chart, use_container_width=True)
            
            # Phase 3: 異常検知による不確実性警告を表示
            if forecast.reason_message:
                st.warning(forecast.reason_message)
    
    # スコア成分
    if analysis_result and analysis_result.components:
        with st.expander("スコア成分内訳"):
            chart = create_score_components_chart(analysis_result, width="container")
            st.altair_chart(chart, use_container_width=True)
    
    # Ground Truth（仮想データにはラベルあり）
    if sensor_data and "label" in sensor_data.dataframe.columns:
        with st.expander("Ground Truth 比較"):
            labels = sensor_data.dataframe["label"].values
            threshold = analysis_result.threshold  # 動的閾値を使用
            true_positives = np.sum((labels == 1) & (analysis_result.integrated_scores > threshold))
            false_positives = np.sum((labels == 0) & (analysis_result.integrated_scores > threshold))
            true_negatives = np.sum((labels == 0) & (analysis_result.integrated_scores <= threshold))
            false_negatives = np.sum((labels == 1) & (analysis_result.integrated_scores <= threshold))
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**混同行列**")
                st.dataframe(pd.DataFrame({
                    "予測正常": [true_negatives, false_negatives],
                    "予測異常": [false_positives, true_positives]
                }, index=["実際:正常", "実際:異常"]))
            
            with col2:
                total = len(labels)
                if total > 0:
                    accuracy = (true_positives + true_negatives) / total
                    st.metric("Accuracy", f"{accuracy:.3f}")
                    
                    if (true_positives + false_positives) > 0:
                        precision = true_positives / (true_positives + false_positives)
                        st.metric("Precision", f"{precision:.3f}")
    
    # ダウンロードボタン
    st.markdown("---")
    _render_download_section(result, state)


def _render_download_section(result: Dict[str, Any], state: StateManager) -> None:
    """ダウンロードセクションを描画"""
    
    st.markdown("### 📥 レポートダウンロード")
    
    # ZIPを生成してダウンロードボタンを表示（1クリックで完了）
    zip_buffer = _create_report_zip(result, state)
    
    st.download_button(
        label="📦 実験レポート（ZIP）をダウンロード",
        data=zip_buffer,
        file_name=f"research_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip",
        mime="application/zip",
        use_container_width=True
    )


def _create_report_zip(result: Dict[str, Any], state: StateManager) -> bytes:
    """レポートZIPを作成"""
    
    buffer = io.BytesIO()
    
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        # パラメータJSON
        params_data = {
            "params": state.research.params,
            "seed": state.research.random_seed,
            "metadata": result.get("metadata", {})
        }
        zf.writestr("params.json", json.dumps(params_data, ensure_ascii=False, indent=2))
        
        # データCSV
        sensor_data = result.get("sensor_data")
        if sensor_data and not sensor_data.is_empty:
            csv_buffer = io.StringIO()
            sensor_data.dataframe.to_csv(csv_buffer, index=False)
            zf.writestr("data.csv", csv_buffer.getvalue())
        
        # スコアCSV
        analysis_result = result.get("analysis_result")
        if analysis_result:
            score_df = analysis_result.to_dataframe()
            csv_buffer = io.StringIO()
            score_df.to_csv(csv_buffer, index=False)
            zf.writestr("scores.csv", csv_buffer.getvalue())
        
        # 予測CSV
        forecast = result.get("forecast")
        if forecast and forecast.length > 0:
            forecast_df = forecast.to_dataframe()
            csv_buffer = io.StringIO()
            forecast_df.to_csv(csv_buffer, index=False)
            zf.writestr("forecast.csv", csv_buffer.getvalue())
    
    buffer.seek(0)
    return buffer.getvalue()


def _render_settings_tab(state: StateManager) -> None:
    """設定タブを描画"""
    
    st.markdown("### 研究モード設定")
    
    st.markdown("""
    研究検証モードでは、以下の機能が利用可能です：
    
    - **シード固定**: 同一パラメータで完全に同じ結果を再現
    - **異常注入**: スパイク・シフト・トレンドパターンの注入
    - **Ground Truth**: 正解ラベル付きデータによる精度評価
    - **レポート出力**: 実験設定・データ・結果のZIP出力
    """)
    
    with st.expander("パラメータを運用設定に反映"):
        st.warning("⚠️ この機能は運用設定を変更します")
        
        if st.button("現在のパラメータを運用に適用", disabled=True):
            st.info("この機能は今後実装予定です")
