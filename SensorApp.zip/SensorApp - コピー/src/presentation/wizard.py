"""
初期設定ウィザード (Version 3.0)

config.json が無効な場合に表示するセットアップ画面。
データフォルダのパス入力と保存を行う。
"""

import streamlit as st
from pathlib import Path
from typing import Optional, Callable

from ..config.settings import AppConfig, PathConfig, get_default_config_path


def render(
    config: AppConfig,
    config_path: Path,
    *,
    on_complete: Optional[Callable[[], None]] = None
) -> bool:
    """
    初期設定ウィザードを描画
    
    Args:
        config: 現在の設定（無効状態）
        config_path: 設定ファイルのパス
        on_complete: 完了時のコールバック
        
    Returns:
        設定が完了したらTrue
    """
    # ウィザードUI
    st.markdown("# 🚀 SensorApp 初期設定")
    st.markdown("---")
    
    st.info("""
    **SensorApp v3.0** へようこそ！
    
    初回起動または設定ファイルが見つからないため、初期設定を行います。
    以下の手順に従って設定を完了してください。
    """)
    
    # ステップ表示
    st.markdown("### 📋 セットアップ手順")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("**Step 1**")
        st.markdown("データフォルダ指定")
    with col2:
        st.markdown("**Step 2**")
        st.markdown("設定確認")
    with col3:
        st.markdown("**Step 3**")
        st.markdown("完了")
    
    st.divider()
    
    # Step 1: パス設定
    st.markdown("### Step 1: データフォルダの指定")
    
    st.markdown("""
    センサデータ（CSV）が保存されているフォルダを指定してください。
    このフォルダ内のCSVファイルが自動的に読み込まれます。
    """)
    
    # 現在の設定を表示
    current_data_dir = config.paths.data_dir or ""
    
    data_dir = st.text_input(
        "データフォルダのパス",
        value=current_data_dir,
        placeholder="C:\\SensorData または /home/user/sensor_data",
        key="wizard_data_dir"
    )
    
    # パス検証
    data_path_valid = False
    if data_dir:
        data_path = Path(data_dir)
        if data_path.exists() and data_path.is_dir():
            csv_count = len(list(data_path.glob("*.csv")))
            st.success(f"✅ 有効なフォルダです（CSV: {csv_count}件）")
            data_path_valid = True
        elif data_path.exists():
            st.warning("⚠️ 指定されたパスはフォルダではありません")
        else:
            st.error("❌ 指定されたフォルダが見つかりません")
    
    st.divider()
    
    # モデルフォルダ（オプション）
    with st.expander("📁 詳細設定（オプション）"):
        model_dir = st.text_input(
            "モデル保存フォルダ（空欄でデフォルト）",
            value=config.paths.model_dir or "",
            placeholder="./models",
            key="wizard_model_dir"
        )
        
        output_dir = st.text_input(
            "出力フォルダ（空欄でデフォルト）",
            value=config.paths.output_dir or "",
            placeholder="./output",
            key="wizard_output_dir"
        )
    
    st.divider()
    
    # Step 2: 確認と保存
    st.markdown("### Step 2: 設定の確認と保存")
    
    if data_path_valid:
        # 設定プレビュー
        st.markdown("**保存される設定:**")
        
        preview_config = {
            "データフォルダ": data_dir,
            "モデルフォルダ": model_dir or "(デフォルト: ./models)",
            "出力フォルダ": output_dir or "(デフォルト: ./output)",
            "設定ファイル": str(config_path)
        }
        
        for key, value in preview_config.items():
            st.text(f"  {key}: {value}")
        
        st.divider()
        
        # 保存ボタン
        col1, col2 = st.columns([1, 1])
        
        with col1:
            if st.button("💾 設定を保存してアプリを開始", type="primary", use_container_width=True):
                try:
                    # 設定を更新
                    new_paths = PathConfig(
                        data_dir=data_dir,
                        model_dir=model_dir or "./models",
                        output_dir=output_dir or "./output"
                    )
                    config.paths = new_paths
                    
                    # 保存
                    config.save(config_path)
                    
                    st.success("✅ 設定を保存しました！")
                    st.balloons()
                    
                    if on_complete:
                        on_complete()
                    
                    st.rerun()
                    return True
                    
                except Exception as e:
                    st.error(f"❌ 設定の保存に失敗しました: {str(e)}")
        
        with col2:
            if st.button("🔄 リセット", use_container_width=True):
                st.rerun()
    
    else:
        st.warning("⚠️ 有効なデータフォルダを指定してください")
        st.button("💾 設定を保存", disabled=True, use_container_width=True)
    
    st.divider()
    
    # ヘルプ
    with st.expander("❓ ヘルプ"):
        st.markdown("""
        **データフォルダについて**
        
        センサデータのCSVファイルが保存されているフォルダを指定してください。
        CSVファイルの形式は以下を想定しています：
        
        - 時刻列（timestamp, datetime, 日時 等）
        - RMS値列（RMS, AccRMS, acc_rms 等）
        
        **エンコーディング**
        
        UTF-8 および Shift-JIS (cp932) に対応しています。
        
        **サポート**
        
        問題が解決しない場合は、管理者にお問い合わせください。
        """)
    
    return False


def should_show_wizard(config: AppConfig) -> bool:
    """
    ウィザードを表示すべきかどうか判定
    
    Args:
        config: アプリケーション設定
        
    Returns:
        ウィザードを表示すべきならTrue
    """
    return not config.is_valid
