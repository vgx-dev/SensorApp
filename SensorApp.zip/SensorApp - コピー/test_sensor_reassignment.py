"""
センサー付け替え機能のテストスクリプト

測定中センサーと遊休センサーの両方が正しくフィルタリングされることを確認。
"""

import sys
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd

# プロジェクトルートとsrcをパスに追加
project_root = Path(__file__).parent
src_path = project_root / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))

from infrastructure.repositories.real_data import RealDataProvider
from config.settings import PathConfig


def create_test_data():
    """テストデータ（CSV）を作成"""
    
    # AppSettingディレクトリ作成
    appsetting_dir = project_root / "AppSetting_test"
    appsetting_dir.mkdir(exist_ok=True)
    
    # マウント履歴作成
    # SENSOR-001: 現在測定中（EndTime未記録）
    # SENSOR-002: 遊休センサー（EndTime記録済）
    # SENSOR-003: 設備付け替え（2回マウント）
    mount_data = {
        "SensorID": ["SENSOR-001", "SENSOR-002", "SENSOR-003", "SENSOR-003"],
        "EquipmentID": ["EQUIP-A", "EQUIP-B", "EQUIP-A", "EQUIP-B"],
        "DeviceID": ["DEVICE-1", "DEVICE-2", "DEVICE-1", "DEVICE-2"],
        "UserName": ["User1", "User2", "User3", "User3"],
        "StartTime": [
            (datetime.now() - timedelta(days=30)).isoformat(),
            (datetime.now() - timedelta(days=60)).isoformat(),
            (datetime.now() - timedelta(days=90)).isoformat(),
            (datetime.now() - timedelta(days=10)).isoformat(),
        ],
        "EndTime": [
            "",  # 現在測定中
            (datetime.now() - timedelta(days=10)).isoformat(),  # 遊休
            (datetime.now() - timedelta(days=11)).isoformat(),  # 付け替え前
            "",  # 付け替え後（現在測定中）
        ],
        "Remark": ["", "", "付け替え前", "付け替え後"]
    }
    
    mount_df = pd.DataFrame(mount_data)
    mount_df.to_csv(appsetting_dir / "sensor_mount_list.csv", index=False, encoding="utf-8-sig")
    
    # センサーデータCSV作成
    data_dir = project_root / "Log_test"
    data_dir.mkdir(exist_ok=True)
    
    # 90日分のデータを生成
    dates = pd.date_range(end=datetime.now(), periods=90, freq='D')
    
    data_rows = []
    for i, date in enumerate(dates):
        # SENSOR-001のデータ（30日前から）
        if i >= 60:
            data_rows.append([
                "SENSOR-001",  # Index 0
                *[""] * 27,    # Index 1-27
                0.5 + i * 0.01,  # Index 28: RMS
                "",  # Index 29
                0.3,  # Index 30: Value2
                "",  # Index 31
                0.2,  # Index 32: Value3
                *[""] * 5,  # Index 33-37
                date.isoformat()  # Index 38: Time
            ])
        
        # SENSOR-002のデータ（60日前から50日前まで）
        if 30 <= i < 80:
            data_rows.append([
                "SENSOR-002",
                *[""] * 27,
                0.6 + i * 0.01,
                "",
                0.4,
                "",
                0.3,
                *[""] * 5,
                date.isoformat()
            ])
        
        # SENSOR-003のデータ（全期間）
        data_rows.append([
            "SENSOR-003",
            *[""] * 27,
            0.7 + i * 0.01,
            "",
            0.5,
            "",
            0.4,
            *[""] * 5,
            date.isoformat()
        ])
    
    # CSV出力
    csv_path = data_dir / f"SensorNode_{datetime.now().strftime('%Y%m%d')}.csv"
    pd.DataFrame(data_rows).to_csv(csv_path, index=False, header=False, encoding="cp932")
    
    print(f"✅ テストデータ作成完了")
    print(f"  - マウント履歴: {appsetting_dir / 'sensor_mount_list.csv'}")
    print(f"  - センサーデータ: {csv_path}")
    
    return appsetting_dir, data_dir


def test_sensor_filtering():
    """センサーフィルタリングのテスト"""
    
    print("\n" + "="*60)
    print("センサー付け替え機能テスト")
    print("="*60)
    
    # テストデータ作成
    appsetting_dir, data_dir = create_test_data()
    
    # PathConfig設定
    config = PathConfig(
        data_dir=str(data_dir),
        appsetting_dir=str(appsetting_dir),
        model_dir=str(project_root / "models_test"),
        output_dir=str(project_root / "output_test")
    )
    
    provider = RealDataProvider(config)
    
    # マウント情報取得
    mounts = provider.get_mount_info()
    print(f"\n📋 マウント履歴: {len(mounts)}件")
    
    # Test 1: 測定中センサー（SENSOR-001、EndTime未記録）
    print("\n" + "-"*60)
    print("Test 1: 測定中センサー（EndTime未記録）")
    print("-"*60)
    
    mount_001 = next((m for m in mounts if m.sensor_id == "SENSOR-001"), None)
    if mount_001:
        print(f"  センサーID: {mount_001.sensor_id}")
        print(f"  設備: {mount_001.equipment}")
        print(f"  マウント開始: {mount_001.mount_date}")
        print(f"  マウント終了: {mount_001.unmount_date} (None=測定中)")
        
        # データ取得（フィルタリング適用）
        data = provider.get_sensor_data(
            "SENSOR-001",
            mount_start_time=mount_001.mount_date,
            mount_end_time=mount_001.unmount_date
        )
        
        print(f"  ✅ フィルタ後データ件数: {data.length}件")
        if data.length > 0:
            print(f"  ✅ 最古データ: {data.dataframe['Time'].min()}")
            print(f"  ✅ 最新データ: {data.dataframe['Time'].max()}")
            assert data.dataframe['Time'].min() >= mount_001.mount_date, "マウント開始前のデータが含まれています"
            print("  ✅ Test 1 PASSED")
        else:
            print("  ❌ データが取得できませんでした")
    
    # Test 2: 遊休センサー（SENSOR-002、EndTime記録済）
    print("\n" + "-"*60)
    print("Test 2: 遊休センサー（EndTime記録済）")
    print("-"*60)
    
    mount_002 = next((m for m in mounts if m.sensor_id == "SENSOR-002"), None)
    if mount_002:
        print(f"  センサーID: {mount_002.sensor_id}")
        print(f"  設備: {mount_002.equipment}")
        print(f"  マウント開始: {mount_002.mount_date}")
        print(f"  マウント終了: {mount_002.unmount_date}")
        
        # データ取得（フィルタリング適用）
        data = provider.get_sensor_data(
            "SENSOR-002",
            mount_start_time=mount_002.mount_date,
            mount_end_time=mount_002.unmount_date
        )
        
        print(f"  ✅ フィルタ後データ件数: {data.length}件")
        if data.length > 0:
            print(f"  ✅ 最古データ: {data.dataframe['Time'].min()}")
            print(f"  ✅ 最新データ: {data.dataframe['Time'].max()}")
            assert data.dataframe['Time'].min() >= mount_002.mount_date, "マウント開始前のデータが含まれています"
            assert data.dataframe['Time'].max() <= mount_002.unmount_date, "マウント終了後のデータが含まれています"
            print("  ✅ Test 2 PASSED")
        else:
            print("  ❌ データが取得できませんでした")
    
    # Test 3: 設備付け替えセンサー（SENSOR-003、現在のマウントのみ）
    print("\n" + "-"*60)
    print("Test 3: 設備付け替えセンサー（現在のマウントのみ表示）")
    print("-"*60)
    
    # SENSOR-003の現在のマウントを取得（最新）
    mount_003_all = [m for m in mounts if m.sensor_id == "SENSOR-003"]
    print(f"  SENSOR-003のマウント履歴: {len(mount_003_all)}件")
    
    # 現在有効なマウント（EndTimeがNone）を探す
    mount_003_current = next((m for m in mount_003_all if m.unmount_date is None), None)
    
    if mount_003_current:
        print(f"  現在の設備: {mount_003_current.equipment}")
        print(f"  マウント開始: {mount_003_current.mount_date}")
        print(f"  マウント終了: {mount_003_current.unmount_date} (None=測定中)")
        
        # データ取得（現在のマウント期間のみ）
        data = provider.get_sensor_data(
            "SENSOR-003",
            mount_start_time=mount_003_current.mount_date,
            mount_end_time=mount_003_current.unmount_date
        )
        
        print(f"  ✅ フィルタ後データ件数: {data.length}件（過去の設備データは除外）")
        if data.length > 0:
            print(f"  ✅ 最古データ: {data.dataframe['Time'].min()}")
            print(f"  ✅ 最新データ: {data.dataframe['Time'].max()}")
            assert data.dataframe['Time'].min() >= mount_003_current.mount_date, "マウント開始前のデータが含まれています"
            print("  ✅ Test 3 PASSED")
        else:
            print("  ❌ データが取得できませんでした")
    
    # Test 4: フィルタリングなし（後方互換性）
    print("\n" + "-"*60)
    print("Test 4: フィルタリングなし（後方互換性確認）")
    print("-"*60)
    
    data_no_filter = provider.get_sensor_data("SENSOR-003")
    print(f"  ✅ 全データ件数: {data_no_filter.length}件")
    print(f"  ✅ Test 4 PASSED（既存API互換性OK）")
    
    print("\n" + "="*60)
    print("✅ 全テスト完了")
    print("="*60)
    
    # クリーンアップ
    import shutil
    if appsetting_dir.exists():
        shutil.rmtree(appsetting_dir)
    if data_dir.exists():
        shutil.rmtree(data_dir)
    print("\n🧹 テストデータをクリーンアップしました")


if __name__ == "__main__":
    test_sensor_filtering()
