"""E2E Pipeline Test for SensorApp v3.7"""
import sys
sys.path.insert(0, '.')

print('=== SensorApp v3.7 E2E Pipeline Test ===')
print()

# 1. Import check
print('[1/6] Importing modules...')
from src.application.services import AnalysisService, AnalysisContext
from src.application.context import AppMode
from src.config.settings import AppConfig
from src.infrastructure.repositories.virtual_data import AnomalyScenario
import numpy as np

print('  OK All imports successful')
print()

# 2. Initialize service
print('[2/6] Initializing AnalysisService...')
config = AppConfig()
service = AnalysisService(config)
print('  OK Service initialized')
print()

# 3. Research mode - Virtual data generation
print('[3/6] Testing Research Mode (Virtual Data)...')
scenario_configs = [
    ('none', AnomalyScenario(anomaly_type='none')),
    ('spike', AnomalyScenario(anomaly_type='spike', amplitude=2.0, spike_count=5)),
    ('shift', AnomalyScenario(anomaly_type='shift', amplitude=0.5)),
    ('trend', AnomalyScenario(anomaly_type='trend', trend_slope=0.01)),
]
results = {}

for name, scenario_obj in scenario_configs:
    context = AnalysisContext(
        sensor_id='VIRTUAL-001',
        mode=AppMode.RESEARCH,
        random_seed=42,
        n_points=500,
        scenario=scenario_obj  # AnomalyScenarioオブジェクトを渡す
    )
    result = service.run_analysis(context)
    
    sensor_data = result.get('sensor_data')
    analysis_result = result.get('analysis_result')
    forecast = result.get('forecast')
    
    results[name] = {
        'data_points': len(sensor_data.dataframe) if sensor_data else 0,
        'has_scores': analysis_result is not None and len(analysis_result.integrated_scores) > 0,
        'has_forecast': forecast is not None and forecast.forecast_values is not None
    }
    
    status = 'OK' if results[name]['data_points'] > 0 else 'NG'
    print(f'  {status} Scenario: {name}')
    print(f'      Data points: {results[name]["data_points"]}')
    print(f'      Has scores: {results[name]["has_scores"]}')
    print(f'      Has forecast: {results[name]["has_forecast"]}')

print()

# 4. Verify GMM filter bypass in research mode
print('[4/6] Verifying GMM filter bypass in Research Mode...')
context = AnalysisContext(
    sensor_id='VIRTUAL-001',
    mode=AppMode.RESEARCH,
    random_seed=42,
    n_points=500,
    scenario=AnomalyScenario(anomaly_type='none')
)
result = service.run_analysis(context)
metadata = result.get('metadata', {})
filter_mode = metadata.get('filter_mode', 'unknown')
print(f'  Filter mode: {filter_mode}')
if filter_mode == 'skipped':
    print('  OK GMM filter correctly bypassed in Research Mode')
else:
    print('  WARNING: GMM filter should be skipped in Research Mode')
print()

# 5. Reproducibility check
print('[5/6] Checking reproducibility (same seed = same result)...')
context1 = AnalysisContext(
    sensor_id='VIRTUAL-001',
    mode=AppMode.RESEARCH,
    random_seed=42,
    n_points=100,
    scenario=AnomalyScenario(anomaly_type='none')
)
context2 = AnalysisContext(
    sensor_id='VIRTUAL-001',
    mode=AppMode.RESEARCH,
    random_seed=42,
    n_points=100,
    scenario=AnomalyScenario(anomaly_type='none')
)
result1 = service.run_analysis(context1)
result2 = service.run_analysis(context2)

scores1 = result1.get('analysis_result').integrated_scores[:5] if result1.get('analysis_result') else []
scores2 = result2.get('analysis_result').integrated_scores[:5] if result2.get('analysis_result') else []

if len(scores1) > 0 and len(scores2) > 0:
    if np.allclose(scores1, scores2):
        print('  OK Reproducibility confirmed (seed 42 produces identical results)')
    else:
        print('  WARNING: Results differ for same seed!')
        print(f'    Run 1: {scores1[:3]}...')
        print(f'    Run 2: {scores2[:3]}...')
else:
    print('  ? Could not verify (no scores)')
print()

# 6. Summary
print('[6/6] Summary')
print('='*50)
all_pass = all(
    r['data_points'] > 0 and r['has_scores'] and r['has_forecast']
    for r in results.values()
)
if all_pass and filter_mode == 'skipped':
    print('  ALL TESTS PASSED')
    print('  Pipeline: INPUT -> VirtualData -> Analysis -> Forecast -> OUTPUT')
else:
    print('  SOME TESTS FAILED')
print('='*50)
