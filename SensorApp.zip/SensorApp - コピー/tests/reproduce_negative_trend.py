import pandas as pd
import numpy as np
import sys
import os

# パス設定
sys.path.append(r"c:\Users\aoyam\Downloads\projects\SensorApp")

from src.domain.ai.forecaster import Forecaster
from src.config.settings import ForecastParams

def test_negative_trend_forecast():
    """下降トレンドデータの予測挙動をテスト"""
    print("=== 下降トレンド予測テスト ===")
    
    # 完全に下降するデータを生成
    # 1.0 -> 0.5 へ直線的に減少
    n_points = 100
    values = np.linspace(1.0, 0.5, n_points)
    # ノイズを追加
    np.random.seed(42)
    values += np.random.normal(0, 0.01, n_points)
    
    dates = pd.date_range(start="2026-01-01", periods=n_points, freq="D")
    df = pd.DataFrame({"timestamp": dates, "RMS": values})
    
    # 予測実行
    params = ForecastParams(forecast_days=30)
    forecaster = Forecaster(params)
    
    result = forecaster.predict(df, time_col="timestamp", value_col="RMS")
    
    print(f"データの傾向: {values[0]:.3f} -> {values[-1]:.3f}")
    print(f"トレンド傾き (slope): {result.trend_slope:.6f}")
    
    # 予測値の確認
    first_pred = result.forecast_values[0]
    last_pred = result.forecast_values[-1]
    
    print(f"予測初日: {first_pred:.3f}")
    print(f"予測最終日: {last_pred:.3f}")
    
    if last_pred < first_pred:
        print("判定: 下降トレンドが予測されています (現在の挙動)")
    else:
        print("判定: 下降トレンドは抑制されています")

if __name__ == "__main__":
    test_negative_trend_forecast()
