"""
GMM稼働フィルタ統合テスト

services.py にGMMフィルタを統合した結果、パイプラインが正常に動作するかを検証する。
"""

import sys
from pathlib import Path

# プロジェクトルートをパスに追加
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import numpy as np
from src.config.settings import AppConfig
from src.application.services import AnalysisService, AnalysisContext
from src.application.context import AppMode


def test_research_mode_pipeline():
    """研究モードでパイプラインが正常に動作するかテスト"""
    print("=" * 60)
    print("TEST 1: 研究モード（仮想データ）パイプラインテスト")
    print("=" * 60)
    
    # 設定をロード
    config = AppConfig.load_or_default_master(Path("config.json"))
    service = AnalysisService(config)
    
    # シナリオ: 正常データ（スパイク異常）
    context = AnalysisContext(
        sensor_id="VIRT-001",
        mode=AppMode.RESEARCH,
        random_seed=42,
        n_points=500
    )
    
    result = service.run_research_scenario({
        "type": "spike",
        "amplitude": 2.0,
        "spike_count": 5
    }, seed=42)
    
    # 結果確認
    print(f"\n[結果]")
    print(f"  sensor_data.length: {result['sensor_data'].length}")
    print(f"  analysis_result type: {type(result['analysis_result']).__name__}")
    print(f"  forecast type: {type(result['forecast']).__name__}")
    print(f"  metadata: {result['metadata']}")
    
    # フィルタ情報の確認
    metadata = result['metadata']
    if 'filter_mode' in metadata:
        print(f"\n[GMMフィルタ情報]")
        print(f"  filter_mode: {metadata.get('filter_mode')}")
        print(f"  filter_message: {metadata.get('filter_message')}")
        if 'filtered_data_points' in metadata:
            print(f"  filtered_data_points: {metadata.get('filtered_data_points')}")
    else:
        print("\n[GMMフィルタ情報] フィルタ未適用（RMS列なし）")
    
    # 検証
    assert result['sensor_data'] is not None, "sensor_data should not be None"
    assert result['analysis_result'] is not None, "analysis_result should not be None"
    assert result['forecast'] is not None, "forecast should not be None"
    
    print("\n✅ TEST 1 PASSED: 研究モードパイプライン正常動作")
    return True


def test_filter_modes():
    """各フィルタモードの動作テスト"""
    print("\n" + "=" * 60)
    print("TEST 2: GMMフィルタ単体テスト（各モード確認）")
    print("=" * 60)
    
    from src.domain.ai.operation_filter import OperationFilter
    
    op_filter = OperationFilter()
    
    # Case 1: 正常稼働データ（高分散）
    print("\n[Case 1: 正常稼働データ]")
    running_data = np.random.normal(5.0, 1.0, 100)
    result = op_filter.filter(running_data)
    print(f"  mode: {result.mode}, message: {result.reason_message}")
    
    # Case 2: 停止データ（低分散）
    print("\n[Case 2: 停止データ（低分散）]")
    stopped_data = np.random.normal(0.01, 0.001, 100)
    result = op_filter.filter(stopped_data)
    print(f"  mode: {result.mode}, message: {result.reason_message}")
    
    # Case 3: 混在データ（稼働/停止）
    print("\n[Case 3: 混在データ]")
    mixed_data = np.concatenate([
        np.random.normal(0.05, 0.01, 50),  # 停止
        np.random.normal(3.0, 0.5, 50)      # 稼働
    ])
    result = op_filter.filter(mixed_data)
    print(f"  mode: {result.mode}, message: {result.reason_message}")
    print(f"  filtered_indices count: {len(result.filtered_indices)}")
    
    # Case 4: データ不足
    print("\n[Case 4: データ不足]")
    insufficient_data = np.array([1.0, 2.0, 3.0])
    result = op_filter.filter(insufficient_data)
    print(f"  mode: {result.mode}, message: {result.reason_message}")
    
    print("\n✅ TEST 2 PASSED: GMMフィルタ各モード正常動作")
    return True


def test_stopped_early_return():
    """停止状態での早期リターンテスト"""
    print("\n" + "=" * 60)
    print("TEST 3: 停止検出時の早期リターン確認")
    print("=" * 60)
    
    from src.domain.ai.operation_filter import OperationFilter, FilterResult
    
    # 停止状態を模擬するために、modeが"stopped"になるケースを確認
    # OperationFilterでは稼働クラスタが極端に小さい場合に"stopped"になる
    op_filter = OperationFilter()
    
    # 大部分が停止状態（低RMS）で、ごく一部だけ稼働状態
    mostly_stopped = np.concatenate([
        np.random.normal(0.02, 0.005, 95),  # 停止
        np.random.normal(2.0, 0.3, 5)        # 稼働（少数）
    ])
    
    result = op_filter.filter(mostly_stopped)
    print(f"  mode: {result.mode}")
    print(f"  reason_code: {result.reason_code}")
    print(f"  reason_message: {result.reason_message}")
    
    if result.mode == "stopped":
        print("\n✅ TEST 3 PASSED: 停止状態が正しく検出された")
    else:
        print(f"\n⚠️ TEST 3 INFO: mode={result.mode}（データ特性により停止判定されない場合あり）")
    
    return True


def main():
    """メインテスト実行"""
    print("\n" + "=" * 60)
    print("GMM稼働フィルタ統合テスト - SensorApp v3.6")
    print("=" * 60)
    
    try:
        test_filter_modes()
        test_research_mode_pipeline()
        test_stopped_early_return()
        
        print("\n" + "=" * 60)
        print("🎉 全テスト完了 - パイプラインは正常に動作しています")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ テスト失敗: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
