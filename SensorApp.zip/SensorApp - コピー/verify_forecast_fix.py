"""
簡易検証スクリプト: RMS予測降下バグ修正の確認
"""

from src.application.services import AnalysisService
from src.config.settings import AppConfig
from pathlib import Path

# 設定ロード
config_path = Path(r'c:\Users\aoyam\Downloads\projects\SensorApp\config.json')
config = AppConfig.load_or_default_master(config_path)
service = AnalysisService(config)

# テストシナリオ
scenarios = [
    ('none', 42),
    ('spike', 42),
    ('shift', 42),
    ('trend', 42),
    ('trend', 46),  # 問題が発生したシード
]

print('Testing all scenarios:')
print('-' * 60)

for scenario_type, seed in scenarios:
    params = {
        'type': scenario_type,
        'n_points': 500,
        'amplitude': 2.0 if scenario_type != 'trend' else 1.0,
        'duration': 30,
        'injection_point': 0.3
    }
    
    if scenario_type == 'trend':
        params['trend_slope'] = 0.001
    
    result = service.run_research_scenario(params=params, seed=seed)
    forecast = result.get('forecast')
    
    if forecast and forecast.length > 0:
        min_val = min(forecast.forecast_values)
        max_val = max(forecast.forecast_values)
        status = '✅ PASS' if min_val >= 0 else '❌ FAIL'
        
        print(f'{status} {scenario_type:10s} (seed={seed:2d}) | min={min_val:8.3f} | max={max_val:8.3f}')
    else:
        print(f'⚠️  {scenario_type:10s} (seed={seed:2d}) | No forecast generated')

print('-' * 60)
print('Verification complete!')
