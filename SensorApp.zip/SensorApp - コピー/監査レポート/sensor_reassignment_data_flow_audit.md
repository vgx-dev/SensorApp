# センサー付け替え時のデータフロー監査レポート

**監査日**: 2026-01-21  
**監査バージョン**: Version 3.6  
**対象質問**: センサ管理で違う設備にセンサを付け替えたら、その段階からのグラフ表示・分析になるか？

---

## エグゼクティブサマリー

**結論**: **いいえ、現在の実装ではセンサIDベースでデータを取得しており、設備付け替え後も過去の全履歴データがグラフ表示・分析対象となります。**

| 観点 | 現状 |
|------|------|
| グラフ表示 | センサIDの全履歴を表示（設備変更を考慮しない） |
| 異常分析 | センサIDの全履歴を対象（設備変更を考慮しない） |
| コンテキスト表示 | ✅ 正しく現在の設備・装置を表示 |

---

## 詳細分析

### 1. データ取得フロー

```mermaid
graph TD
    A[data_view.py<br>render_data_view] --> B[選択されたsensor_id]
    B --> C[RealDataProvider.get_sensor_data]
    C --> D[CSVからセンサIDでフィルタ]
    D --> E[全履歴データを返却]
    E --> F[グラフ表示]
    E --> G[異常検知分析]
```

#### 根拠コード（[real_data.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/real_data.py#L332-L393)）:

```python
def get_sensor_data(
    self,
    sensor_id: str,
    *,
    tail_rows: Optional[int] = None
) -> SensorData:
    # ...
    # センサIDでフィルタリング
    if SENSOR_ID_COL in df.columns:
        df = df[df[SENSOR_ID_COL] == str(sensor_id)].copy()  # ← 設備情報を考慮しない
```

**問題点**: `sensor_id` のみでフィルタリングしており、`equipment_id` や `mount_date` を使った時系列区間の制限がない。

### 2. マウント履歴管理

マウント管理機能は**存在し、正しく動作している**:

| ファイル | 機能 |
|----------|------|
| [sensor_mount_list.csv](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/master_data.py#L58-L70) | マウント履歴（SensorID, EquipmentID, DeviceID, StartTime, EndTime） |
| [sensor_mount_history.csv](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/real_data.py#L582-L640) | 変更イベントの追跡ログ |

#### マウント情報の利用箇所:

1. **UI表示（正しく実装済み）**: [data_view.py L80-92](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/presentation/views/operational/data_view.py#L80-L92)
   ```python
   context = mgmt_service.get_sensor_context(sensor_id)
   if context:
       st.info(f"📍 **設備:** {context.equipment} 　**装置:** {context.device}")
   ```

2. **AIモデル保存/ロード（正しく実装済み）**: [services.py L408-428](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/application/services.py#L408-L428)
   - 設備・装置ごとにモデルを保存/ロード

3. **データ取得（未実装）**: 設備単位での時系列区間フィルタリングがない

### 3. 問題の影響

| シナリオ | 現状の挙動 | 期待される挙動 |
|----------|-----------|---------------|
| センサXを設備Aから設備Bへ付け替え | 設備A+設備Bの全データでグラフ表示 | 設備Bのデータのみでグラフ表示 |
| 設備A時代の異常パターン | 設備Bの分析に影響する | 設備Bの分析には影響しない |
| ベースライン計算 | 設備A+B両方の平均値 | 設備Bのみの平均値 |

---

## 監査結果

### 【指摘レベル】**Critical**

### 【問題点】
センサ付け替え時にデータの時系列区間が分離されておらず、異なる設備のデータが混在して分析される。

### 【根拠】
1. `RealDataProvider.get_sensor_data()` は `sensor_id` のみでフィルタリング
2. マウント履歴の `StartTime`/`EndTime` がデータフィルタリングに使用されていない
3. `AnalysisService.run_analysis()` も設備情報でのデータ区間分離を行っていない

### 【データフロー分析】

```
現状:
  CSV(全履歴) → sensor_id フィルタ → 全期間データ → 分析

期待:
  CSV(全履歴) → sensor_id フィルタ → 現在マウント期間でフィルタ → 分析
```

### 【放置した場合のリスク】

| リスク | 重要度 | 影響 |
|--------|--------|------|
| **誤検知の増加** | 🔴 Critical | 異なる設備特性のデータが混在し、異常スコアの精度が低下 |
| **予測精度の劣化** | 🔴 Critical | ベースラインが実態と乖離し、メンテナンス推奨が不正確に |
| **論文検証の妥当性** | 🟠 Major | 設備単位での分析結果が学術的に成立しない |
| **ユーザー混乱** | 🟡 Minor | UIは正しい設備を表示するが、グラフは過去設備のデータを含む |

---

## 改善案（最小改修原則に準拠）

### オプション A: データ取得時にマウント期間でフィルタリング（推奨）

**変更箇所**: [RealDataProvider.get_sensor_data()](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/real_data.py#L332-L393)

```diff
def get_sensor_data(
    self,
    sensor_id: str,
    *,
    tail_rows: Optional[int] = None,
+   mount_start: Optional[datetime] = None,  # マウント開始日時
+   mount_end: Optional[datetime] = None     # マウント終了日時
) -> SensorData:
    # ...
    if SENSOR_ID_COL in df.columns:
        df = df[df[SENSOR_ID_COL] == str(sensor_id)].copy()
    
+   # マウント期間でフィルタリング
+   if mount_start is not None and TIME_COL in df.columns:
+       df = df[df[TIME_COL] >= mount_start]
+   if mount_end is not None and TIME_COL in df.columns:
+       df = df[df[TIME_COL] <= mount_end]
```

**呼び出し側変更**: [data_view.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/presentation/views/operational/data_view.py#L94-L107)

```python
# マウント情報を取得し、データ取得時に期間を渡す
context = mgmt_service.get_sensor_context(sensor_id)
if context and context.mount_date:
    # マウント開始日以降のデータのみ取得
    ...
```

**影響範囲**: 2ファイル、約20行の追加

### オプション B: Application層でフィルタリング

**変更箇所**: [AnalysisService._run_analysis_impl()](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/application/services.py#L160-L240)

データ取得後、分析前にマウント期間でDataFrameをフィルタリングする。

**影響範囲**: 1ファイル、約15行の追加

---

## 現行アーキテクチャの評価

### S級設計原則への適合度

| 原則 | 評価 | コメント |
|------|------|----------|
| **軽量化・効率化** | ✅ A | 不要な処理なし |
| **分散管理** | ✅ S | 責務分離は良好 |
| **データフローの単方向性** | ✅ S | 逆流なし |
| **後戻りのないフロー** | ✅ S | 非可逆 |
| **設備単位のデータ分離** | ❌ D | **未実装** |

### 総合評価

| 評価項目 | 評価 |
|----------|------|
| **アーキテクチャ健全性** | B |
| **学術的妥当性** | C（設備単位分析が成立しない） |
| **プロダクト品質** | B |

---

## 結論

### 現状の総合評価: **B**

### 致命的リスク

| 観点 | リスク有無 |
|------|-----------|
| 論文検証 | ⚠️ **あり** - 設備単位の検証結果が学術的に成立しない |
| プロダクト | ⚠️ **あり** - センサ付け替え運用時に誤検知リスク |

### 推奨アクション

1. **オプションA**の最小改修を実施（推奨、約20行の変更）
2. センサ付け替え時のデータ継続性についてユーザーへの説明文書を追加

---

## 参照ファイル

- [real_data.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/real_data.py)
- [data_view.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/presentation/views/operational/data_view.py)
- [services.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/application/services.py)
- [management_service.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/application/management_service.py)
- [mount_manager.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/domain/services/mount_manager.py)
- [master_data.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/master_data.py)
