# 研究論文たたき台: 振動センサを用いた設備診断AIシステム

**作成日**: 2026年1月28日（最終更新 22:45）  
**対象システム**: SensorApp v3.7  
**論文形式**: 技術論文（査読付き学術誌向け）

---

## 論文タイトル案

**日本語**: 産業用振動センサデータに基づくアンサンブル異常検知と適応的未来予測システムの設計と評価

**English**: Design and Evaluation of an Ensemble Anomaly Detection and Adaptive Future Prediction System for Industrial Vibration Sensor Data

---

## 概要 (Abstract)

本論文では、産業設備の予知保全を目的とした振動センサデータ分析システムを提案する。本システムは、Isolation ForestとAutoEncoderを組み合わせたアンサンブル異常検知手法、時系列分解に基づく適応的未来予測手法、およびセンサローテーション管理機能を統合的に実装している。

主な貢献:
1. **動的閾値算出**: データ分布に適応するパーセンタイルベース閾値（86パーセンタイル）
2. **連続性ボーナス**: 局所的異常パターン検出の精度向上（1.3倍ブースト）
3. **√t成長信頼区間**: 時系列予測理論に準拠した信頼区間モデル
4. **符号整合性チェック**: 物理的に妥当な長期予測の保証
5. **センサコンテキスト管理**: 設備-センサ間の時系列追跡
6. **効率的データ読込**: マウント開始日からのファイル選択とキャッシュ機構（v3.7追加）

---

## 1. はじめに (Introduction)

### 1.1 背景
産業設備の予知保全において、振動センサデータからの異常検知と劣化予測は重要な課題である。従来手法では、固定閾値による異常判定や単純な線形外挿による予測が主流であったが、実環境では以下の課題が存在する:

- センサ間・設備間のデータ分布の違い
- 時間経過に伴う予測不確実性の増大
- センサローテーションによるコンテキスト変化
- 長期予測における物理的妥当性の欠如

### 1.2 本論文の貢献
本システムは上記課題を解決するため、以下の設計原則に基づいて構築された:

| 原則 | 内容 |
|------|------|
| 軽量化・効率化 | 最小限の計算で論文検証可能な構造 |
| 分散管理 | モジュール間結合度の最小化 |
| 単方向データフロー | 予測可能な一方向構造 |
| 後戻りなしパイプライン | 非可逆・検証可能なフロー |

---

## 2. システム設計 (System Design)

### 2.1 アーキテクチャ概要

```mermaid
flowchart TD
    subgraph Input["入力層"]
        CSV["CSVログファイル<br>SensorNode_yyyymmdd.csv"]
    end
    subgraph Infra["Infrastructure層"]
        RDP["RealDataProvider<br>全ファイル結合・効率読込"]
        MDP["MasterDataRepository<br>マスタデータ管理"]
    end
    subgraph Domain["Domain層"]
        OPF["OperationFilter<br>GMM稼働フィルタ"]
        DET["AnomalyDetector<br>IF+AEアンサンブル"]
        FOR["Forecaster<br>トレンド分解+√t予測"]
    end
    subgraph App["Application層"]
        SVC["AnalysisService<br>パイプライン制御"]
        MGT["ManagementService<br>センサ管理"]
        CACHE["キャッシュ機構<br>st.cache_data"]
    end
    subgraph Output["出力層"]
        UI["Streamlit UI"]
        REP["ZIPレポート"]
    end
    
    CSV --> RDP --> SVC
    MDP --> MGT
    SVC --> OPF --> DET --> SVC
    SVC --> FOR --> SVC
    SVC --> CACHE --> UI
    SVC --> REP
```

### 2.2 ロジック一貫性の保証 (Logic Consistency)

本システム最大の特徴は、運用モードと研究検証モードが **完全に同一のDomainロジック** を共有している点にある。これにより、研究モードで得られた検証結果（精度、F1スコア等）は、ブラックボックスなく運用環境に適用可能である。

```mermaid
flowchart TD
    subgraph Mode["入力モード"]
        OP["運用モード<br>(Operational)"]
        RES["研究モード<br>(Research)"]
    end

    subgraph App["Application Layer (Unified Pipeline)"]
        SVC["AnalysisService<br>共通パイプライン制御"]
        STRAT{"Strategy Pattern"}
        SEED["Seed Context<br>再現性保証"]
    end

    subgraph Infra["Infrastructure Layer (Swappable)"]
        REAL["RealDataProvider<br>CSVログ読込"]
        VIRT["VirtualDataProvider<br>物理モデル生成"]
    end

    subgraph Domain["Domain Layer (Shared Core Logic)"]
        ENTITY(["SensorData Entity<br>共通データ構造"])
        DET["AnomalyDetector<br>学習・推論"]
        FOR["Forecaster<br>予測・推奨"]
    end

    OP -->|Real-time| SVC
    RES -->|Simulation| SEED --> SVC
    
    SVC --> STRAT
    STRAT -->|Production| REAL
    STRAT -->|Experiment| VIRT
    
    REAL --> ENTITY
    VIRT --> ENTITY
    
    ENTITY --> DET
    DET --> FOR
    FOR -->|AnalysisResult| SVC
```

- **共通データ構造**: どちらのプロバイダも同一の `SensorData` エンティティを生成するため、Domain層はデータの出所を意識しない。
- **純粋関数的コア**: `AnomalyDetector` と `Forecaster` は外部状態（DBやUI）に依存しない純粋な計算クラスとして実装されている。

### 2.3 効率化と再現性の両立 (Efficiency & Reproducibility)

研究検証モードでは多数のパラメータ設定を試行錯誤する必要があるため、以下の工夫によりUXと計算効率を両立している。

- **ハッシュベースのメモ化 (Memoization)**:
  入力パラメータ（シナリオ、シード、モデル設定）のハッシュ値をキーとして計算結果をキャッシュする。

- **厳密分離されたコンテキスト (Context Isolation)**:
  `OperationalContext`（運用）と `ResearchContext`（研究）を明確に分離し、UI状態の混同によるオペレーションミスをシステムレベルで防止している。

- **AI分析キャッシュ（v3.7追加）**:
  `@st.cache_data(ttl=60)` により、タブ切替時の再分析を抑制し、UXを大幅改善。

---

## 3. 入力データフロー (Data Flow)

### 3.1 CSVデータ仕様

| 列インデックス | 内容 | 型 |
|--------------|------|-----|
| 0 (A列) | センサID | string |
| 28 (AC列) | RMS値 [m/s²] | float |
| 30 (AE列) | Value 2 | float |
| 32 (AG列) | Value 3 | float |
| 38 (AM列) | 測定時刻 | datetime |

### 3.2 データ整形手法

**ファイル**: [real_data.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/real_data.py)

1. **全ファイル結合読込（v3.7改善）**: `SensorNode_*.csv` を全て結合
2. **効率的読込方式**:
   - 最新ファイル: 一時コピーで読込（書込中ロック回避）
   - 古いファイル: 直接読込（高速）
3. **マウント開始日からのファイル選択（v3.7追加）**:
   - ファイル名から日付を抽出（`_extract_date_from_filename()`）
   - マウント開始日以降のファイルのみ読込（効率化）
4. **型変換**:
   - センサID → 文字列 (`str.strip()`)
   - 時刻 → datetime (`pd.to_datetime(..., errors='coerce')`)
   - RMS → 数値 (`pd.to_numeric(..., errors='coerce')`)

```python
# 効率的なCSV結合読込の実装（v3.7）
csv_files = self.get_all_csv_paths()

# マウント開始日からファイル名でフィルタリング
if mount_start_time is not None:
    mount_date_str = mount_start_time.strftime("%Y%m%d")
    csv_files = [f for f in csv_files 
                 if self._extract_date_from_filename(f.name) >= mount_date_str]

for csv_path in files_to_process:
    if csv_path == latest_csv:
        df = self._load_csv_raw(csv_path)     # 一時コピー版
    else:
        df = self._load_csv_direct(csv_path)  # 直接読込版
```

### 3.3 マウント履歴に基づくデータ分離（S+級改善）

**目的と課題**:
産業現場では、同一センサを異なる設備に付け替えて使用する「センサローテーション」が一般的である。この場合、センサIDが同一でも設備特性（回転数、負荷、振動特性）が異なるため、異なる設備のデータを混在させて分析すると、異常検知のベースラインが誤り、誤報・見逃しが発生する。

**解決手法**:
本システムでは、マウント履歴（`sensor_mount_history.csv`）を参照し、**現在のマウント期間のデータのみ**を分析対象とすることで、設備ごとの正確な異常検知を実現している。

**実装詳細** ([real_data.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/real_data.py)):

```python
def get_mount_info(self) -> List[MountInfo]:
    # マウント履歴から最新のStartTime/EndTimeを取得（v3.7改善）
    if history_file.exists():
        for sensor_id in hist_df["SensorID"].unique():
            # 最新のmount/unmount時刻を計算
            mount_date = mounts["Timestamp"].iloc[-1] if not mounts.empty else None
            unmount_date = unmounts["Timestamp"].iloc[-1] if not unmounts.empty else None
            
            # unmountがmountより古い場合は現在運用中
            if mount_date and unmount_date and unmount_date < mount_date:
                unmount_date = None
```

**マウント履歴がない場合の動作（堅牢性保証）**:
マウント管理を使用しない運用でも正常動作する。`mount_start_time=None`の場合は全ファイル読込（従来動作）となる。

| 状況 | mount_start_time | 動作 |
|------|------------------|------|
| 履歴あり | 日時設定 | その日以降のファイルのみ読込 |
| 履歴なし | None | 全ファイル読込（従来動作） |

**学術的意義**:
マウント履歴による厳密なデータ分離は、本システムにおける **設備単位での統計的妥当性** を保証する基盤技術である。この機構により、論文における「設備ごとの異常検知精度」の主張が実証可能となっている。

---

## 4. 前処理：GMMによる稼働状態フィルタリング (Preprocessing with GMM)

### 4.1 課題とアプローチ
産業用設備は断続的に稼働する場合があり、停止期間のデータ（ノイズレベル）が混入すると異常検知の精度が低下する。従来は固定閾値で除去していたが、設備ごとに閾値調整が必要という課題があった。本システムでは、Gaussian Mixture Model (GMM) を用いた教師なしクラスタリングにより、稼働状態を自動判別する手法を実装した。

### 4.2 アルゴリズム詳細

**ドメインロジック**: [operation_filter.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/domain/ai/operation_filter.py)

1. **GMMクラスタリング**: 入力RMS値分布に対し、クラスタ数 $k \in \{1, 2, 3\}$ のGMMを適用
2. **モデル選択**: BIC (Bayesian Information Criterion) が最小となるモデルを選択
3. **稼働判定**: 平均値が最大のクラスタを「稼働状態」と定義し、該当インデックスを抽出

$$
\text{RunningIndices} = \{i \mid \text{label}_i = \arg\max_k(\mu_k)\}
$$

### 4.3 堅牢性確保の工夫（S級設計）
- **分散チェック**: 分散が極小の場合（$\sigma < 0.01$）は単一状態とみなす
- **分離度チェック**: クラスタ間距離が近い場合（$\Delta\mu < 0.03$）は分離不可として全データ採用
- **データ不足時**: 最小点数（デフォルト20点）未満ではフィルタ適用を回避

### 4.4 パイプライン統合（v3.7）

**統合位置**: [services.py#L210-L258](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/application/services.py#L210-L258)（Application層）

GMMフィルタは `_run_analysis_impl()` メソッド内で、データ取得直後・AI分析前に適用される。**運用モード専用**として設計されており、研究モードでは再現性保証のためバイパスされる。

```python
# services.py 内のGMM稼働フィルタ（運用モード専用）
if context.mode == AppMode.OPERATIONAL and rms_col in sensor_data.dataframe.columns:
    op_filter = OperationFilter()
    filter_result = op_filter.filter(sensor_data.dataframe[rms_col].values)
    
    if filter_result.mode == "stopped":
        # Case A: 完全停止 → 分析スキップ（Early Return）
        return {..., "reason_code": "EQUIPMENT_STOPPED"}
    elif filter_result.mode == "mixed":
        # Case B: 混在 → 稼働データのみ抽出
        sensor_data.dataframe = sensor_data.dataframe.iloc[filter_result.filtered_indices].copy()
else:
    # 研究モード: フィルタなしで全データ使用（再現性保証）
    filter_info = {"filter_mode": "skipped", "filter_reason": "research_mode"}
```

**設計根拠（S+級）**:
- **運用モード**: 実設備には停止期間があり、GMMフィルタは誤検知防止に有効
- **研究モード**: 仮想データは連続稼働を模倣しており、フィルタ適用は論理的に不適切。同一シード・同一パラメータでの完全再現性を保証

**学術的意義**: ドメインロジック（`OperationFilter`）とパイプライン制御（`AnalysisService`）を分離し、モード別の適用制御をApplication層で管理することで、単体テスト容易性と再現性を両立している。

---

## 5. 異常検知手法 (Anomaly Detection)

### 5.1 アンサンブルモデル構成

**ファイル**: [detector.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/domain/ai/detector.py)

| モデル | 役割 | 重み | 備考 |
|--------|------|------|------|
| Isolation Forest (IF) | 外れ値検出 | 0.4 | sklearn実装、n_estimators=100 |
| AutoEncoder (AE) | 再構成誤差 | 0.3 | TensorFlow（オプション） |
| 残差スコア | 急変検出 | 0.0 | 現状無効化 |

> [!NOTE]
> 重みは `settings.py` の `AIParams` で定義され、合計0.7となる。残差スコアは現状無効化されており、IF+AEの2モデルで運用。

### 5.2 ロバストスコア正規化 (Robust Normalization)

一般的な Min-Max 正規化は外れ値（極端な異常値）に弱く、正常範囲が 0 に圧縮されてしまう問題がある。本システムでは **パーセンタイルベース正規化** を採用し、ロバスト性を確保した。

$$
S_{norm} = \text{clip}\left(\frac{S_{raw} - P_{05}}{P_{95} - P_{05}}, 0.0, 1.0\right)
$$

ここで $P_{05}, P_{95}$ はそれぞれスコア分布の5パーセンタイル、95パーセンタイル値である。

### 5.3 動的閾値算出

**学術的根拠**: データ分布のパーセンタイル（デフォルト86%）に基づき閾値を自動算出

$$
\text{threshold} = \text{clip}\left(\text{percentile}(\text{scores}, 86), 0.3, 0.7\right)
$$

| パラメータ | 値 | 説明 |
|-----------|-----|------|
| `threshold_percentile` | 86.0 | 上位14%を異常とする |
| 下限クリップ | 0.3 | 閾値がこれ未満だと感度が高すぎる |
| 上限クリップ | 0.7 | 閾値がこれを超えると異常を見逃す |

### 5.4 連続性ボーナス

**目的**: Spike/Shift等の局所的異常パターンの検出精度向上

**実装** ([detector.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/domain/ai/detector.py)):
```python
def _apply_continuity_bonus(self, scores, window=3, bonus_factor=1.3):
    # 連続window点以上が閾値0.3を超える区間にボーナス
    for i in range(len(scores) - window + 1):
        if np.all(scores[i:i+window] > 0.3):
            scores[i:i+window] *= bonus_factor  # 30%増
```

---

## 6. 未来予測手法 (Future Prediction)

### 6.1 トレンド分解

**ファイル**: [forecaster.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/domain/ai/forecaster.py)

時系列データを以下の成分に分解:

$$
y_t = T_t + S_t + R_t
$$

| 成分 | 計算方法 |
|------|----------|
| $T_t$ (トレンド) | 移動平均 (window = 7日) |
| $S_t$ (季節) | トレンド除去後の周期平均 |
| $R_t$ (残差) | $y_t - T_t - S_t$ |

### 6.2 信頼区間成長モデル（S級改修）

**学術的根拠**: 時系列予測の分散は時間の平方根に比例して増大する（Wiener過程）

$$
\text{margin}(t) = \sigma_\text{base} \times \left(1 + \sqrt{\frac{t}{30}}\right)^{0.5}
$$

| パラメータ | 値 | 説明 |
|-----------|-----|------|
| `base_margin_mps2` | 0.15 | センサノイズ×3σ [m/s²] |
| `margin_growth_exponent` | 0.5 | √t成長 |

### 6.3 適応的予測モデル（S+級アルゴリズム）

単純な線形予測では急激な劣化進行を捉えられないため、ベースライン（全期間トレンド）に直近の加速度成分を加味するハイブリッド手法を実装した。

$$
y_{pred}(t) = y_{base}(t) + w \cdot \alpha (t - t_{now})^2
$$

**安定化と物理的妥当性確保の3つの工夫**:

1. **勾配不感帯 (Slope Deadband)**:
   微小なノイズによるトレンド誤検知を防ぐため、傾き/切片の比率が0.05%未満の場合はトレンドなし（水平）とみなす。

2. **符号整合性チェック (Sign Consistency Check)**:
   トレンドと加速度の符号が不一致の場合は加速度成分を抑制。

3. **物理的非負制約 (Physical Non-negative Constraint)**:
   振動RMS値は定義上、負の値を取り得ない（RMS $\ge 0$）。

---

## 7. センサ管理手法 (Sensor Management)

### 7.1 CRUD操作

**ファイル**: [management_service.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/application/management_service.py)

| 操作 | メソッド | 備考 |
|------|----------|------|
| Create | `register_mount_with_user()` | 使用者情報付き |
| Read | `get_mount_history()` | DataFrame形式（キャッシュ付き） |
| Update | `update_mount()` | 部分更新対応 |
| Delete | `delete_mount()` | インデックス指定 |

### 7.2 時系列追跡（S+級改善）

センサのローテーション履歴を時刻付きで記録:

```csv
Timestamp,SensorID,EquipmentID,DeviceID,Action,Description
2026-01-19T10:00:00,SENSOR-001,OPF-1,CTポンプ,mount,初回取付
2026-01-20T14:30:00,SENSOR-001,OPF-1,CTポンプ,unmount,ローテーション
```

---

## 8. 実験と評価 (Experiments)

### 8.1 仮想データ生成プロトコル

**ファイル**: [virtual_data.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/virtual_data.py)

単なるランダム生成ではなく、実機の振動特性を模倣した物理ベース生成ロジックを採用している。

| シナリオ | 内容 | 異常注入方法 |
|----------|------|-------------|
| none | 正常データ | 物理ベース生成のみ |
| spike | 突発異常 | ランダム位置に振幅2σ（ガウス分布） |
| shift | レベル変化 | 注入点以降ステップ状オフセット |
| trend | トレンド劣化 | 加速度的な増加成分の重畳 |

### 8.2 再現性保証メカニズム（State Isolation）

研究データが運用環境を汚染しないよう、コンテキストマネージャーによる厳密な状態管理を実装している。

```python
@contextmanager
def seed_context(self, seed: int):
    state_random = random.getstate()
    state_np = np.random.get_state()
    try:
        random.seed(seed)
        np.random.seed(seed)
        yield
    finally:
        random.setstate(state_random)
        np.random.set_state(state_np)
```

### 8.3 検証結果サマリー

2026年1月19日の検証実行結果:

| シナリオ | シード | 予測最小値 | 予測最大値 | 判定 |
|----------|--------|------------|------------|------|
| none | 42 | 0.179 | 0.994 | ✅ PASS |
| spike | 42 | 0.000 | 0.763 | ✅ PASS |
| shift | 42 | 0.209 | 1.024 | ✅ PASS |
| trend | 42 | 1.435 | 1.779 | ✅ PASS |

---

## 9. 結論 (Conclusion)

本論文では、産業用振動センサデータに特化したAI診断システムを提案した。主な成果:

1. **GMM稼働フィルタ**: パラメータレスでの稼働/停止分離（運用モード専用）
2. **IF+AEアンサンブル**: 複数モデルの統合による堅牢な異常検知
3. **√t信頼区間成長**: 学術的に妥当な予測不確実性モデル
4. **符号整合性チェック**: 物理的に妥当な長期予測の保証
5. **センサコンテキスト管理**: 運用現場に適したローテーション追跡
6. **効率的データ読込（v3.7）**: マウント開始日からのファイル選択とキャッシュ機構

4大原則（軽量化・分散管理・単方向フロー・後戻りなし）を厳守し、S級アーキテクチャを達成した。

---

## 10. 今後の展望 (Future Work)

### 10.1 学習フェーズへの拡張: マルチモーダル学習
現在のGMMは稼働/停止の2値分類に使用しているが、これを設備の「高速運転」「低速運転」といった多段階の動作モード分類へ拡張する。

### 10.2 診断フェーズへの拡張: 異常要因クラスタリング
検知された異常パターンを教師なし分類することで、故障診断を支援する。

---

## 参考文献 (References)

1. Liu, F.T., et al. "Isolation forest." ICDM 2008.
2. An, J., Cho, S. "Variational autoencoder based anomaly detection." arXiv 2015.
3. ISO 10816-1:1995. "Mechanical vibration evaluation."
4. Box, G.E.P., et al. "Time Series Analysis: Forecasting and Control."
5. Jain, A.K. "Data clustering: 50 years beyond K-means." Pattern Recognition Letters 2010.

---

## 付録A: コード対応表

| 論文セクション | 対応ファイル | 主要クラス/関数 |
|---------------|-------------|----------------|
| 3. 入力データフロー | [real_data.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/real_data.py) | `RealDataProvider` |
| 4. GMM稼働フィルタ | [operation_filter.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/domain/ai/operation_filter.py) | `OperationFilter` |
| 4.4 パイプライン統合 | [services.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/application/services.py#L210-L258) | `AnalysisService._run_analysis_impl()` |
| 5. 異常検知 | [detector.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/domain/ai/detector.py) | `AnomalyDetector.score()` |
| 6. 未来予測 | [forecaster.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/domain/ai/forecaster.py) | `Forecaster.predict()` |
| 7. センサ管理 | [management_service.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/application/management_service.py) | `ManagementService` |
| 8. 仮想データ | [virtual_data.py](file:///c:/Users/aoyam/Downloads/projects/SensorApp/src/infrastructure/repositories/virtual_data.py) | `VirtualDataProvider` |

---

## 付録B: パラメータ一覧

### B.1 AIParams（異常検知）

| パラメータ | 値 | 説明 |
|-----------|-----|------|
| `if_n_estimators` | 100 | Isolation Forestの決定木数 |
| `if_contamination` | 0.05 | 予想される異常データの割合 |
| `weight_if` | 0.4 | IFスコアの重み |
| `weight_ae` | 0.3 | AEスコアの重み |
| `threshold_percentile` | 86.0 | 動的閾値のパーセンタイル |

### B.2 ForecastParams（未来予測）

| パラメータ | 値 | 説明 |
|-----------|-----|------|
| `forecast_days` | 365 | 予測日数 |
| `confidence_level` | 0.95 | 信頼区間レベル |
| `trend_window` | 7 | トレンド抽出の移動平均窓 |
| `use_adaptive_forecast` | True | 適応的予測の有効化 |
| `recent_weight` | 0.7 | 直近データの重み |
| `base_margin_mps2` | 0.15 | 基準マージン [m/s²] |

---

## 付録C: v3.7更新履歴（2026年1月28日）

| 修正内容 | ファイル | 効果 |
|---------|---------|------|
| AI分析キャッシュ導入 | `data_view.py` | タブ切替時の遅延解消 |
| 全CSVファイル結合読込 | `real_data.py` | 複数日のデータ統合 |
| 最新ファイルのみ一時コピー | `real_data.py` | 読込効率化 |
| マウント開始日からファイル選択 | `real_data.py` | 不要ファイル読込回避 |
| マウント履歴からStartTime取得 | `real_data.py` | データ期間自動判定 |
| GMMフィルタを運用モード専用に | `services.py` | 研究モード再現性保証 |
